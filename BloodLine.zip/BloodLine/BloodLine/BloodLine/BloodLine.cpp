﻿#include "BloodLine.h"

BloodLine::BloodLine(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);

	X = 1167 - 754;
	Y = 1051 - 1029;
	Y2 = 1080 - 1029;

	resize(X, Y2);

	move(754, 1029);

}

BloodLine::~BloodLine()
{}

void BloodLine::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);

	//画边框
	painter.setPen(QPen(Qt::green, 1));

	//painter.drawLine(1, 1 ,X-1 ,Y-1 );

	//painter.drawLine(1, 1, X - 1, 1);//上

	//painter.drawLine(1, 1, 1, Y - 1);//左

	//painter.drawLine(1, Y - 1, X - 1, Y - 1);//下

	//painter.drawLine(X - 1, 1, X - 1, Y - 1);//右

	painter.drawLine(0, 0, X , 0);//上

	painter.drawLine(0, 0, 0, Y );//左

	painter.drawLine(0, Y , X , Y );//下

	painter.drawLine(X -1, 0, X-1 , Y );//右

	//画线

	double point;//线的位置=血量百分比
	int LineWidth = 2;//线宽

	QFont font1;
	font1.setPointSizeF(15);
	painter.setFont(font1);
	painter.setBrush(Qt::NoBrush);

	//5圈，伤害3，最低血线18
	point = X * 0.18;
	painter.setPen(QPen(Qt::green, LineWidth));
	painter.drawLine(point, 0, point, Y);
	painter.drawText(point-5,Y+20 , "5");

	//6圈，伤害5，最低血线30
	point = X * 0.30;
	painter.setPen(QPen(Qt::yellow, LineWidth));
	painter.drawLine(point, 0, point, Y);
	painter.drawText(point - 5, Y + 20, "6");

	//7圈，伤害7，最低血线42
	point = X * 0.42;
	painter.setPen(QPen(Qt::darkRed, LineWidth));
	painter.drawLine(point, 0, point, Y);
	painter.drawText(point - 5, Y + 20, "7");

	//8圈，伤害9，最低血线54
	point = X * 0.54;
	painter.setPen(QPen(Qt::blue, LineWidth));
	painter.drawLine(point, 0, point, Y);
	painter.drawText(point - 5, Y + 20, "8");

	//9圈，伤害11，最低血线66
	point = X * 0.66;
	painter.setPen(QPen(Qt::red, LineWidth));
	painter.drawLine(point, 0, point, Y);
	painter.drawText(point - 5, Y + 20, "9");
}

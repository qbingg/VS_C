﻿#pragma once

#include <QWidget>
#include "ui_BloodLine.h"
#include <qpainter.h>

class BloodLine : public QWidget
{
	Q_OBJECT

public:
	BloodLine(QWidget *parent = nullptr);
	~BloodLine();
	void paintEvent(QPaintEvent* event);
private:
	Ui::BloodLineClass ui;
	int X;//血条长
	int Y;//血条宽
	int Y2;//窗口宽
};

﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);
}

Widget::~Widget()
{}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_BloodLine = new BloodLine;

        m_BloodLine->show();
    }
    else
    {

        delete m_BloodLine;
        m_BloodLine = nullptr;
    }
    return false;
}
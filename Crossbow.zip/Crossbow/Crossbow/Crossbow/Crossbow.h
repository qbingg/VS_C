﻿#pragma once

#include <QWidget>
#include "ui_Crossbow.h"
#include "VS_C.h"

class Crossbow : public QWidget
{
	Q_OBJECT

public:
	Crossbow(QWidget *parent = nullptr);
	~Crossbow();

private:
	Ui::CrossbowClass ui;
	bool* push_RB;
	cv::Mat IMG;
	int res_y;
	float* enemy_meter;
public:
	void getpush_RB(bool& m_push_RB);
	void getenemy_meter(float& m_enemy_meter);
private:
	QTimer* m_timer;
private slots:
	void updateWidget();
public:
	void paintEvent(QPaintEvent* event);
	void startTimer();
	void stopTimer();
};

﻿#pragma once

#include <qtimer.h>
#include <qpainter.h>
#include <Windows.h>
#include <thread>
#include <cmath>

//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\SEenvironment\OpenCV\opencv\build\include
//                      D:\SEenvironment\OpenCV\opencv\build\include\opencv2
// 4.库目录 D:\SEenvironment\OpenCV\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
#include <opencv2/opencv.hpp>

#define S1 Sleep(1);
#define S30 Sleep(30);
#define S100 Sleep(100);
#define S500 Sleep(500);
#define S1000 Sleep(1000);

#define GET_LB GetAsyncKeyState(VK_LBUTTON) 
#define GET_RB GetAsyncKeyState(VK_RBUTTON) 
#define GET_LSHIFT GetAsyncKeyState(VK_LSHIFT)
#define GET_R GetAsyncKeyState(82) 

#define USE_NUM keybd_event(VK_NUMLOCK, 0, 0, 0);keybd_event(VK_NUMLOCK, 0, KEYEVENTF_KEYUP, 0);

#define th std::thread

#define USE_F7 keybd_event(VK_F7, 0, 0, 0);keybd_event(VK_F7, 0, KEYEVENTF_KEYUP, 0);

#define PUBGWINDOWNAME L"PUBG: BATTLEGROUNDS "

//输入以玩家为原点的坐标，返回,距离x/y轴的原始像素位置
inline int f(int x)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】
	int map_n = 462 / 2;
	
	int res = x + map_n;

	return res;
}

//输入以玩家为原点,距离x/y轴的米数，返回原始像素位置
inline int F(int meter)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

	int map = 462;

	int map_n = map / 2;

	double n = map / static_cast<double>(700);//每1米对应的像素值

	int x = meter * n;

	int res = x + map_n;

	return res;
}

//输入米数，返回对应像素值（单位：n个像素点/米）
inline int meter_To_Pixel(int meter)
{
	int map = 462;

	double n = map / static_cast<double>(700);//每1米对应的像素值

	int Pixel = meter * n;

	return Pixel;
}

#define PI 3.1415926

//截取指定区域灰度图像函数
inline void f_scr(cv::Mat& image, int x1, int y1, int x2, int y2)
{


    //PUBG窗口截图方式
    LPCWSTR str = PUBGWINDOWNAME;
    // 1. 查找窗口句柄  

    //LPCWSTR str = L"**高校水电费管理系统——20231862卢伟明";

    //LPCWSTR str = L"PUBG：绝地求生 ";//md后面藏了个空格!!!!!!!!!!!!!!!!!       D:\SEenvironment\VisualSC2022\Community\Common7\Tools\spyxx_amd64.exe
    // LPCWSTR str = L"TslGame";

    HWND hwnd = FindWindowW(NULL, str);
    if (hwnd == NULL) {
        //exit(0);
        //QMessageBox::information(this, "错误", "截图失败，获取窗口失败");
        return;
    }
    //const char* processName = "your_process_name.exe"; // Replace with the actual process name  
    //HWND hwnd = FindMainWindowByProcessName(processName);


    // 获取屏幕设备的上下文
    HDC hScreenDC = GetWindowDC(hwnd);

    // 3. 获取窗口尺寸  
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) {
        //std::cerr << "无法获取窗口尺寸" << std::endl;
        //QMessageBox::information(this, "错误", "截图失败，无法获取窗口尺寸");
        ReleaseDC(hwnd, hScreenDC);
        return;
    }







    // 获取屏幕设备的上下文  
    //HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度  
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文  
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据  
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文  
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上  
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据  
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth  

    // 锁定位图的像素区域以便访问  
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB  
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中  
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道  
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像  
    cv::Mat grayScreenshot;
    cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源  
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    image = grayScreenshot;


    cv::imwrite("D:/0.png", image);
}

//图像检测函数，子矩阵
inline float f_mat(cv::Mat& image,int &res_y, short n, int x1, int y1, int x2, int y2)
{

    //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
    if (image.cols == 0)
    {
        return 0;
    }

    // 使用子矩阵功能来截取区域  
    cv::Mat src = image(cv::Rect(x1, y1, x2 - x1, y2 - y1));//浅拷贝


    //cv::Mat src = image;
    cv::Mat templ;

    cv::String filename;

    switch (n)
    {
    case 0: filename = "left.png";

        break;
    case 1: filename = "right.png";

        break;


    default:
        break;
    }
    cv::String file = "C:/PUBG_Project5/opencvImg/" + filename;
    templ = cv::imread(file, 0);




    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点
    cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);

    //std::cout << ptMaxLoc.x << std::endl << ptMaxLoc.y;

    //cv::imshow("image", src);
    //cv::waitKey(0);

    res_y = 420 + ptMaxLoc.y;

    /*std::cout<< dMaxVal<<std::endl;*/

    return dMaxVal;
}

//图像检测函数，子矩阵
inline float f_mark(cv::Mat& image,int &res_x, int& res_y, int x1, int y1, int x2, int y2)
{

    //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
    if (image.cols == 0)
    {
        return 0;
    }

    // 使用子矩阵功能来截取区域  
    cv::Mat src = image(cv::Rect(x1, y1, x2 - x1, y2 - y1));//浅拷贝


    //cv::Mat src = image;
    cv::Mat templ;

    cv::String filename;
    filename = "mark.png";

    cv::String file = "C:/PUBG_Project5/opencvImg/" + filename;
    templ = cv::imread(file, 0);




    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点
    cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);

    //std::cout << ptMaxLoc.x << std::endl << ptMaxLoc.y;

    //cv::imshow("image", src);
    //cv::waitKey(0);

    res_x = 1627 + ptMaxLoc.x + 8;

    res_y = 790 + ptMaxLoc.y + 21;

    /*std::cout<< dMaxVal<<std::endl;*/

    return dMaxVal;
}

inline float f_math(int x ,int y)
{
    int x0 = 1627 + 262 / 2;//中心点坐标，玩家坐标
    int y0 = 790 + 262 / 2;

    int Lx = x0 - x ;//两点差
    int Ly = y0 - y ;

    double L = sqrt((Lx * Lx) + (Ly * Ly));

    double n = 400 / static_cast<double>(262);//每1像素值对应米数

    return L * n;
}
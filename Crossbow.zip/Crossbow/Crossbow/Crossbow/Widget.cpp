﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);
}

Widget::~Widget()
{}

void Widget::getpush_RB(bool& push_RB)
{
    m_push_RB = &push_RB;
}

void Widget::getenemy_meter(float& enemy_meter)
{
    m_enemy_meter = &enemy_meter;
}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_Crossbow = new Crossbow;

        m_Crossbow->getpush_RB(*m_push_RB);

        m_Crossbow->getenemy_meter(*m_enemy_meter);

        m_Crossbow->startTimer();

        m_Crossbow->show();
    }
    else
    {
        m_Crossbow->stopTimer();
        m_Crossbow->close();
        delete m_Crossbow;
        m_Crossbow = nullptr;
    }
    return false;
}

﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include "Crossbow.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    bool* m_push_RB;
    Crossbow* m_Crossbow;
    float* m_enemy_meter;
public:
    void getpush_RB(bool& push_RB);
    void getenemy_meter(float& enemy_meter);
private slots:
    bool on_checkBox(bool checked);
};

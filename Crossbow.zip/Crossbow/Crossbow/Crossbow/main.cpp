﻿#include "Widget.h"
#include <QtWidgets/QApplication>

bool push_RB = false;

void f_RB()
{
	while (true)
	{
		GET_RB;
		while (GET_RB)
		{
			if (!push_RB)
			{
				S500
				push_RB = true;
			}
			GET_RB;
			S1
		}
		if (push_RB)
		{
			push_RB = false;
		}
		S1
	}
}

float enemy_meter = 0;
cv::Mat img;
int res_x, res_y;

void f_markMeter()
{
	
	while (true)
	{
		GET_RB;
		while (GET_RB)
		{
			f_scr(img, 1627, 790, 1627 + 262, 790 + 262);
			float mark = f_mark(img, res_x, res_y, 0, 0, 262, 262);
			if (mark>0.7)
			{
				enemy_meter = f_math(res_x, res_y);
			}
			else
			{
				enemy_meter = 0;
			}
			S100
		}
		S1
	}
}

int main(int argc, char *argv[])
{
	th th_f_RB(f_RB);
	th th_f_markMeter(f_markMeter);
    QApplication a(argc, argv);
    Widget w;
	w.getpush_RB(push_RB);
	w.getenemy_meter(enemy_meter);
    w.show();
    return a.exec();
}

﻿#include "Crossbow.h"

Crossbow::Crossbow(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setAttribute(Qt::WA_TranslucentBackground);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &Crossbow::updateWidget);
    resize(1920, 1080);
   
}

Crossbow::~Crossbow()
{}

void Crossbow::getpush_RB(bool& m_push_RB)
{
	push_RB = &m_push_RB;
}

void Crossbow::paintEvent(QPaintEvent* event)
{
    if (*push_RB)
    {
        QPainter painter(this);
        painter.setPen(Qt::white);
        QFont font1;
        font1.setPointSizeF(15);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        //painter.drawText(960, res_y, "VS的C");

        QFont meter_rank;
        font1.setPointSizeF(7);
        painter.setFont(meter_rank);
        painter.setBrush(Qt::NoBrush);
        

        int max = 4;//字体误差

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 14, 960 + 100, res_y + 14);/*     40m*///painter.drawText(960 + 100, res_y + 14, "米");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y + 25, 960 + 100, res_y + 25);/*     50m*/painter.drawText(960 + 100, res_y + 25 + max, "50");
        
        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 36, 960 + 20, res_y + 36);/*      60m*/painter.drawText(960 + 20, res_y + 36 + max, "60");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y + 51, 960 + 40, res_y + 51);/*      70m*/painter.drawText(960 + 40, res_y + 51 + max, "70");

        painter.drawLine(960, res_y + 68, 960 + 60, res_y + 68);/*      80m*/painter.drawText(960 + 60, res_y + 68 + max, "80");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 82, 960 + 80, res_y + 82);/*      90m*/painter.drawText(960 + 80, res_y + 82 + max, "90");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y + 96, 960 + 130, res_y + 96);/*     100m*/painter.drawText(960 + 130, res_y + 96 + max, "100");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 113, 960 + 20, res_y + 113);/*    110m*/painter.drawText(960 + 20, res_y + 113 + max, "110");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y + 127, 960 + 40, res_y + 127);/*    120m*/painter.drawText(960 + 40, res_y + 127 + max, "120");

        painter.drawLine(960, res_y + 144, 960 + 60, res_y + 144);/*    130m*/painter.drawText(960 + 60, res_y + 144 + max, "130");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 161, 960 + 80, res_y + 161);/*    140m*/painter.drawText(960 + 80, res_y + 161 + max, "140");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y + 177, 960 + 100, res_y + 177);/*   150m*/painter.drawText(960 + 100, res_y + 177 + max, "150");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 190, 960 + 20, res_y + 190);/*    160m*/painter.drawText(960 + 20, res_y + 190 + max, "160");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y + 205, 960 + 40, res_y + 205);/*    170m*/painter.drawText(960 + 40, res_y + 205 + max, "170");

        painter.drawLine(960, res_y + 221, 960 + 60, res_y + 221);/*    180m*/painter.drawText(960 + 60, res_y + 221 + max, "180");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y + 237, 960 + 80, res_y + 237);/*    190m*/painter.drawText(960 + 80, res_y + 237 + max, "190");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y + 253, 960 + 130, res_y + 253);/*   200m*/painter.drawText(960 + 130, res_y + 253 + max, "200");
    }
}

void Crossbow::startTimer()
{
	m_timer->start(33);
}

void Crossbow::stopTimer()
{
	m_timer->stop();
}

void Crossbow::updateWidget()
{
    if (*push_RB)
    {

        f_scr(IMG, 630, 420, 950, 600);
        float left = f_mat(IMG, res_y,0, 0, 0, 950 - 630, 600 - 420);

        if (left<0.6)
        {
            res_y = 540;
        }

        update();

    }
    else
    {
        update();
    }
}

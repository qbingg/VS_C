﻿#include "Crossbow.h"

Crossbow::Crossbow(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setAttribute(Qt::WA_TranslucentBackground);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &Crossbow::updateWidget);
    resize(1920, 1080);
   
}

Crossbow::~Crossbow()
{}

void Crossbow::getpush_RB(bool& m_push_RB)
{
	push_RB = &m_push_RB;
}

void Crossbow::getuse_6x(bool& m_use_6x)
{
    use_6x = &m_use_6x;
}

void Crossbow::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);
    if ((*push_RB) && (*use_6x))//6倍
    {

        painter.setPen(Qt::white);
        QFont font1;
        font1.setPointSizeF(15);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        //painter.drawText(960, res_y, "VS的C");

        QFont meter_rank;
        font1.setPointSizeF(7);
        painter.setFont(meter_rank);
        painter.setBrush(Qt::NoBrush);
        //painter.drawText(960, res_y, "米");

        int max = 4;//字体误差

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 14, 960 + 100, res_y_6 + 14);/*     40m*///painter.drawText(960 + 100, res_y + 14, "米");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y_6 + 25, 960 + 100, res_y_6 + 25);/*     50m*/painter.drawText(960 + 100, res_y_6 + 25 + max, "50");
        
        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 36, 960 + 20, res_y_6 + 36);/*      60m*/painter.drawText(960 + 20, res_y_6 + 36 + max, "60");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_6 + 51, 960 + 40, res_y_6 + 51);/*      70m*/painter.drawText(960 + 40, res_y_6 + 51 + max, "70");

        painter.drawLine(960, res_y_6 + 68, 960 + 60, res_y_6 + 68);/*      80m*/painter.drawText(960 + 60, res_y_6 + 68 + max, "80");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 82, 960 + 80, res_y_6 + 82);/*      90m*/painter.drawText(960 + 80, res_y_6 + 82 + max, "90");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y_6 + 96, 960 + 130, res_y_6 + 96);/*     100m*/painter.drawText(960 + 130, res_y_6 + 96 + max, "100");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 113, 960 + 20, res_y_6 + 113);/*    110m*/painter.drawText(960 + 20, res_y_6 + 113 + max, "110");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_6 + 127, 960 + 40, res_y_6 + 127);/*    120m*/painter.drawText(960 + 40, res_y_6 + 127 + max, "120");

        painter.drawLine(960, res_y_6 + 144, 960 + 60, res_y_6 + 144);/*    130m*/painter.drawText(960 + 60, res_y_6 + 144 + max, "130");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 161, 960 + 80, res_y_6 + 161);/*    140m*/painter.drawText(960 + 80, res_y_6 + 161 + max, "140");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y_6 + 177, 960 + 100, res_y_6 + 177);/*   150m*/painter.drawText(960 + 100, res_y_6 + 177 + max, "150");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 190, 960 + 20, res_y_6 + 190);/*    160m*/painter.drawText(960 + 20, res_y_6 + 190 + max, "160");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_6 + 205, 960 + 40, res_y_6 + 205);/*    170m*/painter.drawText(960 + 40, res_y_6 + 205 + max, "170");

        painter.drawLine(960, res_y_6 + 221, 960 + 60, res_y_6 + 221);/*    180m*/painter.drawText(960 + 60, res_y_6 + 221 + max, "180");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 237, 960 + 80, res_y_6 + 237);/*    190m*/painter.drawText(960 + 80, res_y_6 + 237 + max, "190");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y_6 + 253, 960 + 130, res_y_6 + 253);/*   200m*/painter.drawText(960 + 130, res_y_6 + 253 + max, "200");



        
    }

    else if ((*push_RB) && !(*use_6x))//4倍
    {
        //double k = static_cast<double>(9) / (16);

        //计算放大镜中心点
        int xm = (1920 / 2);
        int ym = (1080 / 2);

        //计算截图a点
        int xa = xm - 272;
        //int ya = ym - ((k) * (600));
        int ya = ym - 338;

        //计算截图b点
        int xb = xm + 272;
        //int yb = ym + ((k) * (600));
        int yb = ym + 338;


        Magnify_Screen(xa, ya, xb, yb);

        QImage qimg = QImage((const unsigned char*)(Image_4x.data), Image_4x.cols, Image_4x.rows,
            Image_4x.step, QImage::Format_RGB888).rgbSwapped();

        int imageWidth = qimg.width();
        int imageHeight = qimg.height();
        int windowWidth = this->width();
        int windowHeight = this->height();


        int x = ((windowWidth - imageWidth) / 2);
        int y = (windowHeight - imageHeight) / 2;

        painter.drawImage(x, y, qimg);


    }

    ////画圈
    //if (*use_6x)//6倍
    //{
    //    int mapX = 1627 + 262 / 2;//小地图中心坐标
    //    int mapY = 790 + 262 / 2;//小地图中心坐标

    //    //int centerX = f(0);
    //    //int centerY = f(0);
    //    int R = (262 / (4) / 2);
    //    int radius = (262 / (4));
    //    //int r = meter_To_Pixel(50);
    //    //painter.setPen(QPen(Qt::green, 1));
    //    //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    int r = meter_To_Pixel(100);
    //    painter.setPen(QPen(Qt::green, 2));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(150);
    //    painter.setPen(QPen(Qt::green, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(200);
    //    painter.setPen(QPen(Qt::green, 2));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);



    //    //for (int i = 2; i <= 14; i++)
    //    //{
    //    //    if (i == 2)
    //    //    {
    //    //        int startAngle = 0 * 16;  
    //    //        int spanAngle = 360 * 16;  
    //    //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
    //    //        painter.setPen(QPen(Qt::green, 2));
    //    //        painter.setBrush(Qt::NoBrush); 
    //    //        painter.drawArc(arcRect, startAngle, spanAngle);
    //    //    }
    //    //    else
    //    //    {
    //    //        radius = i * R;
    //    //        if (i % 2 == 0)
    //    //        {
    //    //            painter.setPen(QPen(Qt::green, 2));
    //    //            painter.setBrush(Qt::NoBrush);
    //    //        }
    //    //        else
    //    //        {
    //    //            painter.setPen(QPen(Qt::black, 1));
    //    //            painter.setBrush(Qt::NoBrush);
    //    //        }
    //    //        int startAngle = 0 * 16; 
    //    //        int spanAngle = 360 * 16;  
    //    //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius); 
    //    //        painter.drawArc(arcRect, startAngle, spanAngle);
    //    //    }
    //    //}
    //    painter.setCompositionMode(QPainter::CompositionMode_Clear);
    //    painter.setPen(QPen(Qt::green, 25));
    //    painter.drawLine(0, 0, 262, 262);
    //    painter.drawLine(0, 262, 262, 0);
    //    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    //    painter.setPen(Qt::green);
    //    QFont font1;
    //    font1.setPointSizeF(7);
    //    painter.setFont(font1);
    //    painter.setBrush(Qt::NoBrush);
    //    int min = 7;
    //    int min2 = 5;
    //    int max = 5;
    //    painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
    //    painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
    //    painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
    //    //painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
    //    painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
    //    painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
    //    painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
    //    painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");
    //    painter.setPen(Qt::yellow);
    //    painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
    //    painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
    //    painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
    //    //painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
    //    painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
    //    painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
    //    painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
    //    painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");
    //    painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
    //    painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
    //    painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
    //    //painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
    //    painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
    //    painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
    //    painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
    //    painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");
    //    painter.setPen(Qt::green);
    //    painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
    //    painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
    //    painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
    //    //painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
    //    painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
    //    painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
    //    painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
    //    painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");
    //    //r = meter_To_Pixel(75);
    //    //painter.setPen(QPen(Qt::white, 0.5));
    //    //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(40);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(50);
    //    painter.setPen(QPen(Qt::green, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(60);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(70);
    //    painter.setPen(QPen(Qt::white, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(80);
    //    painter.setPen(QPen(Qt::white, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(90);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //    r = meter_To_Pixel(110);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(120);
    //    painter.setPen(QPen(Qt::white, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(130);
    //    painter.setPen(QPen(Qt::white, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(140);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //    r = meter_To_Pixel(160);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(170);
    //    painter.setPen(QPen(Qt::white, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(180);
    //    painter.setPen(QPen(Qt::white, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //    r = meter_To_Pixel(190);
    //    painter.setPen(QPen(Qt::black, 1));
    //    painter.drawArc(mapX + f(0) - r, mapY + f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);
    //}
    //else//4倍
    //{

    //}
}

void Crossbow::startTimer()
{
	m_timer->start(17);
}

void Crossbow::stopTimer()
{
	m_timer->stop();
}

void Crossbow::updateWidget()
{
    if (*push_RB)
    {

        function_screenGray(IMG, 630, 420, 950, 600);
        float n6 = function_matchTemplate(IMG, res_y_6,0, 0, 0, 950 - 630, 600 - 420);//6倍镜
        float n4 = function_matchTemplate(IMG, res_y_4, 1, 0, 0, 950 - 630, 600 - 420);//4倍镜

        if (*use_6x && (n6 < 0.6))//6倍镜
        {
            res_y_6 = 540;
        }
        else if((n4 < 0.6))//4倍镜
        {

        }

        update();

    }
    else
    {
        update();
    }
}

void Crossbow::Magnify_Screen(int x1, int y1, int x2, int y2)
{
    LPCWSTR str = PUBGWINDOWNAME;
    HWND hwnd = FindWindowW(NULL, str);
    HDC hScreenDC = GetWindowDC(hwnd);
    RECT rect;
    if (!GetWindowRect(hwnd, &rect))
    {
        ReleaseDC(hwnd, hScreenDC);
        return;
    }
    int width = x2 - x1;
    int height = y2 - y1;


    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);
    cv::Mat screenshot(height, width, CV_8UC4);
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height;
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);


    //int n = sqrt(2.5);
    float n = 1.581;
    cv::Size newSize(screenshot.cols * n, screenshot.rows * n);

    cv::Mat resizedImg;

    cv::resize(screenshot, resizedImg, newSize, 0, 0, cv::INTER_LINEAR);
    Image_4x = resizedImg;
}





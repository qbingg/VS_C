﻿#pragma once

#include <QWidget>
#include "ui_Crossbow.h"
#include "VS_C.h"

class Crossbow : public QWidget
{
	Q_OBJECT

public:
	Crossbow(QWidget *parent = nullptr);
	~Crossbow();

private:
	Ui::CrossbowClass ui;
	bool* push_RB;
	bool* use_6x;
	cv::Mat IMG;
	cv::Mat Image_4x;
	int res_y_6;
	int res_y_4;

public:
	void getpush_RB(bool& m_push_RB);
	void getuse_6x(bool& m_use_6x);
	void Magnify_Screen(int x1, int y1, int x2, int y2);
private:
	QTimer* m_timer;
private slots:
	void updateWidget();
public:
	void paintEvent(QPaintEvent* event);
	void startTimer();
	void stopTimer();



};

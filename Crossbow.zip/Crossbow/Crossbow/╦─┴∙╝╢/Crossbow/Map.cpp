#include "Map.h"

Map::Map(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);



	m_timer = new QTimer(this);
	connect(m_timer, &QTimer::timeout, this, &Map::updateWidget);
}

Map::~Map()
{}

void Map::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
	if (*use_6x)
	{


        int centerX = f(0);
        int centerY = f(0);
        int R = (262 / (4) / 2);
        int radius = (262 / (4));
        //int r = meter_To_Pixel(50);
        //painter.setPen(QPen(Qt::green, 1));
        //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        int r = meter_To_Pixel(100);
        painter.setPen(QPen(Qt::green, 2));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(150);
        painter.setPen(QPen(Qt::green, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(200);
        painter.setPen(QPen(Qt::green, 2));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);



        //for (int i = 2; i <= 14; i++)
        //{
        //    if (i == 2)
        //    {
        //        int startAngle = 0 * 16;  
        //        int spanAngle = 360 * 16;  
        //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
        //        painter.setPen(QPen(Qt::green, 2));
        //        painter.setBrush(Qt::NoBrush); 
        //        painter.drawArc(arcRect, startAngle, spanAngle);
        //    }
        //    else
        //    {
        //        radius = i * R;
        //        if (i % 2 == 0)
        //        {
        //            painter.setPen(QPen(Qt::green, 2));
        //            painter.setBrush(Qt::NoBrush);
        //        }
        //        else
        //        {
        //            painter.setPen(QPen(Qt::black, 1));
        //            painter.setBrush(Qt::NoBrush);
        //        }
        //        int startAngle = 0 * 16; 
        //        int spanAngle = 360 * 16;  
        //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius); 
        //        painter.drawArc(arcRect, startAngle, spanAngle);
        //    }
        //}
        painter.setCompositionMode(QPainter::CompositionMode_Clear);
        painter.setPen(QPen(Qt::green, 25));
        painter.drawLine(0, 0, 262, 262);
        painter.drawLine(0, 262, 262, 0);
        painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
        painter.setPen(Qt::green);
        QFont font1;
        font1.setPointSizeF(7);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        int min = 7;
        int min2 = 5;
        int max = 5;
        painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
        painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
        painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
        //painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
        painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
        painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
        painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
        painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");
        painter.setPen(Qt::yellow);
        painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
        painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
        painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
        //painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
        painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
        painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
        painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
        painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");
        painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
        painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
        painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
        //painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
        painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
        painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
        painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
        painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");
        painter.setPen(Qt::green);
        painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
        painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
        painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
        //painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
        painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
        painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
        painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
        painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");
        //r = meter_To_Pixel(75);
        //painter.setPen(QPen(Qt::white, 0.5));
        //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(40);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(50);
        painter.setPen(QPen(Qt::green, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(60);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(70);
        painter.setPen(QPen(Qt::white, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(80);
        painter.setPen(QPen(Qt::white, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(90);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


        r = meter_To_Pixel(110);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(120);
        painter.setPen(QPen(Qt::white, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(130);
        painter.setPen(QPen(Qt::white, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(140);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


        r = meter_To_Pixel(160);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(170);
        painter.setPen(QPen(Qt::white, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(180);
        painter.setPen(QPen(Qt::white, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

        r = meter_To_Pixel(190);
        painter.setPen(QPen(Qt::black, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);
	}
	else
	{

	}
}

void Map::startTimer()
{
	m_timer->start(1000);
}

void Map::stopTimer()
{
	m_timer->stop();
}

void Map::updateWidget()
{
    if (*use_6x)
    {
        resize(262, 262);
        move(1627, 790);
        update();
    }

}

void Map::getuse_6x(bool& m_use_6x)
{
	use_6x = &m_use_6x;
}
#pragma once

#include <QWidget>
#include "ui_Map.h"
#include "VS_C.h"

class Map : public QWidget
{
	Q_OBJECT

public:
	Map(QWidget *parent = nullptr);
	~Map();
	void paintEvent(QPaintEvent* event);
	void startTimer();
	void stopTimer();
	void getuse_6x(bool& m_use_6x);
private:
	Ui::MapClass ui;
	bool* use_6x;
	QTimer* m_timer;
private slots:
	void updateWidget();
};

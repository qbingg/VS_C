﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);




}

Widget::~Widget()
{}

void Widget::getpush_RB(bool& push_RB)
{
    m_push_RB = &push_RB;
}

void Widget::getuse_6x(bool& use_6x)
{
    m_use_6x = &use_6x;
}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_Crossbow = new Crossbow;

        m_Crossbow->getpush_RB(*m_push_RB);

        m_Crossbow->getuse_6x(*m_use_6x);

        m_Crossbow->startTimer();

        m_Crossbow->show();



        m_Map = new Map;

        m_Map->getuse_6x(*m_use_6x);

        m_Map->startTimer();

        m_Map->show();
    }
    else
    {
        m_Crossbow->stopTimer();
        m_Crossbow->close();
        delete m_Crossbow;
        m_Crossbow = nullptr;

        m_Map->stopTimer();
        m_Map->close();
        delete m_Map;
        m_Map = nullptr;
    }
    return false;
}

﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include "Crossbow.h"
#include "Map.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    bool* m_push_RB;
    bool* m_use_6x;
    Crossbow* m_Crossbow;
    Map* m_Map;
public:
    void getpush_RB(bool& push_RB);
    void getuse_6x(bool& use_6x);
private slots:
    bool on_checkBox(bool checked);
};

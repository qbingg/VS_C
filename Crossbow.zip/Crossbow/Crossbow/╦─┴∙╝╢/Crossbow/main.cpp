﻿#include "Widget.h"
#include <QtWidgets/QApplication>

bool push_RB = false;

void f_RB()//按着右键
{
	while (true)
	{
		GET_RB;
		while (GET_RB)
		{
			S100
			GET_RB;
			if (GET_RB)
			{
				if (!push_RB)
				{
						push_RB = true;
				}
				S1;
			}
			GET_RB;
			S1
		}
		if (push_RB)
		{
			push_RB = false;
		}
		S1
	}
}

bool use_6x = true;//小地图默认是小的，所以默认6倍。真6，假4

void f_change()
{
	while (true)
	{
		GET_MAP;
		if (GET_MAP)
		{
			if (use_6x)
			{
				use_6x = false;
			}
			else
			{
				use_6x = true;
			}
			S300
		}
		S1
	}
}



int main(int argc, char *argv[])
{
	th th_f_RB(f_RB);
	th th_f_change(f_change);
    QApplication a(argc, argv);
    Widget w;
	w.getpush_RB(push_RB);
	w.getuse_6x(use_6x);
    w.show();
    return a.exec();
}

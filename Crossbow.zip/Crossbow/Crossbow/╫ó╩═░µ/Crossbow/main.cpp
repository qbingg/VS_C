﻿#include "Widget.h"
#include <QtWidgets/QApplication>

bool push_RB = false;

void f_RB()
{
	while (true)
	{
		GET_RB;
		while (GET_RB)
		{
			if (!push_RB)
			{
				S500
				push_RB = true;
			}
			GET_RB;
			S1
		}
		if (push_RB)
		{
			push_RB = false;
		}
		S1
	}
}



int main(int argc, char *argv[])
{
	th th_f_RB(f_RB);
    QApplication a(argc, argv);
    Widget w;
	w.getpush_RB(push_RB);
    w.show();
    return a.exec();
}

﻿#include "Crossrow.h"

Crossrow::Crossrow(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setAttribute(Qt::WA_TranslucentBackground);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &Crossrow::updateWidget);
    resize(1920, 1080);

}

Crossrow::~Crossrow()
{}

void Crossrow::getpush_RB(bool& m_push_RB)
{
    push_RB = &m_push_RB;
}

void Crossrow::startTimer()
{
    m_timer->start(17);
}

void Crossrow::stopTimer()
{
    m_timer->stop();
}

void Crossrow::updateWidget()
{
    if ((*push_RB) && (*use_6x))//6倍
    {

        function_screenGray(IMG, 630, 420, 950, 600);
        float n6 = function_matchTemplate(IMG, res_y_6, 0, 0, 0, 950 - 630, 600 - 420);

        if (n6 < 0.3)
        {
            res_y_6 = 540;
        }

        update();

    }
    else if ((*push_RB) && !(*use_6x))//4倍
    {
        //function_screenGray(IMG, 630, 420, 950, 600);
        //float n4 = function_matchTemplate(IMG, res_y_4, 1, 0, 0, 950 - 630, 600 - 420);//4倍镜
        function_screenGray(IMG, 610, 500, 750, 550);
        float n4 = function_matchTemplate(IMG, res_y_4, 1, 0, 0, 750 - 610, 550 - 500);//4倍镜



        //res_y_4 = 420 + (res_y_4 - 420) * 1.581;
        //res_y_4 = 540 + (res_y_4 - 540) * 1.581;
        res_y_4 = 540 + ((res_y_4 + (500 - 420)) - 540) * 1.581;

        function_screenGray(IMG, 830, 130, 1070, 300);
        float n4_top = function_matchTemplate(IMG, res_y_4_top, 3, 0, 0, 1070 - 830, 300 - 130);//4倍镜
        res_y_4_top = 540 + ((res_y_4_top + (130 - 420)+315) - 540) * 1.581;


        // res_y_4 = res_y_4_top;


        if (n4 < n4_top)
        {
            //res_y_4 = 540;
            res_y_4 = res_y_4_top;

        }


        update();
    }
    else
    {
        update();
    }
}

void Crossrow::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);
    if ((*push_RB) && (*use_6x))//6倍
    {

        painter.setPen(Qt::white);
        QFont font1;
        font1.setPointSizeF(15);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        painter.drawText(960, res_y_6, "VS的C");

        QFont meter_rank;
        font1.setPointSizeF(7);
        painter.setFont(meter_rank);
        painter.setBrush(Qt::NoBrush);
        //painter.drawText(960, res_y, "米");

        int max = 4;//字体误差

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 14, 960 + 100, res_y_6 + 14);/*     40m*///painter.drawText(960 + 100, res_y + 14, "米");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y_6 + 25, 960 + 100, res_y_6 + 25);/*     50m*/painter.drawText(960 + 100, res_y_6 + 25 + max, "50");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 36, 960 + 20, res_y_6 + 36);/*      60m*/painter.drawText(960 + 20, res_y_6 + 36 + max, "60");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_6 + 51, 960 + 40, res_y_6 + 51);/*      70m*/painter.drawText(960 + 40, res_y_6 + 51 + max, "70");

        painter.drawLine(960, res_y_6 + 68, 960 + 60, res_y_6 + 68);/*      80m*/painter.drawText(960 + 60, res_y_6 + 68 + max, "80");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 82, 960 + 80, res_y_6 + 82);/*      90m*/painter.drawText(960 + 80, res_y_6 + 82 + max, "90");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y_6 + 96, 960 + 130, res_y_6 + 96);/*     100m*/painter.drawText(960 + 130, res_y_6 + 96 + max, "100");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 113, 960 + 20, res_y_6 + 113);/*    110m*/painter.drawText(960 + 20, res_y_6 + 113 + max, "110");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_6 + 127, 960 + 40, res_y_6 + 127);/*    120m*/painter.drawText(960 + 40, res_y_6 + 127 + max, "120");

        painter.drawLine(960, res_y_6 + 144, 960 + 60, res_y_6 + 144);/*    130m*/painter.drawText(960 + 60, res_y_6 + 144 + max, "130");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 161, 960 + 80, res_y_6 + 161);/*    140m*/painter.drawText(960 + 80, res_y_6 + 161 + max, "140");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y_6 + 177, 960 + 100, res_y_6 + 177);/*   150m*/painter.drawText(960 + 100, res_y_6 + 177 + max, "150");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 190, 960 + 20, res_y_6 + 190);/*    160m*/painter.drawText(960 + 20, res_y_6 + 190 + max, "160");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_6 + 205, 960 + 40, res_y_6 + 205);/*    170m*/painter.drawText(960 + 40, res_y_6 + 205 + max, "170");

        painter.drawLine(960, res_y_6 + 221, 960 + 60, res_y_6 + 221);/*    180m*/painter.drawText(960 + 60, res_y_6 + 221 + max, "180");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_6 + 237, 960 + 80, res_y_6 + 237);/*    190m*/painter.drawText(960 + 80, res_y_6 + 237 + max, "190");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y_6 + 253, 960 + 130, res_y_6 + 253);/*   200m*/painter.drawText(960 + 130, res_y_6 + 253 + max, "200");




    }

    else if ((*push_RB) && !(*use_6x))//4倍
    {
        //double k = static_cast<double>(9) / (16);

        //计算放大镜中心点
        int xm = (1920 / 2);
        int ym = (1080 / 2);

        //计算截图a点
        int xa = xm - 272;
        //int ya = ym - ((k) * (600));
        int ya = ym - 338;

        //计算截图b点
        int xb = xm + 272;
        //int yb = ym + ((k) * (600));
        int yb = ym + 338;


        Magnify_Screen(xa, ya, xb, yb);

        QImage qimg = QImage((const unsigned char*)(Image_4x.data), Image_4x.cols, Image_4x.rows,
            Image_4x.step, QImage::Format_RGB888).rgbSwapped();

        int imageWidth = qimg.width();
        int imageHeight = qimg.height();
        int windowWidth = this->width();
        int windowHeight = this->height();


        int x = ((windowWidth - imageWidth) / 2);
        int y = (windowHeight - imageHeight) / 2;

        painter.drawImage(x, y, qimg);

        /////////////////////////////////////////////
        

        painter.setPen(Qt::white);
        QFont font1;
        font1.setPointSizeF(15);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        painter.drawText(960, res_y_4, "VS的C 4倍镜");


        QFont meter_rank;
        font1.setPointSizeF(7);
        painter.setFont(meter_rank);
        painter.setBrush(Qt::NoBrush);
        //painter.drawText(960, res_y, "米");

        int max = 4;//字体误差

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 16, 960 + 100, res_y_4 + 16);/*     40m*///painter.drawText(960 + 100, res_y + 14, "米");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y_4 + 28, 960 + 100, res_y_4 + 28);/*     50m*/painter.drawText(960 + 100, res_y_4 + 28 + max, "50");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 42, 960 + 20, res_y_4 + 42);/*     60m*/painter.drawText(960 + 20, res_y_4 + 42 + max, "60");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_4 + 61, 960 + 40, res_y_4 + 61);/*     70m*/painter.drawText(960 + 40, res_y_4 + 61 + max, "70");

        painter.drawLine(960, res_y_4 + 77, 960 + 60, res_y_4 + 77);/*     80m*/painter.drawText(960 + 60, res_y_4 + 77 + max, "80");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 95, 960 + 80, res_y_4 + 95);/*     90m*/painter.drawText(960 + 80, res_y_4 + 95 + max, "90");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y_4 + 111, 960 + 120, res_y_4 + 111);/*     100m*/painter.drawText(960 + 120, res_y_4 + 111 + max, "100");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 127, 960 + 20, res_y_4 + 127);/*     110*/painter.drawText(960 + 20, res_y_4 + 127 + max, "110");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_4 + 145, 960 + 40, res_y_4 + 145);/*     120m*/painter.drawText(960 + 40, res_y_4 + 145 + max, "120");

        painter.drawLine(960, res_y_4 + 161, 960 + 60, res_y_4 + 161);/*     130*/painter.drawText(960 + 60, res_y_4 + 161 + max, "130");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 180, 960 + 80, res_y_4 + 180);/*     140*/painter.drawText(960 + 80, res_y_4 + 180 + max, "140");

        painter.setPen(QPen(Qt::green, 1));

        painter.drawLine(960, res_y_4 + 196, 960 + 80, res_y_4 + 196);/*     150*/painter.drawText(960 + 100, res_y_4 + 196 + max, "150");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 212, 960 + 20, res_y_4 + 212);/*     160*/painter.drawText(960 + 20, res_y_4 + 212 + max, "160");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_4 + 230, 960 + 40, res_y_4 + 230);/*     170*/painter.drawText(960 + 40, res_y_4 + 230 + max, "170");

        painter.drawLine(960, res_y_4 + 247, 960 + 60, res_y_4 + 247);/*     180*/painter.drawText(960 + 60, res_y_4 + 247 + max, "180");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 266, 960 + 80, res_y_4 + 266);/*     190*/painter.drawText(960 + 80, res_y_4 + 266 + max, "190");

        painter.setPen(QPen(Qt::green, 2));

        painter.drawLine(960, res_y_4 + 283, 960 + 120, res_y_4 + 283);/*     200*/painter.drawText(960 + 120, res_y_4 + 283 + max, "200");


        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 301, 960 + 20, res_y_4 + 301);/*     210*/painter.drawText(960 + 20, res_y_4 + 301 + max, "210");

        painter.setPen(QPen(Qt::yellow, 1));

        painter.drawLine(960, res_y_4 + 319, 960 + 40, res_y_4 + 319);/*     220m*/painter.drawText(960 + 40, res_y_4 + 319 + max, "220");

        painter.drawLine(960, res_y_4 + 336, 960 + 60, res_y_4 + 336);/*     230*/painter.drawText(960 + 60, res_y_4 + 336 + max, "230");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 353, 960 + 80, res_y_4 + 353);/*     240*/painter.drawText(960 + 80, res_y_4 + 353 + max, "240");

        painter.setPen(QPen(Qt::red, 1));

        painter.drawLine(960, res_y_4 + 372, 960 + 80, res_y_4 + 372);/*     250*/painter.drawText(960 + 100, res_y_4 + 372 + max, "250");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 388, 960 + 20, res_y_4 + 388);/*     260*/painter.drawText(960 + 20, res_y_4 + 388 + max, "260");

        painter.setPen(QPen(Qt::yellow, 1));

        painter.drawLine(960, res_y_4 + 402, 960 + 40, res_y_4 + 402);/*     270*/painter.drawText(960 + 40, res_y_4 + 402 + max, "270");

        painter.drawLine(960, res_y_4 + 421, 960 + 60, res_y_4 + 421);/*     280*/painter.drawText(960 + 60, res_y_4 + 421 + max, "280");

        painter.setPen(QPen(Qt::black, 1));

        painter.drawLine(960, res_y_4 + 440, 960 + 80, res_y_4 + 440);/*     290*/painter.drawText(960 + 80, res_y_4 + 440 + max, "290");


        painter.setPen(QPen(Qt::red, 1));

        painter.drawLine(960, res_y_4 + 460, 960 + 120, res_y_4 + 460);/*     300*/painter.drawText(960 + 120, res_y_4 + 460 + max, "300");

        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(960, res_y_4 + 479, 960 + 20, res_y_4 + 479);/*     310*/painter.drawText(960 + 20, res_y_4 + 479 + max, "310");


    }


}

void Crossrow::getuse_6x(bool& m_use_6x)
{
    use_6x = &m_use_6x;
}

void Crossrow::Magnify_Screen(int x1, int y1, int x2, int y2)
{
    LPCWSTR str = PUBGWINDOWNAME;
    HWND hwnd = FindWindowW(NULL, str);
    HDC hScreenDC = GetWindowDC(hwnd);
    RECT rect;
    if (!GetWindowRect(hwnd, &rect))
    {
        ReleaseDC(hwnd, hScreenDC);
        return;
    }
    int width = x2 - x1;
    int height = y2 - y1;


    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);
    cv::Mat screenshot(height, width, CV_8UC4);
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height;
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);


    //int n = sqrt(2.5);
    float n = 1.581;
    cv::Size newSize(screenshot.cols * n, screenshot.rows * n);

    cv::Mat resizedImg;

    cv::resize(screenshot, resizedImg, newSize, 0, 0, cv::INTER_LINEAR);
    Image_4x = resizedImg;
}
﻿#pragma once

#include <QWidget>
#include "ui_Crossrow.h"
#include "VS_C.h"

class Crossrow : public QWidget
{
	Q_OBJECT

public:
	Crossrow(QWidget *parent = nullptr);
	~Crossrow();

private:
	Ui::CrossrowClass ui;
	bool* push_RB;
public:
	void getpush_RB(bool& m_push_RB);
private:
	QTimer* m_timer;
private slots:
	void updateWidget();
public:
	void paintEvent(QPaintEvent* event);
	void startTimer();
	void stopTimer();


private:
	bool* use_6x;
	cv::Mat IMG;//倍镜中心图像检测
	cv::Mat Image_4x;
	int res_y_6;
	int res_y_4;
	int res_y_4_top;
public:
	void getuse_6x(bool& m_use_6x);
	void Magnify_Screen(int x1, int y1, int x2, int y2);
};

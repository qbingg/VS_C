﻿#include "Map4.h"

Map4::Map4(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);

	resize(460, 460);

}

Map4::~Map4()
{}

void Map4::paintEvent(QPaintEvent* event)
{
    //QPainter painter(this);

    //// 圆弧的参数  
    //int centerX = f(0); // 圆心x坐标  
    //int centerY = f(0); // 圆心y坐标  
    //int R = (462 / (7) / 2);//50米对应像素
    //int radius = (462 / (7));  // 半径  (默认100米)

    //int r = meter_To_Pixel(50);
    //painter.setPen(QPen(Qt::black, 1));
    //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //for (int i = 2; i <= 14; i++)//100、150、200、250、300、350、400、450、500、550、600、650、700   十三个环
    //{
    //    if (i == 2)//第一环不用操作
    //    {
    //        int startAngle = 0 * 16;  // 起始角度，以1/16度为单位（45度 * 16）  
    //        int spanAngle = 360 * 16;  // 跨越角度，以1/16度为单位（180度 * 16）  
    //        // 绘制圆弧的矩形边界  
    //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

    //        // 设置画笔  
    //        painter.setPen(QPen(Qt::green, 2));
    //        painter.setBrush(Qt::NoBrush);

    //        // 绘制圆弧  
    //        painter.drawArc(arcRect, startAngle, spanAngle);
    //    }
    //    else
    //    {
    //        //获取半径
    //        radius = i * R;
    //        //获取颜色（单黄/偶红）
    //        if (i % 2 == 0)
    //        {//偶数
    //            // 设置画笔  
    //            painter.setPen(QPen(Qt::green, 2));
    //            painter.setBrush(Qt::NoBrush);
    //        }
    //        else
    //        {
    //            // 设置画笔  
    //            painter.setPen(QPen(Qt::black, 1));
    //            painter.setBrush(Qt::NoBrush);
    //        }


    //        int startAngle = 0 * 16;  // 起始角度，以1/16度为单位（45度 * 16）  
    //        int spanAngle = 360 * 16;  // 跨越角度，以1/16度为单位（180度 * 16）  

    //        // 绘制圆弧的矩形边界  
    //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

    //        // 绘制圆弧  
    //        painter.drawArc(arcRect, startAngle, spanAngle);


    //    }


    //}

    ////擦去圆弧
    //painter.setCompositionMode(QPainter::CompositionMode_Clear);//清除模式
    //painter.setPen(QPen(Qt::green, 25));
    ////painter.setBrush(QColor(0, 0, 0, 0));
    //painter.drawLine(0, 0, 462, 462);
    //painter.drawLine(0, 462, 462, 0);
    ////painter.drawEllipse(f(0), f(0), F(100), F(100));

    ////画标尺
    //painter.setCompositionMode(QPainter::CompositionMode_SourceOver);//返回默认模式
    //painter.setPen(Qt::white);
    //QFont font1;
    //font1.setPointSizeF(7);
    //painter.setFont(font1);
    //painter.setBrush(Qt::NoBrush);

    //int min = 7;//减去字体误差
    //int min2 = 5;
    //int max = 5;

    ////第4象限
    //painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
    //painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
    //painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
    //painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
    //painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
    //painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
    //painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
    //painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");

    ////第3象限
    //painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
    //painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
    //painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
    //painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
    //painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
    //painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
    //painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
    //painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");

    ////第1象限
    //painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
    //painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
    //painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
    //painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
    //painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
    //painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
    //painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
    //painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");

    ////第2象限
    //painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
    //painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
    //painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
    //painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
    //painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
    //painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
    //painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
    //painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");


    //r = meter_To_Pixel(75);
    //painter.setPen(QPen(Qt::white, 0.5));
    //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    QPainter painter(this);
    int centerX = f(0);
    int centerY = f(0);
    int R = (460 / (7) / 2);//50米对应像素
    int radius = (460 / (7));  // 半径  (默认100米)
    //int r = meter_To_Pixel(50);
    //painter.setPen(QPen(Qt::green, 1));
    //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    int r = meter_To_Pixel(100);
    painter.setPen(QPen(Qt::green, 2));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(150);
    painter.setPen(QPen(Qt::green, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(200);
    painter.setPen(QPen(Qt::green, 2));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(250);
    painter.setPen(QPen(Qt::red, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(300);
    painter.setPen(QPen(Qt::red, 2));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);



    painter.setCompositionMode(QPainter::CompositionMode_Clear);
    painter.setPen(QPen(Qt::green, 25));
    painter.drawLine(0, 0, 460, 460);
    painter.drawLine(0, 460, 460, 0);
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.setPen(Qt::green);
    QFont font1;
    font1.setPointSizeF(7);
    painter.setFont(font1);
    painter.setBrush(Qt::NoBrush);
    int min = 7;
    int min2 = 5;
    int max = 5;
    painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
    painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
    painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
    painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
    painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
    //painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
    //painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
    //painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");
    painter.setPen(Qt::yellow);
    painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
    painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
    painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
    painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
    painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
    //painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
    //painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
    //painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");
    painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
    painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
    painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
    painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
    painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
    //painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
    //painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
    //painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");
    painter.setPen(Qt::green);
    painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
    painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
    painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
    painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
    painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
    //painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
    //painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
    //painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");
    //r = meter_To_Pixel(75);
    //painter.setPen(QPen(Qt::white, 0.5));
    //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(40);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(50);
    painter.setPen(QPen(Qt::green, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(60);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(70);
    painter.setPen(QPen(Qt::white, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(80);
    painter.setPen(QPen(Qt::white, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(90);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    r = meter_To_Pixel(110);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(120);
    painter.setPen(QPen(Qt::white, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(130);
    painter.setPen(QPen(Qt::white, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(140);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    r = meter_To_Pixel(160);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(170);
    painter.setPen(QPen(Qt::white, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(180);
    painter.setPen(QPen(Qt::white, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(190);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);
    

    r = meter_To_Pixel(210);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(220);
    painter.setPen(QPen(Qt::yellow, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(230);
    painter.setPen(QPen(Qt::yellow, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(240);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    r = meter_To_Pixel(260);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(270);
    painter.setPen(QPen(Qt::yellow, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(280);
    painter.setPen(QPen(Qt::yellow, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    r = meter_To_Pixel(290);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    r = meter_To_Pixel(310);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


}

//输入以玩家为原点的坐标，返回,距离x/y轴的原始像素位置
int Map4::f(int x)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】
    int map_n = 460 / 2;

    int res = x + map_n;

    return res;
}

//输入以玩家为原点,距离x/y轴的米数，返回原始像素位置
int Map4::F(int meter)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

    int map = 460;

    int map_n = map / 2;

    double n = map / static_cast<double>(700);//每1米对应的像素值

    int x = meter * n;

    int res = x + map_n;

    return res;
}

//输入米数，返回对应像素值（单位：n个像素点/米）
int Map4::meter_To_Pixel(int meter)
{
    int map = 460;

    double n = map / static_cast<double>(700);//每1米对应的像素值

    int Pixel = meter * n;

    return Pixel;
}
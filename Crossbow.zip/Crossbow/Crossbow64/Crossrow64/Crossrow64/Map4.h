﻿#pragma once

#include <QWidget>
#include "ui_Map4.h"

#include "VS_C.h"

class Map4 : public QWidget
{
	Q_OBJECT

public:
	Map4(QWidget *parent = nullptr);
	~Map4();
	void paintEvent(QPaintEvent* event);
private:
	Ui::Map4Class ui;

public:
	int f(int x);
	int F(int meter);
	int meter_To_Pixel(int meter);
};

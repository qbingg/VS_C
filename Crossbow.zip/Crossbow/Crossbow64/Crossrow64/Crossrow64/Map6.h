﻿#pragma once

#include <QWidget>
#include "ui_Map6.h"

#include "VS_C.h"

class Map6 : public QWidget
{
	Q_OBJECT

public:
	Map6(QWidget *parent = nullptr);
	~Map6();
	void paintEvent(QPaintEvent* event);
private:
	Ui::Map6Class ui;

public:
	int f(int x);
	int F(int meter);
	int meter_To_Pixel(int meter);
};

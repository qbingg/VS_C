﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);


}

Widget::~Widget()
{}

void Widget::getpush_RB(bool& push_RB)
{
    m_push_RB = &push_RB;
}

void Widget::getmapChange(bool& mapChange)
{
    m_mapChange = &mapChange;
}

void Widget::getuse_6x(bool& use_6x)
{
    m_use_6x = &use_6x;
}


bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        //1、打开计时器，每秒判定一次是否想要变换地图模式
        m_timer = new QTimer(this);
        connect(m_timer, &QTimer::timeout, this, &Widget::mapSelect);
        m_timer->start(1000);

        //2、初始化地图类
        m_Map6 = new Map6;
        m_Map4 = new Map4;

        //3、勾选“启用”后，第一次绘地图时不需要按~键的，所以要设为true把第一次show出来
        *m_mapChange = true;

        //4、初始化动态准心类
        m_Crossrow = new Crossrow;
        m_Crossrow->getpush_RB(*m_push_RB);
        m_Crossrow->getuse_6x(*m_use_6x);

        m_Crossrow->startTimer();

        m_Crossrow->show();
    }
    else
    {
        //1、关闭计时器
        m_timer->stop();
        delete m_timer;
        m_timer = nullptr;

        //2、释放地图类
        m_Map6->close();
        delete m_Map6;
        m_Map6 = nullptr;

        m_Map4->close();
        delete m_Map4;
        m_Map4 = nullptr;

        //4、释放动态准心类
        m_Crossrow->stopTimer();
        m_Crossrow->close();
        delete m_Crossrow;
        m_Crossrow = nullptr;


    }
    return false;
}

void Widget::mapSelect()
{
    if (*m_mapChange)//按下~键时才会为真
    {
        *m_mapChange = false;//重置为false

        if (*m_use_6x)//6倍
        {
            m_Map4->close();

            m_Map6->show();

            m_Map6->move(1627, 790);//小地图左上角像素位置
        }
        else//4倍
        {
            m_Map6->close();

            m_Map4->show();

            m_Map4->move(1428, 591);//大地图左上角像素位置
        }
    }
}
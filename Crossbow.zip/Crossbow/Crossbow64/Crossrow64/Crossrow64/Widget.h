﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"

#include "Map6.h"
#include "Map4.h"

#include "Crossrow.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    bool* m_push_RB;
    bool* m_mapChange;
    bool* m_use_6x;
public:
    void getpush_RB(bool& push_RB);
    void getmapChange(bool& mapChange);
    void getuse_6x(bool& use_6x);
private slots:
    bool on_checkBox(bool checked);


private:
    QTimer* m_timer;//每秒触发一次，大小地图选择
private slots:
    void mapSelect();//每秒触发一次，大小地图选择


private:
    Map6* m_Map6;
    Map4* m_Map4;
private:
    Crossrow* m_Crossrow;
};

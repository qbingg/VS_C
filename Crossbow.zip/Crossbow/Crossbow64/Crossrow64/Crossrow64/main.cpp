﻿#include "Widget.h"
#include <QtWidgets/QApplication>



bool push_RB = false;//按着右键触发

void f_RB()
{
	while (true)
	{
		GET_RB;
		while (GET_RB)
		{
			S100
				GET_RB;
			if (GET_RB)
			{
				if (!push_RB)
				{
					push_RB = true;
				}
				S1;
			}
			GET_RB;
			S1
		}
		if (push_RB)
		{
			push_RB = false;
		}
		S1
	}
}

bool mapChange = true;//来判断是否切换大小地图,	从这里变更为true，在widget类里变为false

bool use_6x = true;	//切换为4、6倍镜模式	默认6倍镜

void f_mapChange()
{
	while (true)
	{
		GET_MAP;
		if (GET_MAP)
		{
			if (use_6x)//6倍->4倍
			{
				use_6x = false;//4倍

				mapChange = true;
			}
			else
			{
				use_6x = true;//6倍

				mapChange = true;
			}
			S300
		}
		S1
	}
}


int main(int argc, char *argv[])
{
	th th_f_RB(f_RB);
	th th_f_mapChange(f_mapChange);
    QApplication a(argc, argv);
    Widget w;
	w.getpush_RB(push_RB);
	w.getmapChange(mapChange);
	w.getuse_6x(use_6x);
    w.show();
    return a.exec();
}

#include "C_Crossbow_Thread.h"

C_Crossbow_Thread::C_Crossbow_Thread()
{
    //初始化opencv类，插入到Map里，并初始化图片
    C_opencv opencv_25m;
    crossbow_opencv[0] = opencv_25m;
    crossbow_opencv[0].setImage_templ(cv::imread("res/opencvImg/crossbow4x_25m.png"));
    C_opencv opencv_4xTop;
    crossbow_opencv[1] = opencv_4xTop;
    crossbow_opencv[1].setImage_templ(cv::imread("res/opencvImg/crossbow4x.png"));
    C_opencv opencv_4xBottom;
    crossbow_opencv[2] = opencv_4xBottom;
    crossbow_opencv[2].setImage_templ(cv::imread("res/opencvImg/crossbow4x_bottom.png"));

}

void C_Crossbow_Thread::getxy(int m_crossbow_x1, int m_crossbow_y1, int m_crossbow_x2, int m_crossbow_y2, int m_crossbow_4_2R, int m_crossbow_4_PngY, double m_magnify_n, int m_screen_resolution_x, int m_screen_resolution_y, int m_crossbow_25m_x1, int m_crossbow_25m_y1, int m_crossbow_25m_x2, int m_crossbow_25m_y2, int m_crossbow_x1_bottom, int m_crossbow_y1_bottom, int m_crossbow_x2_bottom, int m_crossbow_y2_bottom, int m_crossbow_4_PngY_bottom)
{
    crossbow_x1 = m_crossbow_x1;
    crossbow_y1 = m_crossbow_y1;
    crossbow_x2 = m_crossbow_x2;
    crossbow_y2 = m_crossbow_y2;
    crossbow_4_R = m_crossbow_4_2R / static_cast<double>(2);//直径-》》半径
    crossbow_4_PngY = m_crossbow_4_PngY;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    screen_resolution_x = m_screen_resolution_x;
    screen_resolution_y = m_screen_resolution_y;

    crossbow_25m_x1 = m_crossbow_25m_x1;
    crossbow_25m_y1 = m_crossbow_25m_y1;
    crossbow_25m_x2 = m_crossbow_25m_x2;
    crossbow_25m_y2 = m_crossbow_25m_y2;

    crossbow_x1_bottom = m_crossbow_x1_bottom;
    crossbow_y1_bottom = m_crossbow_y1_bottom;
    crossbow_x2_bottom = m_crossbow_x2_bottom;
    crossbow_y2_bottom = m_crossbow_y2_bottom;
    crossbow_4_PngY_bottom = m_crossbow_4_PngY_bottom;
}

void C_Crossbow_Thread::run()
{
    // 开始计时
    std::chrono::steady_clock::time_point start;
    // 停止计时
    std::chrono::steady_clock::time_point end;

    long long duration;

    C_screenshot s;
    cv::Mat screen;
    while (true)
    {
        //按下右键
        if (GetAsyncKeyState(VK_RBUTTON))
        {
            //开始计时
            start = std::chrono::high_resolution_clock::now();
            while (GetAsyncKeyState(VK_RBUTTON))
            {
                end = std::chrono::high_resolution_clock::now();

                // 计算持续时间并转换为毫秒
                duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

                //长按右键，400毫秒后，开始图像检测
                if(duration>400)
                {
                    while (GetAsyncKeyState(VK_RBUTTON))
                    {
                        //25m
                        //截图
                        screen = s.function_grayScreenshotByHandle(crossbow_25m_x1, crossbow_25m_y1, crossbow_25m_x2, crossbow_25m_y2);
                        //输入截图
                        crossbow_opencv[0].setImage_screen(screen);
                        //调用执行函数，进行图像检测
                        crossbow_opencv[0].executeTemplateMatching();

                        //4xTop
                        screen = s.function_grayScreenshotByHandle(crossbow_x1, crossbow_y1, crossbow_x2, crossbow_y2);
                        //输入截图
                        crossbow_opencv[1].setImage_screen(screen);
                        //调用执行函数，进行图像检测
                        crossbow_opencv[1].executeTemplateMatching();

                        //4x_bottom
                        screen = s.function_grayScreenshotByHandle(crossbow_x1_bottom, crossbow_y1_bottom, crossbow_x2_bottom, crossbow_y2_bottom);
                        //输入截图
                        crossbow_opencv[2].setImage_screen(screen);
                        //调用执行函数，进行图像检测
                        crossbow_opencv[2].executeTemplateMatching();

                        //发射信号，将数据传回主线程
                        emit newValue(crossbow_opencv);

                        Sleep(1);
                    }


                    //松开右键后，调用一次update（）清屏
                    Sleep(60);
                    emit sendUpdateOnceToClear();
                }

                Sleep(1);
            }
        }

        Sleep(1);
    }
}


#ifndef C_CROSSBOW_THREAD_H
#define C_CROSSBOW_THREAD_H

#include"Defines.h"
#include <QMap>
#include<QThread>
#include "C_opencv.h"
#include"C_screenshot.h"

class C_Crossbow_Thread:public QThread
{
    Q_OBJECT
private:
    int crossbow_x1;
    int crossbow_y1;
    int crossbow_x2;
    int crossbow_y2;
    int crossbow_4_R;
    int crossbow_4_PngY;
    double magnify_n;//125%->0.8
    int screen_resolution_x;
    int screen_resolution_y;

    int crossbow_25m_x1;
    int crossbow_25m_y1;
    int crossbow_25m_x2;
    int crossbow_25m_y2;

    int crossbow_x1_bottom;
    int crossbow_y1_bottom;
    int crossbow_x2_bottom;
    int crossbow_y2_bottom;
    int crossbow_4_PngY_bottom;
public:
    C_Crossbow_Thread();
    void getxy
        (
            int m_crossbow_x1,
            int m_crossbow_y1,
            int m_crossbow_x2,
            int m_crossbow_y2,
            int m_crossbow_4_2R,//直径
            int m_crossbow_4_PngY,
            double m_magnify_n,
            int m_screen_resolution_x,
            int m_screen_resolution_y,

            int m_crossbow_25m_x1,
            int m_crossbow_25m_y1,
            int m_crossbow_25m_x2,
            int m_crossbow_25m_y2,

            int m_crossbow_x1_bottom,
            int m_crossbow_y1_bottom,
            int m_crossbow_x2_bottom,
            int m_crossbow_y2_bottom,
            int m_crossbow_4_PngY_bottom
            );

private:
    QMap<int,C_opencv> crossbow_opencv;//此处仅声明，在构造函数里初始化，赋值
    //const bool updateOnceToClear = true;//这个信号只发送，是固定值
signals:
    void newValue(QMap<int,C_opencv>);
    void sendUpdateOnceToClear();
protected:
    void run()override;//写override提高代码可读性，说明这个函数是重载的







};

#endif // C_CROSSBOW_THREAD_H

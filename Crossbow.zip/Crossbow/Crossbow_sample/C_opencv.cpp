#include "C_opencv.h"

C_opencv::C_opencv() {}

void C_opencv::setImage_screen(const cv::Mat &newImage_screen)
{
    image_screen = newImage_screen;
}

void C_opencv::setImage_templ(const cv::Mat &newImage_templ)
{
    image_templ = newImage_templ;
}

cv::Point C_opencv::getTarget_point() const
{
    return target_point;
}

double C_opencv::getN() const
{
    return n;
}



void C_opencv::function_matchTemplate(const cv::Mat &input_src, const cv::Mat &input_templ, cv::Point &output_point, double &output_n)
{
    // 确保输入图像是灰度图，如果不是则转换
    cv::Mat src, templ;
    if (input_src.channels() != 1) {
        cv::cvtColor(input_src, src, cv::COLOR_BGR2GRAY);
    } else {
        src = input_src;
    }

    if (input_templ.channels() != 1) {
        cv::cvtColor(input_templ, templ, cv::COLOR_BGR2GRAY);
    } else {
        templ = input_templ;
    }


    //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
    if ((src.cols == 0) || (templ.cols == 0) || (src.cols < templ.cols))
    {
        // 这是程序会崩溃的情况：

        //截图为空，返回-1值
        //模板图为空，返回-1值
        //截图小于模板图，返回-1值
        return ;
    }

    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点
    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    output_point = ptMaxLoc;

    output_n = dMaxVal;

}

void C_opencv::function_matchTemplate_advance(const cv::Mat &intput_src, const cv::Mat &intput_templ, cv::Point &output_point, double &output_n)
{
    using namespace cv;

    //1、直方图反向投影

    //获取模板图像
    Mat image_target = intput_templ;

    //源图为空，则返回
    if (intput_src.empty())
    {
        return ;
    }

    Mat hsv_image;
    cvtColor(intput_src, hsv_image, COLOR_BGR2HSV);
    Mat hsv_image_target;
    cvtColor(image_target, hsv_image_target, COLOR_BGR2HSV);

    // Quantize the hue to 30 levels                            将色相量化为 30 个级别
    // and the saturation to 32 levels                          饱和度为 32 个级别
    int hbins = 30, sbins = 32;
    int histSize[] = { hbins, sbins };
    // hue varies from 0 to 179, see cvtColor                   色相从 0 到 179 不等，请参阅 cvtColor
    float hranges[] = { 0, 180 };
    // saturation varies from 0 (black-gray-white) to           饱和度从 0（黑-灰-白）到
    // 255 (pure spectrum color)                                255（纯光谱色）
    float sranges[] = { 0, 256 };
    const float* ranges[] = { hranges, sranges };
    MatND hist;
    // we compute the histogram from the 0-th and 1-st channels 我们从第 0 个和第 1 个通道计算直方图
    int channels[] = { 0, 1 };
    calcHist(&hsv_image_target, 1, channels, Mat(), // do not use mask       不要使用蒙版
             hist, 2, histSize, ranges,
             true, // the histogram is uniform                       直方图是均匀的
             false);


    //归一化直方图
    normalize(hist, hist, 0, 255, NORM_MINMAX, -1, Mat());
    //normalize(template_hist, template_hist, 0, 255, cv::NORM_MINMAX, -1, cv::Mat());

    // 反投影“模板直方图”到图像上
    cv::Mat back_proj;
    calcBackProject(&hsv_image, 1, channels, hist, back_proj, ranges, 1, true);

    // 使用固定阈值并创建二值图像
    //double threshold = 240;
    cv::Mat thresh;
    threshold(back_proj, thresh, 240, 255, cv::THRESH_BINARY);

    // 进行按位与操作以提取匹配区域
    cv::Mat thresh_result;
    bitwise_and(intput_src, intput_src, thresh_result, thresh);






    //2、图像检测

    cv::Mat src;
    cv::Mat templ;

    cvtColor(thresh_result, src, COLOR_HSV2BGR);
    cvtColor(src, src, COLOR_BGR2GRAY);

    //templ = cv::imread("image_target.png", 0);
    templ = intput_templ;
    cvtColor(templ, templ, cv::COLOR_BGR2GRAY);




    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值



    //匹配结果的四个顶点
    output_point = ptMaxLoc;

    //获取拟合度
    output_n = dMaxVal;

    return ;
}

void C_opencv::executeAdvancedTemplateMatching()
{
    function_matchTemplate_advance(image_screen,image_templ,target_point,n);
}

void C_opencv::executeTemplateMatching()
{
    function_matchTemplate(image_screen,image_templ,target_point,n);
}



#include "C_sMap_Point.h"

C_sMap_Point::C_sMap_Point(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setWindowTitle("小地图自动测距");
    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);

    setAttribute(Qt::WA_TranslucentBackground);

    //绑定槽函数：接受信号
    connect(&sMap_thread,&C_sMap_Point_Thread::newValue,this,&C_sMap_Point::receiveSignal);
}

C_sMap_Point::~C_sMap_Point()
{}

void C_sMap_Point::getxy(int& m_check_sMap_Point_Solo, int& m_sMap_MeterSize, int m_sMap400_x1, int m_sMap400_y1, int m_sMap400_x2, int m_sMap400_y2, int m_sMap700_x1, int m_sMap700_y1, int m_sMap700_x2, int m_sMap700_y2, double m_magnify_n, int m_point_PngTarget_x,int m_point_PngTarget_y)
{
    check_sMap_Point_Solo = &m_check_sMap_Point_Solo;
    sMap_MeterSize = &m_sMap_MeterSize;

    sMap400_x1 = m_sMap400_x1;
    sMap400_y1 = m_sMap400_y1;
    sMap400_x2 = m_sMap400_x2;
    sMap400_y2 = m_sMap400_y2;

    sMap700_x1 = m_sMap700_x1;
    sMap700_y1 = m_sMap700_y1;
    sMap700_x2 = m_sMap700_x2;
    sMap700_y2 = m_sMap700_y2;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    point_PngTarget_x = m_point_PngTarget_x;
    point_PngTarget_y = m_point_PngTarget_y;

    if (*sMap_MeterSize == 400)
    {
        resize
            (
                (sMap400_x2 - sMap400_x1) * magnify_n,
                (sMap400_y2 - sMap400_y1) * magnify_n
                );

        move
            (
                sMap400_x1 * magnify_n,
                sMap400_y1 * magnify_n
                );
    }
    else if (*sMap_MeterSize == 700)
    {
        resize
            (
                (sMap700_x2 - sMap700_x1) * magnify_n,
                (sMap700_y2 - sMap700_y1) * magnify_n
                );

        move
            (
                sMap700_x1 * magnify_n,
                sMap700_y1 * magnify_n
                );
    }

    width400 = (sMap400_x2 - sMap400_x1) * magnify_n;
    height400 = (sMap400_x2 - sMap400_x2) * magnify_n;

    width700 = (sMap700_x2 - sMap700_x1) * magnify_n;
    height700 = (sMap700_x2 - sMap700_x2) * magnify_n;

    //在获取数据的同时，将数据传到子线程里
    sMap_thread.getxy(
        m_sMap_MeterSize,

        m_sMap400_x1,
        m_sMap400_y1,
        m_sMap400_x2,
        m_sMap400_y2,

        m_sMap700_x1,
        m_sMap700_y1,
        m_sMap700_x2,
        m_sMap700_y2,

        point_PngTarget_x = m_point_PngTarget_x,
        point_PngTarget_y = m_point_PngTarget_y
        );

}

void C_sMap_Point::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);

    /*原小地图画圆，画框：*/

    //画310m的圈，以便用于显示弩箭的射程范围
    if (*sMap_MeterSize == 700)
    {
        //画圆
        int r = meter_To_Pixel(310);
        painter.setPen(QPen(penColor310m, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);
        //擦去圆上的四处，写字
        painter.setCompositionMode(QPainter::CompositionMode_Clear);
        painter.setPen(QPen(Qt::green, 25));
        painter.drawLine(0, 0, width700, width700);
        painter.drawLine(0, width700, width700, 0);
        painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
        painter.setPen(penColor310m);
        QFont font1;
        font1.setPointSizeF(7);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        int min = 7;
        int min2 = 5;
        int max = 5;

        painter.drawText(F(310 * sin(PI / 4)) - min, F(310 * cos(PI / 4)) + max, "310");
        painter.drawText(F(-310 * sin(PI / 4)) - min2, F(310 * cos(PI / 4)), "310");
        painter.drawText(F(310 * sin(PI / 4)) - min2, F(-310 * cos(PI / 4)), "310");
        painter.drawText(F(-310 * sin(PI / 4)) - min, F(-310 * cos(PI / 4)) + max, "310");
    }

    //画边框，确认小地图范围
    painter.setPen(QPen(penColorBorder, 1.5));
    if (*sMap_MeterSize == 400)
    {
        painter.drawRect(0, 0, (sMap400_x2 - sMap400_x1) * magnify_n, (sMap400_y2 - sMap400_y1) * magnify_n);
    }
    else if (*sMap_MeterSize == 700)
    {
        painter.drawRect(0, 0, (sMap700_x2 - sMap700_x1) * magnify_n , (sMap700_y2 - sMap700_y1) * magnify_n);
    }



    /*小地图测距：*/

    //画框
    for (int i = 0; i < 5; i++)
    {
        if (n[i] > 0.3)
        {
            if (i == 0 && *check_sMap_Point_Solo == 1)
            {
                painter.setPen(QPen(penColor[i], 2));
                int X = target_point_x[i] * magnify_n;
                int Y = target_point_y[i] * magnify_n;
                painter.drawRect(X, Y, point_PngTarget_x * 2, point_PngTarget_y);
            }

            if (i != 0 && *check_sMap_Point_Solo == 0)
            {
                painter.setPen(QPen(penColor[i], 2));
                int X = target_point_x[i] * magnify_n;
                int Y = target_point_y[i] * magnify_n;
                painter.drawRect(X, Y, point_PngTarget_x * 2, point_PngTarget_y);
            }
        }
    }

    //计算距离
    QFont font1;
    font1.setPointSizeF(13);
    painter.setFont(font1);
    //四排，只显示combobox选中的玩家
    int player = *crossbow_player_number + 1;//0123>>1234
    for (int i = 0; i < 5; i++)
    {
        if (n[i]>0.3)
        {
            if (i == 0 && *check_sMap_Point_Solo == 1)//单人
            {
                painter.setPen(QPen(penColor[i]));
                float meter = function_Pixels_To_Meters(target_point_x[i], target_point_y[i]);
                QString strNumber = QString::number(meter, 'f', 0);
                QString STR = " " + strNumber + " 米";
                painter.drawText(0, 20 * (i + 1), STR);

                *sendMeterToCrossbow = meter;
            }

            if (i != 0 && *check_sMap_Point_Solo == 0)//四排
            {
                painter.setPen(QPen(penColor[i]));
                float meter = function_Pixels_To_Meters(target_point_x[i], target_point_y[i]);
                QString strNumber = QString::number(meter, 'f', 1);
                QString STR = " " + strNumber + "";
                painter.drawText(0, 20 * (i), STR);


                if (i==player)
                {
                    //四舍五入为整数，仅限非负数（避免舍弃小数导致结果偏小）
                    *sendMeterToCrossbow = meter + 0.5;
                }
                //*sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[1], target_point_y[1]);
            }
        }
        else if ((n[0] < 0.3) && (n[player] < 0.3))//单排 和四排？号 都没有检测到标点
        {
            *sendMeterToCrossbow = 0;
        }
    }



}

double C_sMap_Point::function_Pixels_To_Meters(int Pixel_x, int Pixel_y)
{

    //获取中心点
    double x0;
    double y0;
    //获取每1像素值对应米数
    double n;
    if (*sMap_MeterSize == 400)
    {
        //中心点坐标，玩家坐标
        x0 = (sMap400_x2 - sMap400_x1) / static_cast <double>(2);
        y0 = (sMap400_y2 - sMap400_y1) / static_cast <double>(2);

        n = static_cast<double>(400) / (sMap400_x2 - sMap400_x1);//每1像素值对应米数
    }
    else if (*sMap_MeterSize == 700)
    {
        //中心点坐标，玩家坐标
        x0 = (sMap700_x2 - sMap700_x1) / static_cast <double>(2);
        y0 = (sMap700_y2 - sMap700_y1) / static_cast <double>(2);

        n = static_cast<double>(700) / (sMap700_x2 - sMap700_x1);//每1像素值对应米数
    }

    //两点差,注意加上“目标像素位置”
    double Lx = x0 - (Pixel_x+ point_PngTarget_x);
    double Ly = y0 - (Pixel_y+ point_PngTarget_y);

    //double L = sqrt((Lx * Lx) + (Ly * Ly));
    // 可考虑使用hypot函数提高计算稳定性
    double L = hypot(Lx, Ly);  // 等价于 sqrt(Lx² + Ly²)，但数值稳定性更好


    return L * n;
}

void C_sMap_Point::getsendMeterToCrossbow(int& m_sendMeterToCrossbow)
{
    sendMeterToCrossbow = &m_sendMeterToCrossbow;
}

void C_sMap_Point::getcrossbow_player_number(int &m_crossbow_player_number)
{
    crossbow_player_number = & m_crossbow_player_number;
}

void C_sMap_Point::startThread()
{
    //与startTimer类似，运行多线程
    //注意要在数据获取getxy之后
    //在绑定槽函数之后
    sMap_thread.start();
}

void C_sMap_Point::receiveSignal(QMap<int, C_opencv> sMap_opencv)
{
    //获取值
    for(int key : sMap_opencv.keys())
    {
        n[key] = sMap_opencv[key].getN();

        target_point_x[key] =  sMap_opencv[key].getTarget_point().x;
        target_point_y[key] =  sMap_opencv[key].getTarget_point().y;
    }

    //检测小地图窗口尺寸
    if(1){
        //
        if (*sMap_MeterSize == 400)
        {
            resize
                (
                    (sMap400_x2 - sMap400_x1) * magnify_n,
                    (sMap400_y2 - sMap400_y1) * magnify_n
                    );

            move
                (
                    sMap400_x1 * magnify_n,
                    sMap400_y1 * magnify_n
                    );


            update();

        }
        else if (*sMap_MeterSize == 700)
        {
            resize
                (
                    (sMap700_x2 - sMap700_x1) * magnify_n,
                    (sMap700_y2 - sMap700_y1) * magnify_n
                    );

            move
                (
                    sMap700_x1 * magnify_n,
                    sMap700_y1 * magnify_n
                    );


            update();

        }
    }
    //更新窗口
    update();

}



//输入以玩家为原点的坐标，返回,距离x/y轴的原始像素位置
int C_sMap_Point::f(int x)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

    if (*sMap_MeterSize == 400)
    {
        int map_n = width400 / 2;

        int res = x + map_n;

        return res;
    }
    else if (*sMap_MeterSize == 700)
    {
        int map_n = width700 / 2;

        int res = x + map_n;

        return res;
    }

    return -1;
}

//输入以玩家为原点,距离x/y轴的米数，返回原始像素位置
int C_sMap_Point::F(int meter)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

    if (*sMap_MeterSize == 400)
    {
        int map = width400;

        int map_n = map / 2;

        double n = map / static_cast<double>(400);//每1米对应的像素值

        int x = meter * n;

        int res = x + map_n;

        return res;
    }
    else if (*sMap_MeterSize == 700)
    {
        int map = width700;

        int map_n = map / 2;

        double n = map / static_cast<double>(700);//每1米对应的像素值

        int x = meter * n;

        int res = x + map_n;

        return res;
    }

    return -1;

}

//输入米数，返回对应像素值（单位：n个像素点/米）
int C_sMap_Point::meter_To_Pixel(int meter)
{
    if (*sMap_MeterSize == 400)
    {
        int map = width400;

        double n = map / static_cast<double>(400);//每1米对应的像素值

        int Pixel = meter * n;

        return Pixel;
    }
    else if (*sMap_MeterSize == 700)
    {
        int map = width700;

        double n = map / static_cast<double>(700);//每1米对应的像素值

        int Pixel = meter * n;

        return Pixel;
    }

    return -1;

}

void C_sMap_Point::getpenColor(QMap<int, QColor> QColorMapData)
{
    penColorBorder = QColorMapData[SMAP_COLOR];
    penColor310m = QColorMapData[SMAP_COLOR310M];
    update();
}



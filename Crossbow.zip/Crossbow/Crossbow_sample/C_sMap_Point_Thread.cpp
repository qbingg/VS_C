#include "C_sMap_Point_Thread.h"

C_sMap_Point_Thread::C_sMap_Point_Thread()
{
    //初始化opencv类，插入到Map里
    for (int key = 0; key < 5; key++) {
        //初始化opencv类
        C_opencv player;
        sMap_opencv[key]=player;//存在修改，不存在则插入

        //初始化模板图片
        QString strNumber = QString::number(key);
        QString STR = "res/opencvImg/point_" + strNumber + ".png";
        cv::String stdSTR = STR.toStdString();
        //设置opencv类的模板图像
        sMap_opencv[key].setImage_templ(cv::imread(stdSTR));
    }
}

void C_sMap_Point_Thread::getxy(int &m_sMap_MeterSize, int m_sMap400_x1, int m_sMap400_y1, int m_sMap400_x2, int m_sMap400_y2, int m_sMap700_x1, int m_sMap700_y1, int m_sMap700_x2, int m_sMap700_y2, int m_point_PngTarget_x, int m_point_PngTarget_y)
{
    sMap_MeterSize = &m_sMap_MeterSize;

    sMap400_x1 = m_sMap400_x1;
    sMap400_y1 = m_sMap400_y1;
    sMap400_x2 = m_sMap400_x2;
    sMap400_y2 = m_sMap400_y2;

    sMap700_x1 = m_sMap700_x1;
    sMap700_y1 = m_sMap700_y1;
    sMap700_x2 = m_sMap700_x2;
    sMap700_y2 = m_sMap700_y2;

    point_PngTarget_x = m_point_PngTarget_x;
    point_PngTarget_y = m_point_PngTarget_y;
}

void C_sMap_Point_Thread::run()
{
    //实例声明在循环外以优化性能
    C_screenshot s;
    cv::Mat screen;
    while (true)
    {
        //截图
        if (*sMap_MeterSize == 400)
        {
            //function_screen(screen,sMap400_x1, sMap400_y1, sMap400_x2, sMap400_y2);
            screen= s.function_colorfulScreenshotByHandle(sMap400_x1, sMap400_y1, sMap400_x2, sMap400_y2);
        }
        else if (*sMap_MeterSize == 700)
        {
            //function_screen(screen, sMap700_x1, sMap700_y1, sMap700_x2, sMap700_y2);
            screen= s.function_colorfulScreenshotByHandle(sMap700_x1, sMap700_y1, sMap700_x2, sMap700_y2);
        }

        for (int key : sMap_opencv.keys())
        {
            //输入截图
            sMap_opencv[key].setImage_screen(screen);
            //调用执行函数，进行图像检测
            sMap_opencv[key].executeAdvancedTemplateMatching();
        }

        //发射信号，将数据传回主线程
        emit newValue(sMap_opencv);

        Sleep(1);
    }
}



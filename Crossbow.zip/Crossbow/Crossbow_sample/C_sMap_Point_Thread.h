#ifndef C_SMAP_POINT_THREAD_H
#define C_SMAP_POINT_THREAD_H

#include"Defines.h"
#include <QMap>
#include<QThread>
#include "C_opencv.h"
#include"C_screenshot.h"

class C_sMap_Point_Thread:public QThread
{
    Q_OBJECT
private:
    int* sMap_MeterSize;

    int point_PngTarget_x;
    int point_PngTarget_y;

    int sMap400_x1;
    int sMap400_y1;
    int sMap400_x2;
    int sMap400_y2;

    int sMap700_x1;
    int sMap700_y1;
    int sMap700_x2;
    int sMap700_y2;

public:
    C_sMap_Point_Thread();

    void getxy
        (
            int& m_sMap_MeterSize,

            int m_sMap400_x1,
            int m_sMap400_y1,
            int m_sMap400_x2,
            int m_sMap400_y2,

            int m_sMap700_x1,
            int m_sMap700_y1,
            int m_sMap700_x2,
            int m_sMap700_y2,

            int m_point_PngTarget_x,
            int m_point_PngTarget_y

            );

private:
    QMap<int,C_opencv> sMap_opencv;//此处仅声明，在构造函数里初始化，赋值
signals:
    void newValue(QMap<int,C_opencv>);
protected:
    void run()override;//写override提高代码可读性，说明这个函数是重载的
};

#endif // C_SMAP_POINT_THREAD_H

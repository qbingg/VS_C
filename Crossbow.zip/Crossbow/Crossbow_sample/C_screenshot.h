#ifndef C_SCREENSHOT_H
#define C_SCREENSHOT_H

#include"Defines.h"

//1、输入截图区域
//2、选择截图方式
//3、输出截图图片

class C_screenshot
{
    //简化代码，不需要这么多get/set，这么多成员变量了
    //这个类只有函数，输入截图区域，即返回图片
//private:
    // int m_x1, m_x2;
    // int m_y1, m_y2;
    // cv::Mat m_screenshot;
//public:
    //void setScreenshotArea(const int x1, const int y1, const int x2, const int y2);


public:
    //全屏截图
    cv::Mat function_colorfulScreenshotByFullScreen(const int x1, const int y1, const int x2, const int y2);

    cv::Mat function_grayScreenshotByFullScreen(const int x1, const int y1, const int x2, const int y2);

    cv::Mat function_negativeScreenshotByFullScreen(const int x1, const int y1, const int x2, const int y2);

    //窗口截图
    cv::Mat function_colorfulScreenshotByHandle(const int x1, const int y1, const int x2, const int y2);

    cv::Mat function_grayScreenshotByHandle(const int x1, const int y1, const int x2, const int y2);

    cv::Mat function_negativeScreenshotByHandle(const int x1, const int y1, const int x2, const int y2);


public:
    C_screenshot();

};

#endif // C_SCREENSHOT_H

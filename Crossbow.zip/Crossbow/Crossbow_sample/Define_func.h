#ifndef DEFINE_FUNC_H
#define DEFINE_FUNC_H

#endif // DEFINE_FUNC_H

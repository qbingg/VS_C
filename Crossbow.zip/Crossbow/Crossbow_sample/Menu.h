#ifndef MENU_H
#define MENU_H

#include <QWidget>

#include "Defines.h"
#include "C_SQL.h"
//#include "C_sMap.h"
#include "C_sMap_Point.h"
#include "C_Crossbow.h"
#include "C_preview.h"
#include <QMouseEvent>
#include <qmessagebox.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class Menu;
}
QT_END_NAMESPACE

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();

    void closeEvent(QCloseEvent* event);
private:
    Ui::Menu *ui;

//窗口拖动事件
private:
    QPoint _offset;
protected:
    void mousePressEvent(QMouseEvent *event) override {
        if (event->button() == Qt::LeftButton) {
            _offset = event->pos();
        }
    }

    void mouseMoveEvent(QMouseEvent *event) override {
        if (_offset.isNull() == false) { // 检查 _offset 是否已设置
            int x = this->x() + event->x() - _offset.x();
            int y = this->y() + event->y() - _offset.y();
            this->move(x, y);
        }
    }

    void mouseReleaseEvent(QMouseEvent *event) override {
        if (event->button() == Qt::LeftButton) {
            _offset = QPoint(); // 重置偏移量
        }
    }

//数据库
private:
    QMap<int,int> m_intMapData;
    QMap<int,double> m_doubleMapData;
    QMap<int,QColor> m_QColorMapData;
public:
    void setIntMapData(const QMap<int, int> &newIntMapData);

    void setDoubleMapData(const QMap<int, double> &newDoubleMapData);

    void setQColorMapData(const QMap<int, QColor> &newQColorMapData);
private slots:
    void on_btnSave_clicked();

    bool on_checkBoxRunning(bool checked);

    void on_btnClose_clicked();

    void on_btnMinimize_clicked();



//小地图
private:
    //C_sMap* m_C_sMap;
    int* m_sMap_MeterSize;
public:
    void getsMap_MeterSize(int& sMap_MeterSize);


//小地图测距
private:
    C_sMap_Point* m_C_sMap_Point;
    int* m_check_sMap_Point_Solo;
    int* m_sendMeterToCrossbow;
    int* m_crossbow_player_number;
public:
    void getsendMeterToCrossbow(int& sendMeterToCrossbow);
    void getsMap_Point(int& check_sMap_Point_Solo);
    void getcrossbow_player_number(int& crossbow_player_number);
private slots:
    bool on_checkBoxcheck_sMap_Point_Solo(bool checked);

//弩箭动态准心
    void on_comboBoxPlayerNumber_activated(int index);

//图像检测区域预览
private:
    C_preview* m_C_preview;




private:
    C_Crossbow* m_C_Crossbow;

//放大镜
private:
    int *m_Magnify_UPy0;
    float *m_winMagnify_n;
    bool* m_use_winMagnify;
public:
    void getMagnify(int& Magnify_UPy0, float& winMagnify_n);
    void getuse_winMagnify(bool& use_winMagnify);

private:
    //通过comboBoxColor修改滑块的值时，不触发槽函数：切换颜色
    bool isUserInteraction = true;
private slots:
    void slot_RGB_Setting(int action);
    void on_comboBoxColor_activated(int index);

    void on_checkBoxPreview_stateChanged(int arg1);
};

#endif // MENU_H

#include "Menu.h"

#include <QApplication>
#include <QFile>

#include "Defines.h"
#include "Define_Var.h"
#include "Define_Func.h"
#include "C_SQL.h"
//启动程序需要做的事
void function_StartALL()//启动程序需要做的事
{
    //1. 检查文件夹是否存在，如果不存在则创建
    if (!fs::exists(relative_Path))
    {
        fs::create_directories(relative_Path);
    }
    if (!fs::exists(shareInfo_Path))
    {
        fs::create_directories(shareInfo_Path);
    }
    if (!fs::exists(opencv_Path))
    {
        fs::create_directories(opencv_Path);
    }
    if (!fs::exists(img_Path))
    {
        fs::create_directories(img_Path);
    }



    //读取数据
    C_SQL sql;
    sql.read_intMapData(intMapData);
    sql.read_doubleMapData(doubleMapData);
    sql.read_QColorMapData(QColorMapData);
    //特殊数据，赋值
    check_sMap_Point_Solo=intMapData[CHECK_SMAP_POINT_SOLO];
    Magnify_UPy0=intMapData[MAGNIFY_UPY0];
    winMagnify_n=doubleMapData[WINMAGNIFY_N];//一定要分清楚数据类型！！！

    for(int key :QColorMapData.keys()){

        qDebug() << QColorMapData[key];
    }







}

void function_setSMapSize()
{
    while (true)
    {
        GetAsyncKeyState(192);
        if (GetAsyncKeyState(192))
        {
            if (sMap_MeterSize == 400)
            {
                sMap_MeterSize = 700;
            }
            else if (sMap_MeterSize == 700)
            {
                sMap_MeterSize = 400;
            }

            while(GetAsyncKeyState(192))
            {
                Sleep(10);
            }
        }
        Sleep(100);
    }
}

//右键：点按腰射，长按开镜，不自动屏息
void function_RB()
{
#define WASD_IS_NOT_CLICKED (GetAsyncKeyState(87) == 0 && GetAsyncKeyState(65) == 0 && GetAsyncKeyState(83) == 0 && GetAsyncKeyState(68) == 0)

    //经测试，默认点按开镜14帧，默认长按开镜10帧数，我写的代码开镜12~16帧。
    //[ 219  ] 221
    GetAsyncKeyState(219);
    GetAsyncKeyState(VK_RBUTTON);
    // 开始计时
    std::chrono::steady_clock::time_point start;
    // 停止计时
    std::chrono::steady_clock::time_point end;

    while (true)
    {
        //判断到按下鼠标右键，（但是不知道是点按还是长按）
        if (GetAsyncKeyState(VK_RBUTTON) != 0)
        {
            //开始计时
            start = std::chrono::high_resolution_clock::now();

            // // 按着右键,开镜后自动按下屏息键
            // bool keyDown = false;
            // while (GetAsyncKeyState(VK_RBUTTON) != 0)
            // {
            //     //等待WASD松开，按下屏息，退出循环
            //     if ( WASD_IS_NOT_CLICKED )
            //     {
            //         //按着屏息键
            //         keybd_event(221, 0, 0, 0);
            //         keyDown = true;
            //
            //         //退出循环
            //         break;
            //     }
            //
            //     Sleep(1);
            // }
            // 只要按着右键，就是开镜
            while (GetAsyncKeyState(VK_RBUTTON) != 0)
            {
                Sleep(10);
            }
            // //如果按下了屏息键，松开屏息键
            // if (keyDown)
            // {
            //     //松开屏息键
            //     keybd_event(221, 0, KEYEVENTF_KEYUP, 0);
            // }

            //做差计时
            end = std::chrono::high_resolution_clock::now();
            // 计算持续时间并转换为毫秒
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
            //持续时间小于150毫秒，视为腰射
            if (duration<150)
            {
                keybd_event(219, 0, 0, 0);//点一下腰射键，进入腰射(因为每次右键先触发的是开镜，所以从这里退不出腰射的)
                keybd_event(219, 0, KEYEVENTF_KEYUP, 0);
            }

        }
        Sleep(10);




    }

}


//win放大镜
void function_winMagnify()
{

    MagInitialize();
    while (true)
    {
        while (true)//非暂停
        {
            while (use_winMagnify)
            {
                if (GetAsyncKeyState(VK_RBUTTON) != 0 && GetAsyncKeyState(VK_LSHIFT) == 0)
                {
                    while (GetAsyncKeyState(VK_RBUTTON) != 0)
                    {
                        if (GetAsyncKeyState(VK_LSHIFT))
                        {
                            while (GetAsyncKeyState(VK_RBUTTON) != 0)
                            {
                                //确保每次只触发一次命令:启用放大镜
                                if (winMagnify_Click == false)
                                {
                                    winMagnify_Click = true;

                                    //获取放大倍数


                                    //调用WindowsAPI
                                    int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / winMagnify_n)) / 2.0);
                                    int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / winMagnify_n)) / 2.0);
                                    yDlg -= Magnify_UPy0;//向下偏移量
                                    MagSetFullscreenTransform(winMagnify_n, xDlg, yDlg);
                                }
                                Sleep(1);
                            }
                            //关闭放大镜
                            if (winMagnify_Click == true)
                            {
                                winMagnify_Click = false;

                                float reset_n = 1;

                                //调用WindowsAPI
                                int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / reset_n)) / 2.0);
                                int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / reset_n)) / 2.0);

                                MagSetFullscreenTransform(reset_n, xDlg, yDlg);
                            }
                            Sleep(1);
                        }
                        Sleep(1);
                    }
                }
                Sleep(100);
            }
            Sleep(1000);
        }
        Sleep(1000);
    }
    MagUninitialize();
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QFile file("res/style.qss");
    if (file.open(QFile::ReadOnly)) {
        QTextStream filetext(&file);
        QString styleSheet = filetext.readAll();
        a.setStyleSheet(styleSheet);
    } else {
        qWarning("Couldn't open style sheet file.");
    }

    function_StartALL();

    std::thread thread_function_setSMapSize(function_setSMapSize);
    std::thread thread_function_RB(function_RB);
    std::thread thread_function_winMagnify(function_winMagnify);

    Menu w;

    w.setIntMapData(intMapData);
    w.setDoubleMapData(doubleMapData);
    w.setQColorMapData(QColorMapData);
    w.getsMap_Point(check_sMap_Point_Solo);

    w.getsMap_MeterSize(sMap_MeterSize);

    w.getMagnify( Magnify_UPy0, winMagnify_n);
    w.getuse_winMagnify(use_winMagnify);

    w.getcrossbow_player_number(crossbow_player_number);

    w.getsendMeterToCrossbow(sendMeterToCrossbow);//否则程序崩溃的原因，之前为什么程序不崩溃，还可以正常的运行？

    w.show();
    return a.exec();
}

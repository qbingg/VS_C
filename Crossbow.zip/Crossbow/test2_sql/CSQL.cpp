#include "CSQL.h"

CSQL::CSQL() {
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return;
    }


    QSqlQuery query;
    QString sql = QString::fromUtf8(R"(
create table if not exists tb_int
(
key int PRIMARY KEY,
value int
)
)");
    if (!query.exec(sql))
    {
        qDebug() << "Failed to create table";
        qDebug() << query.lastQuery();
        return;
    }
    m_db.close();
}

bool CSQL::writeData(QMap<int, int> &intMap)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    //写入数据
    foreach (int key, intMap.keys()) {
        int value = intMap.value(key);

        QSqlQuery query;
        query.prepare(R"(
        insert into tb_int
        (
        key,
        value
        )
        values
        (
        :key,
        :value
        )
        ON CONFLICT(key) DO UPDATE SET value = excluded.value;
        )");//key = excluded.key,键不需要修改

        query.bindValue(":key", key);
        query.bindValue(":value", value);
        if (!query.exec())
        {
            qDebug() << query.lastQuery();
            m_db.close();
            return false;
        }

    }
    // //写入数据  使用迭代器
    // for (QMap<int, int>::const_iterator it = intMap.cbegin(); it != intMap.cend(); ++it) {
    //     int key = it.key();
    //     int value = it.value();

    //     QSqlQuery query;
    //     query.prepare(R"(
    //     insert into tb_int
    //     (
    //     key,
    //     value
    //     )
    //     values
    //     (
    //     :key,
    //     :value
    //     )
    //     ON CONFLICT(key) DO UPDATE SET key = excluded.key, value = excluded.value;
    //     )");

    //     query.bindValue(":key", key);
    //     query.bindValue(":value", value);
    //     if (!query.exec())
    //     {
    //         qDebug() << query.lastQuery();
    //         m_db.close();
    //         return false;
    //     }

    // }


    m_db.close();

    return true;
}

bool CSQL::readDate(QMap<int, int> &intMap)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM tb_int");
    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }

    while(query.next())
    {
        qDebug() << query.value("key").toInt()<<", "<<query.value("value").toInt();

        int key = query.value("key").toInt();
        int value = query.value("value").toInt();
        intMap[key] = value;
    }
    m_db.close();

    return true;
}

#ifndef DEFINE_VAR_H
#define DEFINE_VAR_H

#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>

//数据库变量初始化
#define SCREEN_RESOLUTION_X 1
#define SCREEN_RESOLUTION_Y 2

#define SMAP700_X1 3
#define SMAP700_Y1 4
#define SMAP700_X2 5
#define SMAP700_Y2 6





#endif // DEFINE_VAR_H

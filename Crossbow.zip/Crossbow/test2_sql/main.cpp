#include "Menu.h"

#include <QApplication>
#include "CSQL.h"

// QMap<int,int> intMap = {
//     {SCREEN_RESOLUTION_X , 111},
//     {SCREEN_RESOLUTION_Y , 222},
//     {SMAP700_X1 , 333},
//     {SMAP700_Y1 , 444},
//     {SMAP700_X2 , 555},
//     {SMAP700_Y2 , 666}
// };

QMap<int,int> intMap = {
    {SCREEN_RESOLUTION_X , 0},
    {SCREEN_RESOLUTION_Y , 0},
    {SMAP700_X1 , 0},
    {SMAP700_Y1 , 0},
    {SMAP700_X2 , 0},
    {SMAP700_Y2 , 0}
};

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    CSQL sql;
    //sql.writeData(intMap);
    sql.readDate(intMap);

    qDebug() << intMap;

    QMap<int,int>* m_intMap;

    m_intMap = & intMap;

    //int* value = &intMap[SCREEN_RESOLUTION_X];
    auto* value = &m_intMap[SCREEN_RESOLUTION_X];

    qDebug() <<"指针下的值："<< *value;

    /*
     map的值并不能进行内存穿透，需要内存穿透的变量只能用原来的方法

    关于涉及数据库的变量：
    所有类获取数据时都是用
    get_intMapData(QMap<int,int> intMapData)
    {
        m_screen_resolution_x = intMapData[SCREEN_RESOLUTION_X];
    }
    然后各取所需即可

*/

    Menu w;
    w.show();
    return a.exec();
}

#ifndef C_SQL_H
#define C_SQL_H

class C_SQL
{
public:
    C_SQL();
};

#endif // C_SQL_H

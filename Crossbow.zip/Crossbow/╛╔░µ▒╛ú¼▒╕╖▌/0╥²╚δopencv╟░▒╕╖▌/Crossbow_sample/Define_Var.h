#ifndef DEFINE_VAR_H
#define DEFINE_VAR_H

#include "Defines.h"

#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>

QMap<int,int> intMapData = {
    {SCREEN_RESOLUTION_X , 0},
    {SCREEN_RESOLUTION_Y , 0}
};

#endif // DEFINE_VAR_H

#ifndef DEFINES_DATA_H
#define DEFINES_DATA_H

//数据库变量 宏定义
#define SCREEN_RESOLUTION_X 1
#define SCREEN_RESOLUTION_Y 2

// 重复定义错误 (LNK2005)，通常发生在全局变量在多个编译单元中被重复定义
// 使用 extern 声明全局变量,在头文件中，只声明全局变量，而不定义它。变量的定义应该放在一个单独的 .cpp 文件中。
//
// 或者直接使用 inline 定义全局变量
// inline QMap<int,int> intMapData = {
//     {SCREEN_RESOLUTION_X , 0},
//     {SCREEN_RESOLUTION_Y , 0}
// };
// 不过我并不需要在这里声明变量，我可以在这里对数据库变量进行宏定义，在Define_Var里对数据库变量进行初始化
// 且仅在main.cpp引入一次
// 在这里定义全局变量会导致Menu类里可以直接访问的，安全性会下降

#endif // DEFINES_DATA_H

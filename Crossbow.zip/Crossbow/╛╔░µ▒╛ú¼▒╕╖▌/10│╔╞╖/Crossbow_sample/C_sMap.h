#ifndef C_SMAP_H
#define C_SMAP_H

#include <QWidget>
#include <qtimer.h>
#include <qpainter.h>
#include <Windows.h>

#include "Defines.h"
namespace Ui {
class C_sMap;
}

class C_sMap : public QWidget
{
    Q_OBJECT

public:
    explicit C_sMap(QWidget *parent = nullptr);
    ~C_sMap();

private:
    Ui::C_sMap *ui;

private:
    QTimer* m_timer;
private slots:
    void updateWidget();
public:
    void paintEvent(QPaintEvent* event);
    void startTimer();
    void stopTimer();


private:
    int sMap400_x1;
    int sMap400_y1;
    int sMap400_x2;
    int sMap400_y2;

    int sMap700_x1;
    int sMap700_y1;
    int sMap700_x2;
    int sMap700_y2;

    double magnify_n;//125%->0.8

    int* sMap_MeterSize;

public:
    void getxy
        (
            int m_sMap400_x1,
            int m_sMap400_y1,
            int m_sMap400_x2,
            int m_sMap400_y2,

            int m_sMap700_x1,
            int m_sMap700_y1,
            int m_sMap700_x2,
            int m_sMap700_y2,

            double m_magnify_n,

            int &m_sMap_MeterSize
            );

// private:
//     int* check_sMap_DrawArc;
// public:
//     void getcheck_sMap_DrawArc(int& m_check_sMap_DrawArc);





private:
    int width400, height400;
    int width700, height700;


public:
    int f(int x);
    int F(int meter);
    int meter_To_Pixel(int meter);


private:
    QColor penColor = QColor::fromString("#00ff00");
public:
    void getpenColor(QColor Color);
};

#endif // C_SMAP_H

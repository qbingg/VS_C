#include "Menu.h"

#include <QApplication>
#include <QFile>

#include "Defines.h"
#include "Define_Var.h"
#include "Define_Func.h"
#include "C_SQL.h"
//启动程序需要做的事
void function_StartALL()//启动程序需要做的事
{
    //1. 检查文件夹是否存在，如果不存在则创建
    if (!fs::exists(relative_Path))
    {
        fs::create_directories(relative_Path);
    }
    if (!fs::exists(shareInfo_Path))
    {
        fs::create_directories(shareInfo_Path);
    }
    if (!fs::exists(opencv_Path))
    {
        fs::create_directories(opencv_Path);
    }
    if (!fs::exists(img_Path))
    {
        fs::create_directories(img_Path);
    }

    //读取数据
    C_SQL sql;
    sql.read_intMapData(intMapData);
    sql.read_doubleMapData(doubleMapData);
    //特殊数据，赋值
    check_sMap_Point_Solo=intMapData[CHECK_SMAP_POINT_SOLO];
    Magnify_UPy0=intMapData[MAGNIFY_UPY0];
    winMagnify_n=doubleMapData[WINMAGNIFY_N];//一定要分清楚数据类型！！！









}

//win放大镜
void function_winMagnify()
{

    MagInitialize();
    while (true)
    {
        while (true)//非暂停
        {
            while (use_winMagnify)
            {
                if (GetAsyncKeyState(VK_RBUTTON) != 0 && GetAsyncKeyState(VK_LSHIFT) == 0)
                {
                    while (GetAsyncKeyState(VK_RBUTTON) != 0)
                    {
                        if (GetAsyncKeyState(VK_LSHIFT))
                        {
                            while (GetAsyncKeyState(VK_RBUTTON) != 0)
                            {
                                //确保每次只触发一次命令:启用放大镜
                                if (winMagnify_Click == false)
                                {
                                    winMagnify_Click = true;

                                    //获取放大倍数


                                    //调用WindowsAPI
                                    int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / winMagnify_n)) / 2.0);
                                    int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / winMagnify_n)) / 2.0);
                                    yDlg -= Magnify_UPy0;//向下偏移量
                                    MagSetFullscreenTransform(winMagnify_n, xDlg, yDlg);
                                }
                                Sleep(1);
                            }
                            //关闭放大镜
                            if (winMagnify_Click == true)
                            {
                                winMagnify_Click = false;

                                float reset_n = 1;

                                //调用WindowsAPI
                                int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / reset_n)) / 2.0);
                                int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / reset_n)) / 2.0);

                                MagSetFullscreenTransform(reset_n, xDlg, yDlg);
                            }
                            Sleep(1);
                        }
                        Sleep(1);
                    }
                }
                Sleep(100);
            }
            Sleep(1000);
        }
        Sleep(1000);
    }
    MagUninitialize();
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QFile file("res/style.qss");
    if (file.open(QFile::ReadOnly)) {
        QTextStream filetext(&file);
        QString styleSheet = filetext.readAll();
        a.setStyleSheet(styleSheet);
    } else {
        qWarning("Couldn't open style sheet file.");
    }

    function_StartALL();

    std::thread thread_function_winMagnify(function_winMagnify);

    Menu w;

    w.setIntMapData(intMapData);
    w.setDoubleMapData(doubleMapData);
    w.getsMap_Point(check_sMap_Point_Solo);

    w.getsMap_MeterSize(sMap_MeterSize);

    w.getMagnify( Magnify_UPy0, winMagnify_n);
    w.getuse_winMagnify(use_winMagnify);

    w.getcrossbow_player_number(crossbow_player_number);

    w.getsendMeterToCrossbow(sendMeterToCrossbow);//否则程序崩溃的原因，之前为什么程序不崩溃，还可以正常的运行？

    w.show();
    return a.exec();
}

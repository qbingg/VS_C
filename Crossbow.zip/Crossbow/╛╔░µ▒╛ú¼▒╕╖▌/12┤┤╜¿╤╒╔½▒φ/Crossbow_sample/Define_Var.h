#ifndef DEFINE_VAR_H
#define DEFINE_VAR_H

#include "Defines.h"

//创建文件夹
namespace fs = std::filesystem;
fs::path relative_Path = PATH; //项目文件夹的相对路径
fs::path shareInfo_Path = SHAREINFO_PATH;////共享文件夹路径
fs::path opencv_Path = OPENCV_PATH; //图像检测，模板图片文件夹路径
fs::path img_Path = IMG_PATH;//img文件夹路径


#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>
#include <QColor>

QMap<int,int> intMapData = {
    {SCREEN_RESOLUTION_X , 0},
    {SCREEN_RESOLUTION_Y , 0},
    {SMAP400_X1, 0},
    {SMAP400_Y1, 0},
    {SMAP400_X2, 0},
    {SMAP400_Y2, 0},
    {SMAP700_X1, 0},
    {SMAP700_Y1, 0},
    {SMAP700_X2, 0},
    {SMAP700_Y2, 0},
    {MAGNIFY_UPY0, 0},
    {POINT_PNG_TARGET_X, 0},
    {POINT_PNG_TARGET_Y, 0},
    {CROSSBOW_X1, 0},
    {CROSSBOW_Y1, 0},
    {CROSSBOW_X2, 0},
    {CROSSBOW_Y2, 0},
    {CROSSBOW_4_2R, 0},
    {CROSSBOW_4_PNGY, 0},
    {CROSSBOW_25M_X1, 0},
    {CROSSBOW_25M_Y1, 0},
    {CROSSBOW_25M_X2, 0},
    {CROSSBOW_25M_Y2, 0},
    {CROSSBOW_X1_BOTTOM, 0},
    {CROSSBOW_Y1_BOTTOM, 0},
    {CROSSBOW_X2_BOTTOM, 0},
    {CROSSBOW_Y2_BOTTOM, 0},
    {CROSSBOW_4_PNGY_BOTTOM, 0},
    {CHECK_SMAP_POINT_SOLO,0}   //有动态变化需求，数据库map只提供存储
};

QMap<int,double> doubleMapData = {
    {SCREEN_MAGNIFY , 0},
    {WINMAGNIFY_N,0}

};

QMap<int,QColor> QColorMapData = {
    {SMAP_COLOR, QColor(Qt::green)},
    {40,  QColor(Qt::black)},
    {50,  QColor(Qt::blue)},
    {60,  QColor(Qt::black)},
    {70,  QColor(Qt::white)},
    {80,  QColor(Qt::white)},
    {90,  QColor(Qt::black)},
    {100, QColor(Qt::green)},

    {110, QColor(Qt::black)},
    {120, QColor(Qt::white)},
    {130, QColor(Qt::white)},
    {140, QColor(Qt::black)},
    {150, QColor(Qt::blue)},

    {160, QColor(Qt::black)},
    {170, QColor(Qt::white)},
    {180, QColor(Qt::white)},
    {190, QColor(Qt::black)},
    {200, QColor(Qt::green)},

    {210, QColor(Qt::black)},
    {220, QColor(Qt::white)},
    {230, QColor(Qt::white)},
    {240, QColor(Qt::black)},
    {250, QColor(Qt::blue)},

    {260, QColor(Qt::black)},
    {270, QColor(Qt::white)},
    {280, QColor(Qt::white)},
    {290, QColor(Qt::black)},
    {300, QColor(Qt::green)},

    {310, QColor(Qt::red)}
};


//特殊的数据库变量******************************************************
int check_sMap_Point_Solo;//勾选框		0关闭 1打开

int Magnify_UPy0=0;		//向上偏移量
float winMagnify_n = 1;


//非数据库变量**********************************************************

//sMap
int sMap_MeterSize = 400;//

int sendMeterToCrossbow = 0;//将自动测距的米数穿透到弩箭自动测距上，初始化为0

//win放大镜
bool winMagnify_Click = false;

bool use_winMagnify = false;

int crossbow_player_number = 0;//0黄1橙2蓝3绿

#endif // DEFINE_VAR_H

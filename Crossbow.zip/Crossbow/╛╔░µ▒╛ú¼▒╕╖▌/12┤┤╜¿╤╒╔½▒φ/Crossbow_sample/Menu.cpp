#include "Menu.h"

#include "ui_Menu.h"



Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);

    connect(ui->checkBoxRunning, &QCheckBox::stateChanged, this, &Menu::on_checkBoxRunning);

    //去除窗口标题栏
    setWindowFlags(Qt::FramelessWindowHint);

    //设置窗口大小
    resize(1067,600);

    // 不允许子部件根据 QScrollArea 的大小调整自身大小
    ui->scrollArea->setWidgetResizable(false);
    ui->scrollArea->setWidget(ui->widget);

}

Menu::~Menu()
{
    delete ui;
}

void Menu::closeEvent(QCloseEvent *event)
{
    //关闭菜单时，关闭其他窗口
    if(ui->checkBoxRunning->isChecked())
    {
        //小地图
        m_C_sMap->close();
        //小地图测距
        m_C_sMap_Point->close();
        //弩箭
        m_C_Crossbow->close();
    }
}

void Menu::setQColorMapData(const QMap<int, QColor> &newQColorMapData)
{
    m_QColorMapData = newQColorMapData;
}



void Menu::setDoubleMapData(const QMap<int, double> &newDoubleMapData)
{
    m_doubleMapData = newDoubleMapData;

    //将数据展示到ui控件上
    ui->screen_magnify->setValue(m_doubleMapData[SCREEN_MAGNIFY]);

    //特殊变量，不通过map赋值到ui控件
    //ui->winMagnify_n->setValue(m_doubleMapData[WINMAGNIFY_N]);
}

void Menu::getsMap_Point(int &check_sMap_Point_Solo)
{
    m_check_sMap_Point_Solo = &check_sMap_Point_Solo;

    connect(ui->checkBoxcheck_sMap_Point_Solo, &QCheckBox::stateChanged, this, &Menu::on_checkBoxcheck_sMap_Point_Solo);
    //将数据展示到ui控件上
    if (*m_check_sMap_Point_Solo==1)
    {
        ui->checkBoxcheck_sMap_Point_Solo->setChecked(true);
    }

}

void Menu::getcrossbow_player_number(int &crossbow_player_number)
{
    m_crossbow_player_number =& crossbow_player_number;

    //QIcon icon0("res/opencvImg/point_0.png");
    QIcon icon1("res/opencvImg/point_1.png");
    QIcon icon2("res/opencvImg/point_2.png");
    QIcon icon3("res/opencvImg/point_3.png");
    QIcon icon4("res/opencvImg/point_4.png");

    // ui->comboBoxPlayerNumber->addItem(icon0,"0");
    // ui->comboBoxPlayerNumber->addItem(icon1,"1");
    // ui->comboBoxPlayerNumber->addItem(icon2,"2");
    // ui->comboBoxPlayerNumber->addItem(icon3,"3");
    // ui->comboBoxPlayerNumber->addItem(icon4,"4");

    //ui->comboBoxPlayerNumber->addItem(icon0,"单排/1号");
    ui->comboBoxPlayerNumber->addItem(icon1,"1号");
    ui->comboBoxPlayerNumber->addItem(icon2,"2号");
    ui->comboBoxPlayerNumber->addItem(icon3,"3号");
    ui->comboBoxPlayerNumber->addItem(icon4,"4号");

    ui->comboBoxPlayerNumber->setIconSize(QSize(32, 44));
    //ui->comboBoxPlayerNumber->setIconSize(QSize(64, 88));
}

void Menu::getsMap_MeterSize(int &sMap_MeterSize)
{
    m_sMap_MeterSize =&sMap_MeterSize;




}

bool Menu::on_checkBoxcheck_sMap_Point_Solo(bool checked)
{
    if (ui->checkBoxcheck_sMap_Point_Solo->isChecked())
    {
        *m_check_sMap_Point_Solo = 1;
    }
    else
    {
        *m_check_sMap_Point_Solo = 0;
    }

    return false;
}

void Menu::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;

    //将数据展示到ui控件上
    ui->screen_resolution_x->setValue(m_intMapData[SCREEN_RESOLUTION_X]);
    ui->screen_resolution_y->setValue(m_intMapData[SCREEN_RESOLUTION_Y]);

    ui->sMap400_x1->setValue(m_intMapData[SMAP400_X1]);
    ui->sMap400_y1->setValue(m_intMapData[SMAP400_Y1]);
    ui->sMap400_x2->setValue(m_intMapData[SMAP400_X2]);
    ui->sMap400_y2->setValue(m_intMapData[SMAP400_Y2]);

    ui->sMap700_x1->setValue(m_intMapData[SMAP700_X1]);
    ui->sMap700_y1->setValue(m_intMapData[SMAP700_Y1]);
    ui->sMap700_x2->setValue(m_intMapData[SMAP700_X2]);
    ui->sMap700_y2->setValue(m_intMapData[SMAP700_Y2]);

    //特殊变量，不通过map赋值到ui控件
    //ui->Magnify_UPy0->setValue(m_intMapData[MAGNIFY_UPY0]);

    ui->point_PngTarget_x->setValue(m_intMapData[POINT_PNG_TARGET_X]);
    ui->point_PngTarget_y->setValue(m_intMapData[POINT_PNG_TARGET_Y]);

    ui->crossbow_x1->setValue(m_intMapData[CROSSBOW_X1]);
    ui->crossbow_y1->setValue(m_intMapData[CROSSBOW_Y1]);
    ui->crossbow_x2->setValue(m_intMapData[CROSSBOW_X2]);
    ui->crossbow_y2->setValue(m_intMapData[CROSSBOW_Y2]);
    ui->crossbow_4_2R->setValue(m_intMapData[CROSSBOW_4_2R]);
    ui->crossbow_4_PngY->setValue(m_intMapData[CROSSBOW_4_PNGY]);
    ui->crossbow_25m_x1->setValue(m_intMapData[CROSSBOW_25M_X1]);
    ui->crossbow_25m_y1->setValue(m_intMapData[CROSSBOW_25M_Y1]);
    ui->crossbow_25m_x2->setValue(m_intMapData[CROSSBOW_25M_X2]);
    ui->crossbow_25m_y2->setValue(m_intMapData[CROSSBOW_25M_Y2]);
    ui->crossbow_x1_bottom->setValue(m_intMapData[CROSSBOW_X1_BOTTOM]);
    ui->crossbow_y1_bottom->setValue(m_intMapData[CROSSBOW_Y1_BOTTOM]);
    ui->crossbow_x2_bottom->setValue(m_intMapData[CROSSBOW_X2_BOTTOM]);
    ui->crossbow_y2_bottom->setValue(m_intMapData[CROSSBOW_Y2_BOTTOM]);
    ui->crossbow_4_PngY_bottom->setValue(m_intMapData[CROSSBOW_4_PNGY_BOTTOM]);

}



void Menu::on_btnSave_clicked()
{
    //特殊变量 ，先存到map里 ，在由map存入数据库
    if (ui->checkBoxcheck_sMap_Point_Solo->isChecked())
    {
        // m_intMapData[CHECK_SMAP_POINT_SOLO]=1;
        // *m_check_sMap_Point_Solo = m_intMapData[CHECK_SMAP_POINT_SOLO];
        *m_check_sMap_Point_Solo=1;
    }
    else
    {
        // m_intMapData[CHECK_SMAP_POINT_SOLO]=0;
        // *m_check_sMap_Point_Solo = m_intMapData[CHECK_SMAP_POINT_SOLO];
        *m_check_sMap_Point_Solo=0;
    }
    m_intMapData[CHECK_SMAP_POINT_SOLO]=*m_check_sMap_Point_Solo;

    *m_Magnify_UPy0 = ui->Magnify_UPy0->value();
    m_intMapData[MAGNIFY_UPY0]=*m_Magnify_UPy0;

    *m_winMagnify_n = ui->winMagnify_n->value();
    m_doubleMapData[WINMAGNIFY_N]=*m_winMagnify_n;

    //将ui控件的数据写入Map
    //int
    m_intMapData[SCREEN_RESOLUTION_X] = ui->screen_resolution_x->value();
    m_intMapData[SCREEN_RESOLUTION_Y] = ui->screen_resolution_y->value();

    m_intMapData[SMAP400_X1] = ui->sMap400_x1->value();
    m_intMapData[SMAP400_Y1] = ui->sMap400_y1->value();
    m_intMapData[SMAP400_X2] = ui->sMap400_x2->value();
    m_intMapData[SMAP400_Y2] = ui->sMap400_y2->value();

    m_intMapData[SMAP700_X1] = ui->sMap700_x1->value();
    m_intMapData[SMAP700_Y1] = ui->sMap700_y1->value();
    m_intMapData[SMAP700_X2] = ui->sMap700_x2->value();
    m_intMapData[SMAP700_Y2] = ui->sMap700_y2->value();

    m_intMapData[MAGNIFY_UPY0]=ui->Magnify_UPy0->value();

    m_intMapData[POINT_PNG_TARGET_X]=ui->point_PngTarget_x->value();
    m_intMapData[POINT_PNG_TARGET_Y]=ui->point_PngTarget_y->value();

    m_intMapData[CROSSBOW_X1] = ui->crossbow_x1->value();
    m_intMapData[CROSSBOW_Y1] = ui->crossbow_y1->value();
    m_intMapData[CROSSBOW_X2] = ui->crossbow_x2->value();
    m_intMapData[CROSSBOW_Y2] = ui->crossbow_y2->value();
    m_intMapData[CROSSBOW_4_2R] = ui->crossbow_4_2R->value();
    m_intMapData[CROSSBOW_4_PNGY] = ui->crossbow_4_PngY->value();
    m_intMapData[CROSSBOW_25M_X1] = ui->crossbow_25m_x1->value();
    m_intMapData[CROSSBOW_25M_Y1] = ui->crossbow_25m_y1->value();
    m_intMapData[CROSSBOW_25M_X2] = ui->crossbow_25m_x2->value();
    m_intMapData[CROSSBOW_25M_Y2] = ui->crossbow_25m_y2->value();
    m_intMapData[CROSSBOW_X1_BOTTOM] = ui->crossbow_x1_bottom->value();
    m_intMapData[CROSSBOW_Y1_BOTTOM] = ui->crossbow_y1_bottom->value();
    m_intMapData[CROSSBOW_X2_BOTTOM] = ui->crossbow_x2_bottom->value();
    m_intMapData[CROSSBOW_Y2_BOTTOM] = ui->crossbow_y2_bottom->value();
    m_intMapData[CROSSBOW_4_PNGY_BOTTOM] = ui->crossbow_4_PngY_bottom->value();





    //double
    m_doubleMapData[SCREEN_MAGNIFY] = ui->screen_magnify->value();
    m_doubleMapData[WINMAGNIFY_N]=ui->winMagnify_n->value();





    //将map写入数据库
    C_SQL sql;
    sql.write_intMapData(m_intMapData);
    sql.write_doubleMapData(m_doubleMapData);
    sql.write_QColorMapData(m_QColorMapData);

    //将map更新到其他类里
    if(ui->checkBoxRunning->isChecked())
    {
        //小地图
        if(1)
        {
            m_C_sMap->getxy
                (
                    m_intMapData[SMAP400_X1],
                    m_intMapData[SMAP400_Y1],
                    m_intMapData[SMAP400_X2],
                    m_intMapData[SMAP400_Y2],

                    m_intMapData[SMAP700_X1],
                    m_intMapData[SMAP700_Y1],
                    m_intMapData[SMAP700_X2],
                    m_intMapData[SMAP700_Y2],

                    m_doubleMapData[SCREEN_MAGNIFY],

                    *m_sMap_MeterSize
                    );
        }

        //小地图测距
        if(1)
        {
            m_C_sMap_Point->getxy
                (
                    *m_check_sMap_Point_Solo,
                    *m_sMap_MeterSize,


                    m_intMapData[SMAP400_X1],
                    m_intMapData[SMAP400_Y1],
                    m_intMapData[SMAP400_X2],
                    m_intMapData[SMAP400_Y2],

                    m_intMapData[SMAP700_X1],
                    m_intMapData[SMAP700_Y1],
                    m_intMapData[SMAP700_X2],
                    m_intMapData[SMAP700_Y2],

                    m_doubleMapData[SCREEN_MAGNIFY],

                    m_intMapData[POINT_PNG_TARGET_X],
                    m_intMapData[POINT_PNG_TARGET_Y]


                    );
        }

        //弩箭
        if(1)
        {
            m_C_Crossbow->getxy
                (
                    m_intMapData[CROSSBOW_X1],
                    m_intMapData[CROSSBOW_Y1],
                    m_intMapData[CROSSBOW_X2],
                    m_intMapData[CROSSBOW_Y2],
                    m_intMapData[CROSSBOW_4_2R],
                    m_intMapData[CROSSBOW_4_PNGY],

                    m_doubleMapData[SCREEN_MAGNIFY],

                    m_intMapData[SCREEN_RESOLUTION_X],
                    m_intMapData[SCREEN_RESOLUTION_Y],

                    m_intMapData[CROSSBOW_25M_X1],
                    m_intMapData[CROSSBOW_25M_Y1],
                    m_intMapData[CROSSBOW_25M_X2],
                    m_intMapData[CROSSBOW_25M_Y2],

                    m_intMapData[CROSSBOW_X1_BOTTOM],
                    m_intMapData[CROSSBOW_Y1_BOTTOM],
                    m_intMapData[CROSSBOW_X2_BOTTOM],
                    m_intMapData[CROSSBOW_Y2_BOTTOM],
                    m_intMapData[CROSSBOW_4_PNGY_BOTTOM]
                    );

            m_C_Crossbow->resize
                (
                    m_intMapData[SCREEN_RESOLUTION_X] / (m_doubleMapData[SCREEN_MAGNIFY]),
                    m_intMapData[SCREEN_RESOLUTION_Y] / (m_doubleMapData[SCREEN_MAGNIFY])
                    );
        }
    }


}


bool Menu::on_checkBoxRunning(bool checked)
{
    *m_use_winMagnify = true;

    //QMessageBox::information(this, "", "开始运行");

    //小地图
    if(ui->checkBoxRunning->isChecked())
    {
        m_C_sMap = new C_sMap;

        m_C_sMap->getxy
            (
            m_intMapData[SMAP400_X1],
            m_intMapData[SMAP400_Y1],
            m_intMapData[SMAP400_X2],
            m_intMapData[SMAP400_Y2],

            m_intMapData[SMAP700_X1],
            m_intMapData[SMAP700_Y1],
            m_intMapData[SMAP700_X2],
            m_intMapData[SMAP700_Y2],

            m_doubleMapData[SCREEN_MAGNIFY],

                *m_sMap_MeterSize
                );

        //m_C_sMap->getcheck_sMap_DrawArc(*m_check_sMap_DrawArc);

        m_C_sMap->getpenColor
            (
                Qt::red
                // QColor
                // (
                //     ui.sMap_Manager_R->value(),
                //     ui.sMap_Manager_G->value(),
                //     ui.sMap_Manager_B->value()
                //     )
                );

        m_C_sMap->startTimer();

        m_C_sMap->show();
    }
    else
    {
        m_C_sMap->stopTimer();
        m_C_sMap->close();
        delete m_C_sMap;
        m_C_sMap = nullptr;
    }

    //小地图自动测距
    if (ui->checkBoxRunning->isChecked())
    {
        m_C_sMap_Point = new C_sMap_Point;

        m_C_sMap_Point->getxy
            (
                *m_check_sMap_Point_Solo,
                *m_sMap_MeterSize,


                m_intMapData[SMAP400_X1],
                m_intMapData[SMAP400_Y1],
                m_intMapData[SMAP400_X2],
                m_intMapData[SMAP400_Y2],

                m_intMapData[SMAP700_X1],
                m_intMapData[SMAP700_Y1],
                m_intMapData[SMAP700_X2],
                m_intMapData[SMAP700_Y2],

                m_doubleMapData[SCREEN_MAGNIFY],

                m_intMapData[POINT_PNG_TARGET_X],
                m_intMapData[POINT_PNG_TARGET_Y]


                );

        m_C_sMap_Point->getsendMeterToCrossbow(*m_sendMeterToCrossbow);

        m_C_sMap_Point->getcrossbow_player_number(*m_crossbow_player_number);

        m_C_sMap_Point->startTimer();

        m_C_sMap_Point->show();

    }
    else
    {
        m_C_sMap_Point->stopTimer();
        m_C_sMap_Point->close();
        delete m_C_sMap_Point;
        m_C_sMap_Point = nullptr;
    }

    //弩箭动态准心
    if (ui->checkBoxRunning->isChecked())
    {
        m_C_Crossbow = new C_Crossbow;


        m_C_Crossbow->getxy
            (
                m_intMapData[CROSSBOW_X1],
                m_intMapData[CROSSBOW_Y1],
                m_intMapData[CROSSBOW_X2],
                m_intMapData[CROSSBOW_Y2],
                m_intMapData[CROSSBOW_4_2R],
                m_intMapData[CROSSBOW_4_PNGY],

                m_doubleMapData[SCREEN_MAGNIFY],

                m_intMapData[SCREEN_RESOLUTION_X],
                m_intMapData[SCREEN_RESOLUTION_Y],

                m_intMapData[CROSSBOW_25M_X1],
                m_intMapData[CROSSBOW_25M_Y1],
                m_intMapData[CROSSBOW_25M_X2],
                m_intMapData[CROSSBOW_25M_Y2],

                m_intMapData[CROSSBOW_X1_BOTTOM],
                m_intMapData[CROSSBOW_Y1_BOTTOM],
                m_intMapData[CROSSBOW_X2_BOTTOM],
                m_intMapData[CROSSBOW_Y2_BOTTOM],
                m_intMapData[CROSSBOW_4_PNGY_BOTTOM]
                );

        m_C_Crossbow->getsendMeterToCrossbow(*m_sendMeterToCrossbow);

        m_C_Crossbow->getcrossbow_player_number(*m_crossbow_player_number);

        m_C_Crossbow->resize
            (
                m_intMapData[SCREEN_RESOLUTION_X] / (m_doubleMapData[SCREEN_MAGNIFY]),
                m_intMapData[SCREEN_RESOLUTION_Y] / (m_doubleMapData[SCREEN_MAGNIFY])
                );


        m_C_Crossbow->startTimer();

        m_C_Crossbow->show();

    }
    else
    {
        m_C_Crossbow->stopTimer();
        m_C_Crossbow->close();
        delete m_C_Crossbow;
        m_C_Crossbow = nullptr;
    }



    return false;
}

void Menu::getsendMeterToCrossbow(int &sendMeterToCrossbow)
{
    m_sendMeterToCrossbow = &sendMeterToCrossbow;
}

void Menu::getMagnify(int &Magnify_UPy0, float &winMagnify_n)
{
    m_Magnify_UPy0 = &Magnify_UPy0;
    m_winMagnify_n = &winMagnify_n;

    //赋值到菜单控件
    ui->Magnify_UPy0->setValue(*m_Magnify_UPy0);
    ui->winMagnify_n->setValue(*m_winMagnify_n);
}

void Menu::getuse_winMagnify(bool &use_winMagnify)
{
    m_use_winMagnify = &use_winMagnify;

    //ui->Magnify_UPy0->setValue(*m_Magnify_UPy0);
    //ui->winMagnify_n->setValue(*m_winMagnify_n);
}


void Menu::on_comboBoxPlayerNumber_activated(int index)
{
    *m_crossbow_player_number = index;

    ui->playerNumber->setText(QString::number(index));
}




void Menu::on_btnClose_clicked()
{
    close();
}


void Menu::on_btnMinimize_clicked()
{
    showMinimized();
}


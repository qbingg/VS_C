#include "C_Crossbow.h"

C_Crossbow::C_Crossbow(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setWindowTitle("弩箭动态准心");
    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);

    setAttribute(Qt::WA_TranslucentBackground);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &C_Crossbow::updateWidget);
    //resize(1920 * 0.8, 1200 * 0.8);

    //初始化图片
    target_img = cv::imread("res/opencvImg/crossbow4x.png");
    target_img_bottom = cv::imread("res/opencvImg/crossbow4x_bottom.png");
    target_back = cv::imread("res/opencvImg/crossbow4x_Back.png");
    target_25m = cv::imread("res/opencvImg/crossbow4x_25m.png",0);

}

C_Crossbow::~C_Crossbow()
{}

void C_Crossbow::paintEvent(QPaintEvent * event)
{
    if (GetAsyncKeyState(VK_RBUTTON))
    {
        QPainter painter(this);

        painter.setPen(player_number_color[*crossbow_player_number]);
        QFont font1;
        font1.setPointSizeF(15);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);


        //对个位数进行不足近似,米数
        int round = ((*sendMeterToCrossbow) / 10) * 10;//186m->180m

        //将“不足近似”输出到屏幕
        painter.drawText((screen_resolution_x / 2) * magnify_n + 480, res_y2 * magnify_n, QString::number(round));

        //4倍镜顶部输出参数
        QString top = "顶部y：" + QString::number(res_y2);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 550, res_y2 * magnify_n, top);
        QString n_top = "顶部n：" + QString::number(n2, 'f', 4);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 550, res_y2 * magnify_n+20, n_top);
        //4倍镜底部输出参数
        QString bottom = "底部y：" + QString::number(res_y2_bottom);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 700, res_y2 * magnify_n, bottom);
        QString n_bottom = "底部n：" + QString::number(n2_bottom, 'f', 4);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 700, res_y2 * magnify_n+20, n_bottom);


        //如果不是弩箭开镜，则函数立刻结束，不划线
        if (n_25m < 0.8)
        {
            return;
        }

        //如果顶部和底部测得的y值相近，优先使用顶部的y2
        int res_y = res_y2;
        int differentResult = abs(res_y2 - res_y2_bottom);//计算两个res_y2的绝对差值

        //如果res_y2的绝对差值大于2
        if (differentResult > 2)
        {
            //如果底部拟合度大于顶部，使用底部数据划线
            if (n2_bottom>n2)
            {
                res_y = res_y2_bottom;

                painter.drawText((screen_resolution_x / 2) * magnify_n + 700, res_y * magnify_n + 40, "使用底部数据划线");
            }
        }



        //通过map查询刻度是否存在: round,和round+10
        if ((meterToPixel.count(round)) && (meterToPixel.count(round + 10)))
        {
            //通过map查询刻度 round,和round+10
            int sendMeterToCrossbowHeight =
                (
                    res_y //四倍镜准心高度

                    + meterToPixel[round]//180m刻度对应的高度

                    //186-180 = 6得到6/10=0.6  得到 0.6*（190m与180m对应刻度像素的差值）
                    + (((*sendMeterToCrossbow) - static_cast<double>(round)) / 10) * (meterToPixel[round + 10] - meterToPixel[round])

                    ) * magnify_n;


            //标出米数
            painter.drawText((screen_resolution_x / 2) * magnify_n - 60, sendMeterToCrossbowHeight - 3 , QString::number(*sendMeterToCrossbow));


            //大于等于40m，划线
            if (round >= 40)
            {
                //painter.setPen(Qt::yellow);

                painter.drawLine
                    (
                        ((screen_resolution_x - crossbow_4_R) / 2) * magnify_n,

                        sendMeterToCrossbowHeight,

                        ((screen_resolution_x + crossbow_4_R) / 2) * magnify_n,

                        sendMeterToCrossbowHeight
                        );
            }


        }
        else//如果不存在，则不划线
        {
            //标出米数
            painter.drawText((screen_resolution_x / 2) * magnify_n - 60, (res_y) * magnify_n - 3, QString::number(*sendMeterToCrossbow));
        }




        QFont meter_rank;
        font1.setPointSizeF(7);
        painter.setFont(meter_rank);
        painter.setBrush(Qt::NoBrush);


        int max = 4 * magnify_n;//字体误差

        int X = (screen_resolution_x / static_cast<double>(2)) * magnify_n;


        for (int meter = 40; meter <= 310; meter += 10)
        {
            painter.setPen(QPenMap[meter]);
            painter.drawLine
                (
                    X,

                    (res_y + meterToPixel[meter])* magnify_n,

                    X + LineMap[meter],

                    (res_y + meterToPixel[meter])* magnify_n
                    );
            painter.drawText
                (

                        X + LineMap[meter],

                    max + (res_y + meterToPixel[meter]) * magnify_n,

                    QString::number(meter)
                    );
        }

    }
}

void C_Crossbow::startTimer()
{
    m_timer->start(33);
}

void C_Crossbow::stopTimer()
{
    m_timer->stop();
}

void C_Crossbow::getxy(int m_crossbow_x1, int m_crossbow_y1, int m_crossbow_x2, int m_crossbow_y2, int m_crossbow_4_2R, int m_crossbow_4_PngY, double m_magnify_n, int m_screen_resolution_x, int m_screen_resolution_y, int m_crossbow_25m_x1, int m_crossbow_25m_y1, int m_crossbow_25m_x2, int m_crossbow_25m_y2, int m_crossbow_x1_bottom, int m_crossbow_y1_bottom, int m_crossbow_x2_bottom, int m_crossbow_y2_bottom, int m_crossbow_4_PngY_bottom)
{
    crossbow_x1 = m_crossbow_x1;
    crossbow_y1 = m_crossbow_y1;
    crossbow_x2 = m_crossbow_x2;
    crossbow_y2 = m_crossbow_y2;
    crossbow_4_R = m_crossbow_4_2R / static_cast<double>(2);//直径-》》半径
    crossbow_4_PngY = m_crossbow_4_PngY;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    screen_resolution_x = m_screen_resolution_x;
    screen_resolution_y = m_screen_resolution_y;

    crossbow_25m_x1 = m_crossbow_25m_x1;
    crossbow_25m_y1 = m_crossbow_25m_y1;
    crossbow_25m_x2 = m_crossbow_25m_x2;
    crossbow_25m_y2 = m_crossbow_25m_y2;



    crossbow_x1_bottom = m_crossbow_x1_bottom;
    crossbow_y1_bottom = m_crossbow_y1_bottom;
    crossbow_x2_bottom = m_crossbow_x2_bottom;
    crossbow_y2_bottom = m_crossbow_y2_bottom;
    crossbow_4_PngY_bottom = m_crossbow_4_PngY_bottom;

    //m_k = crossbow_4_310m / static_cast<double>(479);

    // 提前算好 【四倍镜半径像素 *（百分比刻度）】
    for (auto& [key, value] : percentage)
    {
        //meterToPixel.insert({ key,value * crossbow_4_R });//百分比*4倍镜半径 //insert不能插入已经存在的键，及不能修改覆盖
        //解决方法也非常简单，先初始化meterToPixel[40]~[310],值为0，先占茅坑不拉屎。省去第一次插入，只有修改
        meterToPixel[key] = value * crossbow_4_R;
    }

}


void C_Crossbow::updateWidget()
{
    GetAsyncKeyState(VK_RBUTTON);
    if (GetAsyncKeyState(VK_RBUTTON))
    {
        if (!updateOnceToClear)
        {
            Sleep(400);
        }
        function_screen(screen, crossbow_25m_x1, crossbow_25m_y1, crossbow_25m_x2, crossbow_25m_y2);
        n_25m = function_match_25m(screen);

        function_screen(screen, crossbow_x1, crossbow_y1, crossbow_x2, crossbow_y2);
        n1=function_templematch_advance(screen, res_y1);
        //function_screenGray(screen, crossbow_x1, crossbow_y1, crossbow_x2, crossbow_y2);
        n2 = function_templematch(screen, res_y2);

        //底部
        function_screen(screen, crossbow_x1_bottom, crossbow_y1_bottom, crossbow_x2_bottom, crossbow_y2_bottom);
        n2_bottom = function_templematch_bottom(screen, res_y2_bottom);


        update();
        updateOnceToClear = true;
    }
    GetAsyncKeyState(VK_RBUTTON);
    if ((!GetAsyncKeyState(VK_RBUTTON)) && updateOnceToClear)
    {
        //Sleep(100);
        updateOnceToClear = false;
        update();
    }
}

//截取指定区域图像函数(彩色),在本类中默认转换为负片
void C_Crossbow::function_screen(cv::Mat& image, int x1, int y1, int x2, int y2)
{

    //PUBG窗口截图方式
    LPCWSTR str = PUBGWINDOWNAME;
    // 1. 查找窗口句柄

    //LPCWSTR str = L"**高校水电费管理系统——20231862卢伟明";

    //LPCWSTR str = L"PUBG：绝地求生 ";//md后面藏了个空格!!!!!!!!!!!!!!!!!       D:\SEenvironment\VisualSC2022\Community\Common7\Tools\spyxx_amd64.exe
    // LPCWSTR str = L"TslGame";

    HWND hwnd = FindWindowW(NULL, str);
    if (hwnd == NULL) {
        //exit(0);
        //QMessageBox::information(this, "错误", "截图失败，获取窗口失败");
        return;
    }
    //const char* processName = "your_process_name.exe"; // Replace with the actual process name
    //HWND hwnd = FindMainWindowByProcessName(processName);


    // 获取屏幕设备的上下文
    HDC hScreenDC = GetWindowDC(hwnd);

    // 3. 获取窗口尺寸
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) {
        //std::cerr << "无法获取窗口尺寸" << std::endl;
        //QMessageBox::information(this, "错误", "截图失败，无法获取窗口尺寸");
        ReleaseDC(hwnd, hScreenDC);
        return;
    }







    // 获取屏幕设备的上下文
    //HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

    // 锁定位图的像素区域以便访问
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像
    //cv::Mat grayScreenshot;
    //cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    // 将图像转为负片
    cv::subtract(cv::Scalar(255, 255, 255), screenshot, screenshot);
    //TESTImage = screenshot.clone();

    //cv::imwrite("test.png", screenshot);

    image = screenshot;

    //cv::Mat imgGRAY;
    //cv::cvtColor(screenshot, imgGRAY, cv::COLOR_BGRA2BGR);
    ////cv::cvtColor(imgGRAY, img_GRAY, cv::COLOR_BGR2GRAY);
    //img_GRAY = imgGRAY.clone();

}

float C_Crossbow::function_templematch_advance(cv::Mat image, int& res_y)
{
    using namespace cv;

    //Mat image = imread("image.png");
    //Mat image_target = imread("image_target.png");
    Mat image_target = target_back;

    //TESTImage = image_target.clone();


    if (image.empty())
    {
        return 0;
    }

    Mat hsv_image;
    cvtColor(image, hsv_image, COLOR_BGR2HSV);
    Mat hsv_image_target;
    cvtColor(image_target, hsv_image_target, COLOR_BGR2HSV);

    // Quantize the hue to 30 levels                            将色相量化为 30 个级别
    // and the saturation to 32 levels                          饱和度为 32 个级别
    int hbins = 30, sbins = 32;
    int histSize[] = { hbins, sbins };
    // hue varies from 0 to 179, see cvtColor                   色相从 0 到 179 不等，请参阅 cvtColor
    float hranges[] = { 0, 180 };
    // saturation varies from 0 (black-gray-white) to           饱和度从 0（黑-灰-白）到
    // 255 (pure spectrum color)                                255（纯光谱色）
    float sranges[] = { 0, 256 };
    const float* ranges[] = { hranges, sranges };
    MatND hist;
    // we compute the histogram from the 0-th and 1-st channels 我们从第 0 个和第 1 个通道计算直方图
    int channels[] = { 0, 1 };
    calcHist(&hsv_image_target, 1, channels, Mat(), // do not use mask       不要使用蒙版
             hist, 2, histSize, ranges,
             true, // the histogram is uniform                       直方图是均匀的
             false);


    //归一化直方图
    normalize(hist, hist, 0, 255, NORM_MINMAX, -1, Mat());
    //normalize(template_hist, template_hist, 0, 255, cv::NORM_MINMAX, -1, cv::Mat());


    ////namedWindow("hist", WINDOW_FREERATIO);
    ////imshow("hist", hist);



    // 反投影“模板直方图”到图像上
    cv::Mat back_proj;
    calcBackProject(&hsv_image, 1, channels, hist, back_proj, ranges, 1, true);


    //namedWindow("back_proj", WINDOW_FREERATIO);
    //imshow("back_proj", back_proj);
    //TESTImage = back_proj.clone();

    //waitKey(0);

    // 注意：C++中通常不使用cv::filter2D进行形态学操作，而是使用cv::dilate等
    // 这里我们跳过卷积部分，因为它不适用于形态学增强



    // 使用固定阈值并创建二值图像
    //double threshold = 240;
    cv::Mat thresh;
    threshold(back_proj, thresh, 200, 255, cv::THRESH_BINARY);

    // 进行按位与操作以提取匹配区域
    cv::Mat thresh_result;
    bitwise_and(image, image, thresh_result, thresh);

    //namedWindow("result", WINDOW_FREERATIO);
    //imshow("result", thresh_result);
    //TESTImage = thresh_result.clone();

    //double maxVal = 0;
    //minMaxLoc(hist, 0, &maxVal, 0, 0);
    //int scale = 10;
    //Mat histImg = Mat::zeros(sbins * scale, hbins * 10, CV_8UC3);
    //for (int h = 0; h < hbins; h++)
    //    for (int s = 0; s < sbins; s++)
    //    {
    //        float binVal = hist.at<float>(h, s);
    //        int intensity = cvRound(binVal * 255 / maxVal);
    //        rectangle(histImg, Point(h * scale, s * scale),
    //            Point((h + 1) * scale - 1, (s + 1) * scale - 1),
    //            Scalar::all(intensity),
    //            -1);
    //    }
    //namedWindow("Source", 1);
    //imshow("Source", image);

    //applyColorMap(histImg, histImg, COLORMAP_JET);

    //namedWindow("H-S Histogram", 1);
    //imshow("H-S Histogram", histImg);


    cv::Mat src;
    cv::Mat templ;

    cvtColor(thresh_result, src, COLOR_HSV2BGR);
    cvtColor(src, src, COLOR_BGR2GRAY);

    //templ = cv::imread("test.png", 0);
    templ = target_img;
    cvtColor(templ, templ, cv::COLOR_BGR2GRAY);

    //TESTImage = templ.clone();


    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点


    //res_y = 200 + 325 + ptMaxLoc.y;
    res_y = crossbow_y1 + crossbow_4_PngY+ crossbow_4_R + ptMaxLoc.y;






    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/





    //waitKey(0);

    return dMaxVal;
}

void C_Crossbow::function_screenGray(cv::Mat& image, int x1, int y1, int x2, int y2)
{

    //PUBG窗口截图方式
    LPCWSTR str = PUBGWINDOWNAME;
    // 1. 查找窗口句柄

    //LPCWSTR str = L"**高校水电费管理系统——20231862卢伟明";

    //LPCWSTR str = L"PUBG：绝地求生 ";//md后面藏了个空格!!!!!!!!!!!!!!!!!       D:\SEenvironment\VisualSC2022\Community\Common7\Tools\spyxx_amd64.exe
    // LPCWSTR str = L"TslGame";

    HWND hwnd = FindWindowW(NULL, str);
    if (hwnd == NULL) {
        //exit(0);
        //QMessageBox::information(this, "错误", "截图失败，获取窗口失败");
        return;
    }
    //const char* processName = "your_process_name.exe"; // Replace with the actual process name
    //HWND hwnd = FindMainWindowByProcessName(processName);


    // 获取屏幕设备的上下文
    HDC hScreenDC = GetWindowDC(hwnd);

    // 3. 获取窗口尺寸
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) {
        //std::cerr << "无法获取窗口尺寸" << std::endl;
        //QMessageBox::information(this, "错误", "截图失败，无法获取窗口尺寸");
        ReleaseDC(hwnd, hScreenDC);
        return;
    }







    // 获取屏幕设备的上下文
    //HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

    // 锁定位图的像素区域以便访问
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像
    cv::Mat grayScreenshot;
    cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    // 将图像转为负片
    //cv::subtract(cv::Scalar(255, 255, 255), screenshot, screenshot);
    //TESTImage = screenshot.clone();

    //cv::imwrite("test.png", screenshot);

    image = grayScreenshot;

    //cv::Mat imgGRAY;
    //cv::cvtColor(screenshot, imgGRAY, cv::COLOR_BGRA2BGR);
    ////cv::cvtColor(imgGRAY, img_GRAY, cv::COLOR_BGR2GRAY);
    //img_GRAY = imgGRAY.clone();
}

float C_Crossbow::function_templematch(cv::Mat image, int& res_y)
{
    cv::Mat src = image;
    cv::Mat templ;

    //彩色截图
    cvtColor(src, src, cv::COLOR_BGR2GRAY);

    //templ = cv::imread("test.png", 0);
    templ = target_img;
    cvtColor(templ, templ, cv::COLOR_BGR2GRAY);

    //TESTImage = templ.clone();


    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点


    //res_y = 200 + 325 + ptMaxLoc.y;
    res_y = crossbow_y1 + crossbow_4_PngY + crossbow_4_R + ptMaxLoc.y;






    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/





    //waitKey(0);

    return dMaxVal;
}

float C_Crossbow::function_templematch_bottom(cv::Mat image, int& res_y)
{
    cv::Mat src = image;
    cv::Mat templ;

    //彩色截图
    cvtColor(src, src, cv::COLOR_BGR2GRAY);

    //templ = cv::imread("test.png", 0);
    templ = target_img_bottom;
    cvtColor(templ, templ, cv::COLOR_BGR2GRAY);

    //TESTImage = templ.clone();


    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点


    //res_y = 200 + 325 + ptMaxLoc.y;
    res_y = crossbow_y1_bottom + crossbow_4_PngY_bottom - crossbow_4_R + ptMaxLoc.y;






    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/





    //waitKey(0);

    return dMaxVal;
}

//int C_Crossbow::k(int x)
//{
//    return m_k * x;
//}

void C_Crossbow::getsendMeterToCrossbow(int& m_sendMeterToCrossbow)
{
    sendMeterToCrossbow = &m_sendMeterToCrossbow;
}

void C_Crossbow::getcrossbow_player_number(int &m_crossbow_player_number)
{
    crossbow_player_number=&m_crossbow_player_number;
}

void C_Crossbow::setPenColor(QMap<int, QColor> QColorMapData)
{
    for(int key :QPenMap.keys()){

        QPen newPen = QPen(QColorMapData[key], 1);

        QPenMap[key] = newPen;

    }
}

float C_Crossbow::function_match_25m(cv::Mat image)
{
    cv::Mat src = image;
    cv::Mat templ;

    // 将图像转为负片
    cv::subtract(cv::Scalar(255, 255, 255), src, src);

    //彩色截图
    cvtColor(src, src, cv::COLOR_BGR2GRAY);

    //templ = cv::imread("test.png", 0);
    templ = target_25m;
    //cvtColor(templ, templ, cv::COLOR_BGR2GRAY);

    //TESTImage = templ.clone();


    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点


    //res_y = 200 + 325 + ptMaxLoc.y;
    //res_y = crossbow_y1 + crossbow_4_PngY + crossbow_4_R + ptMaxLoc.y;






    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/





    //waitKey(0);

    return dMaxVal;
}

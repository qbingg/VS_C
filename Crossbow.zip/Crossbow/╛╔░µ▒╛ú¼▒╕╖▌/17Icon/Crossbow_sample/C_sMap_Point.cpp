#include "C_sMap_Point.h"

C_sMap_Point::C_sMap_Point(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setWindowTitle("小地图自动测距");
    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);

    setAttribute(Qt::WA_TranslucentBackground);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &C_sMap_Point::updateWidget);
    //resize(1920, 1080);

    //初始化模板图片
    for (int i = 0; i < 5; i++)
    {
        QString strNumber = QString::number(i);
        QString STR = "res/opencvImg/point_" + strNumber + ".png";
        cv::String stdSTR = STR.toStdString();

        img_point[i] = cv::imread(stdSTR);
    }

}

C_sMap_Point::~C_sMap_Point()
{}

void C_sMap_Point::getxy(int& m_check_sMap_Point_Solo, int& m_sMap_MeterSize, int m_sMap400_x1, int m_sMap400_y1, int m_sMap400_x2, int m_sMap400_y2, int m_sMap700_x1, int m_sMap700_y1, int m_sMap700_x2, int m_sMap700_y2, double m_magnify_n, int m_point_PngTarget_x,int m_point_PngTarget_y)
{
    check_sMap_Point_Solo = &m_check_sMap_Point_Solo;
    sMap_MeterSize = &m_sMap_MeterSize;

    sMap400_x1 = m_sMap400_x1;
    sMap400_y1 = m_sMap400_y1;
    sMap400_x2 = m_sMap400_x2;
    sMap400_y2 = m_sMap400_y2;

    sMap700_x1 = m_sMap700_x1;
    sMap700_y1 = m_sMap700_y1;
    sMap700_x2 = m_sMap700_x2;
    sMap700_y2 = m_sMap700_y2;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    point_PngTarget_x = m_point_PngTarget_x;
    point_PngTarget_y = m_point_PngTarget_y;

    if (*sMap_MeterSize == 400)
    {
        resize
            (
                (sMap400_x2 - sMap400_x1) * magnify_n,
                (sMap400_y2 - sMap400_y1) * magnify_n
                );

        move
            (
                sMap400_x1 * magnify_n,
                sMap400_y1 * magnify_n
                );
    }
    else if (*sMap_MeterSize == 700)
    {
        resize
            (
                (sMap700_x2 - sMap700_x1) * magnify_n,
                (sMap700_y2 - sMap700_y1) * magnify_n
                );

        move
            (
                sMap700_x1 * magnify_n,
                sMap700_y1 * magnify_n
                );
    }

    width400 = (sMap400_x2 - sMap400_x1) * magnify_n;
    height400 = (sMap400_x2 - sMap400_x2) * magnify_n;

    width700 = (sMap700_x2 - sMap700_x1) * magnify_n;
    height700 = (sMap700_x2 - sMap700_x2) * magnify_n;
}

void C_sMap_Point::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);


    //画框
    for (int i = 0; i < 5; i++)
    {
        if (n[i] > 0.3)
        {
            if (i == 0 && *check_sMap_Point_Solo == 1)
            {
                painter.setPen(QPen(penColor[i], 2));
                int X = target_point_x[i] * magnify_n;
                int Y = target_point_y[i] * magnify_n;
                painter.drawRect(X, Y, point_PngTarget_x * 2, point_PngTarget_y);
            }

            if (i != 0 && *check_sMap_Point_Solo == 0)
            {
                painter.setPen(QPen(penColor[i], 2));
                int X = target_point_x[i] * magnify_n;
                int Y = target_point_y[i] * magnify_n;
                painter.drawRect(X, Y, point_PngTarget_x * 2, point_PngTarget_y);
            }
        }
    }

    //计算距离
    QFont font1;
    font1.setPointSizeF(13);
    painter.setFont(font1);
    //四排，只显示combobox选中的玩家
    int player = *crossbow_player_number + 1;//0123>>1234
    for (int i = 0; i < 5; i++)
    {
        if (n[i]>0.3)
        {
            if (i == 0 && *check_sMap_Point_Solo == 1)//单人
            {
                painter.setPen(QPen(penColor[i]));
                float meter = function_Pixels_To_Meters(target_point_x[i], target_point_y[i]);
                QString strNumber = QString::number(meter, 'f', 0);
                QString STR = " " + strNumber + " 米";
                painter.drawText(0, 20 * (i + 1), STR);

                *sendMeterToCrossbow = meter;
            }

            if (i != 0 && *check_sMap_Point_Solo == 0)//四排
            {
                painter.setPen(QPen(penColor[i]));
                float meter = function_Pixels_To_Meters(target_point_x[i], target_point_y[i]);
                QString strNumber = QString::number(meter, 'f', 1);
                QString STR = " " + strNumber + "";
                painter.drawText(0, 20 * (i), STR);


                if (i==player)
                {
                    //四舍五入为整数，仅限非负数（避免舍弃小数导致结果偏小）
                    *sendMeterToCrossbow = meter + 0.5;
                }
                //*sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[1], target_point_y[1]);
            }
        }
        else if ((n[0] < 0.3) && (n[player] < 0.3))//单排 和四排？号 都没有检测到标点
        {
            *sendMeterToCrossbow = 0;
        }
    }

    //if (*check_sMap_Point_Solo == 1)//单人
    //{
    //    *sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[0], target_point_y[0]);
    //
    //}
    //else//四排，只显示1号的
    //{
    //    *sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[1], target_point_y[1]);
    //
    //}
}

void C_sMap_Point::startTimer()
{
    m_timer->start(100);
}

void C_sMap_Point::stopTimer()
{
    m_timer->stop();
}

void C_sMap_Point::updateWidget()
{
    //
    if (*sMap_MeterSize == 400)
    {
        resize
            (
                (sMap400_x2 - sMap400_x1) * magnify_n,
                (sMap400_y2 - sMap400_y1) * magnify_n
                );

        move
            (
                sMap400_x1 * magnify_n,
                sMap400_y1 * magnify_n
                );


        update();

    }
    else if (*sMap_MeterSize == 700)
    {
        resize
            (
                (sMap700_x2 - sMap700_x1) * magnify_n,
                (sMap700_y2 - sMap700_y1) * magnify_n
                );

        move
            (
                sMap700_x1 * magnify_n,
                sMap700_y1 * magnify_n
                );


        update();

    }

    for (int i = 0; i < 5; i++)
    {
        //function_screen(screen[i],i, 1373, 657, 1885, 1169);
        //function_screen(screen[i], i, 1373, 657, 1885, 1169);

        if (*sMap_MeterSize == 400)
        {
            //function_screen(screen[i],i, 1373, 657, 1885, 1169);

            function_screen(screen[i], i, sMap400_x1, sMap400_y1, sMap400_x2, sMap400_y2);

        }
        else if (*sMap_MeterSize == 700)
        {
            //function_screen(screen[i], i, 1373, 657, 1885, 1169);
            function_screen(screen[i], i, sMap700_x1, sMap700_y1, sMap700_x2, sMap700_y2);
        }

        n[i] = function_templematch_advance(screen[i],i);
    }


}

float C_sMap_Point::function_templematch_advance(cv::Mat image, int i)
{
    using namespace cv;

    //Mat image = imread("image.png");
    //Mat image_target = imread("image_target.png");
    Mat image_target = img_point[i];


    if (image.empty())
    {
        return 0;
    }

    Mat hsv_image;
    cvtColor(image, hsv_image, COLOR_BGR2HSV);
    Mat hsv_image_target;
    cvtColor(image_target, hsv_image_target, COLOR_BGR2HSV);

    // Quantize the hue to 30 levels                            将色相量化为 30 个级别
    // and the saturation to 32 levels                          饱和度为 32 个级别
    int hbins = 30, sbins = 32;
    int histSize[] = { hbins, sbins };
    // hue varies from 0 to 179, see cvtColor                   色相从 0 到 179 不等，请参阅 cvtColor
    float hranges[] = { 0, 180 };
    // saturation varies from 0 (black-gray-white) to           饱和度从 0（黑-灰-白）到
    // 255 (pure spectrum color)                                255（纯光谱色）
    float sranges[] = { 0, 256 };
    const float* ranges[] = { hranges, sranges };
    MatND hist;
    // we compute the histogram from the 0-th and 1-st channels 我们从第 0 个和第 1 个通道计算直方图
    int channels[] = { 0, 1 };
    calcHist(&hsv_image_target, 1, channels, Mat(), // do not use mask       不要使用蒙版
             hist, 2, histSize, ranges,
             true, // the histogram is uniform                       直方图是均匀的
             false);


    //归一化直方图
    normalize(hist, hist, 0, 255, NORM_MINMAX, -1, Mat());
    //normalize(template_hist, template_hist, 0, 255, cv::NORM_MINMAX, -1, cv::Mat());


    ////namedWindow("hist", WINDOW_FREERATIO);
    ////imshow("hist", hist);



    // 反投影“模板直方图”到图像上
    cv::Mat back_proj;
    calcBackProject(&hsv_image, 1, channels, hist, back_proj, ranges, 1, true);


    //namedWindow("back_proj", WINDOW_FREERATIO);
    //imshow("back_proj", back_proj);
    //TESTImage = back_proj;

    // 注意：C++中通常不使用cv::filter2D进行形态学操作，而是使用cv::dilate等
    // 这里我们跳过卷积部分，因为它不适用于形态学增强



    // 使用固定阈值并创建二值图像
    //double threshold = 240;
    cv::Mat thresh;
    threshold(back_proj, thresh, 240, 255, cv::THRESH_BINARY);

    // 进行按位与操作以提取匹配区域
    cv::Mat thresh_result;
    bitwise_and(image, image, thresh_result, thresh);

    //namedWindow("result", WINDOW_FREERATIO);
    //imshow("result", thresh_result);
    //TESTImage = thresh_result;

    //double maxVal = 0;
    //minMaxLoc(hist, 0, &maxVal, 0, 0);
    //int scale = 10;
    //Mat histImg = Mat::zeros(sbins * scale, hbins * 10, CV_8UC3);
    //for (int h = 0; h < hbins; h++)
    //    for (int s = 0; s < sbins; s++)
    //    {
    //        float binVal = hist.at<float>(h, s);
    //        int intensity = cvRound(binVal * 255 / maxVal);
    //        rectangle(histImg, Point(h * scale, s * scale),
    //            Point((h + 1) * scale - 1, (s + 1) * scale - 1),
    //            Scalar::all(intensity),
    //            -1);
    //    }
    //namedWindow("Source", 1);
    //imshow("Source", image);

    //applyColorMap(histImg, histImg, COLORMAP_JET);

    //namedWindow("H-S Histogram", 1);
    //imshow("H-S Histogram", histImg);


    cv::Mat src;
    cv::Mat templ;

    cvtColor(thresh_result, src, COLOR_HSV2BGR);
    cvtColor(src, src, COLOR_BGR2GRAY);

    //templ = cv::imread("image_target.png", 0);
    templ = img_point[i];
    cvtColor(templ, templ, cv::COLOR_BGR2GRAY);




    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点

    if (*sMap_MeterSize==400)
    {
        target_point_x[i] =  ptMaxLoc.x;
        target_point_y[i] =  ptMaxLoc.y;

        //target_point_x[i] = (sMap400_x1)*magnify_n + ptMaxLoc.x;
        //target_point_y[i] = (sMap400_y1)*magnify_n + ptMaxLoc.y;
    }
    else if (*sMap_MeterSize == 700)
    {
        //target_point_x[i] = (sMap700_x1)*magnify_n + ptMaxLoc.x;
        //target_point_y[i] = (sMap700_y1)*magnify_n + ptMaxLoc.y;

        target_point_x[i] = ptMaxLoc.x;
        target_point_y[i] = ptMaxLoc.y;
    }





    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(image, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(image, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("image", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("image", image);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/





    waitKey(0);

    return dMaxVal;
}

//截取指定区域图像函数(彩色)
void C_sMap_Point::function_screen(cv::Mat& image, int i, int x1, int y1, int x2, int y2)
{

    //PUBG窗口截图方式
    LPCWSTR str = PUBGWINDOWNAME;
    // 1. 查找窗口句柄

    //LPCWSTR str = L"**高校水电费管理系统——20231862卢伟明";

    //LPCWSTR str = L"PUBG：绝地求生 ";//md后面藏了个空格!!!!!!!!!!!!!!!!!       D:\SEenvironment\VisualSC2022\Community\Common7\Tools\spyxx_amd64.exe
    // LPCWSTR str = L"TslGame";

    HWND hwnd = FindWindowW(NULL, str);
    if (hwnd == NULL) {
        //exit(0);
        //QMessageBox::information(this, "错误", "截图失败，获取窗口失败");
        return;
    }
    //const char* processName = "your_process_name.exe"; // Replace with the actual process name
    //HWND hwnd = FindMainWindowByProcessName(processName);


    // 获取屏幕设备的上下文
    HDC hScreenDC = GetWindowDC(hwnd);

    // 3. 获取窗口尺寸
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) {
        //std::cerr << "无法获取窗口尺寸" << std::endl;
        //QMessageBox::information(this, "错误", "截图失败，无法获取窗口尺寸");
        ReleaseDC(hwnd, hScreenDC);
        return;
    }







    // 获取屏幕设备的上下文
    //HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

    // 锁定位图的像素区域以便访问
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像
    //cv::Mat grayScreenshot;
    //cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    image = screenshot;

    //cv::Mat imgGRAY;
    //cv::cvtColor(screenshot, imgGRAY, cv::COLOR_BGRA2BGR);
    ////cv::cvtColor(imgGRAY, img_GRAY, cv::COLOR_BGR2GRAY);
    //img_GRAY = imgGRAY.clone();

}

double C_sMap_Point::function_Pixels_To_Meters(int Pixel_x, int Pixel_y)
{

    //获取中心点
    double x0;
    double y0;
    //获取每1像素值对应米数
    double n;
    if (*sMap_MeterSize == 400)
    {
        //中心点坐标，玩家坐标
        x0 = (sMap400_x2 - sMap400_x1) / static_cast <double>(2);
        y0 = (sMap400_y2 - sMap400_y1) / static_cast <double>(2);

        n = static_cast<double>(400) / (sMap400_x2 - sMap400_x1);//每1像素值对应米数
    }
    else if (*sMap_MeterSize == 700)
    {
        //中心点坐标，玩家坐标
        x0 = (sMap700_x2 - sMap700_x1) / static_cast <double>(2);
        y0 = (sMap700_y2 - sMap700_y1) / static_cast <double>(2);

        n = static_cast<double>(700) / (sMap700_x2 - sMap700_x1);//每1像素值对应米数
    }

    //两点差,注意加上“目标像素位置”
    double Lx = x0 - (Pixel_x+ point_PngTarget_x);
    double Ly = y0 - (Pixel_y+ point_PngTarget_y);

    //double L = sqrt((Lx * Lx) + (Ly * Ly));
    // 可考虑使用hypot函数提高计算稳定性
    double L = hypot(Lx, Ly);  // 等价于 sqrt(Lx² + Ly²)，但数值稳定性更好


    return L * n;
}

void C_sMap_Point::getsendMeterToCrossbow(int& m_sendMeterToCrossbow)
{
    sendMeterToCrossbow = &m_sendMeterToCrossbow;
}

void C_sMap_Point::getcrossbow_player_number(int &m_crossbow_player_number)
{
    crossbow_player_number = & m_crossbow_player_number;
}




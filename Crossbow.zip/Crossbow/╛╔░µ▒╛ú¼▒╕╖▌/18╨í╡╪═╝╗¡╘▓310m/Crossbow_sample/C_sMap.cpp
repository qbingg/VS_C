#include "C_sMap.h"
#include "ui_C_sMap.h"

C_sMap::C_sMap(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setWindowTitle("小地图");
    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);

    setAttribute(Qt::WA_TranslucentBackground);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &C_sMap::updateWidget);
    //resize(1920, 1080);



}

C_sMap::~C_sMap()
{}


void C_sMap::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);



    // if (*check_sMap_DrawArc &&(*sMap_MeterSize == 400))
    // {

    //     //QPainter painter(this);
    //     int centerX = f(0);
    //     int centerY = f(0);
    //     //int R = (262 / (4) / 2);
    //     //int radius = (262 / (4));
    //     //int r = meter_To_Pixel(50);
    //     //painter.setPen(QPen(Qt::green, 1));
    //     //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     int r = meter_To_Pixel(100);
    //     painter.setPen(QPen(Qt::green, 2));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(150);
    //     painter.setPen(QPen(Qt::green, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(200);
    //     painter.setPen(QPen(Qt::green, 2));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);



    //     //for (int i = 2; i <= 14; i++)
    //     //{
    //     //    if (i == 2)
    //     //    {
    //     //        int startAngle = 0 * 16;
    //     //        int spanAngle = 360 * 16;
    //     //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
    //     //        painter.setPen(QPen(Qt::green, 2));
    //     //        painter.setBrush(Qt::NoBrush);
    //     //        painter.drawArc(arcRect, startAngle, spanAngle);
    //     //    }
    //     //    else
    //     //    {
    //     //        radius = i * R;
    //     //        if (i % 2 == 0)
    //     //        {
    //     //            painter.setPen(QPen(Qt::green, 2));
    //     //            painter.setBrush(Qt::NoBrush);
    //     //        }
    //     //        else
    //     //        {
    //     //            painter.setPen(QPen(Qt::black, 1));
    //     //            painter.setBrush(Qt::NoBrush);
    //     //        }
    //     //        int startAngle = 0 * 16;
    //     //        int spanAngle = 360 * 16;
    //     //        QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
    //     //        painter.drawArc(arcRect, startAngle, spanAngle);
    //     //    }
    //     //}
    //     painter.setCompositionMode(QPainter::CompositionMode_Clear);
    //     painter.setPen(QPen(Qt::green, 25));
    //     painter.drawLine(0, 0, width400, width400);
    //     painter.drawLine(0, width400, width400, 0);
    //     painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    //     painter.setPen(Qt::green);
    //     QFont font1;
    //     font1.setPointSizeF(7);
    //     painter.setFont(font1);
    //     painter.setBrush(Qt::NoBrush);
    //     int min = 7;
    //     int min2 = 5;
    //     int max = 5;
    //     painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
    //     painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
    //     painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
    //     //painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
    //     //painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
    //     //painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
    //     //painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
    //     //painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");
    //     painter.setPen(Qt::yellow);
    //     painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
    //     painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
    //     painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
    //     //painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
    //     //painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
    //     //painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
    //     //painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
    //     //painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");
    //     painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
    //     painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
    //     painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
    //     //painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
    //     //painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
    //     //painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
    //     //painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
    //     //painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");
    //     painter.setPen(Qt::green);
    //     painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
    //     painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
    //     painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
    //     //painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
    //     //painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
    //     //painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
    //     //painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
    //     //painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");
    //     //r = meter_To_Pixel(75);
    //     //painter.setPen(QPen(Qt::white, 0.5));
    //     //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(40);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(50);
    //     painter.setPen(QPen(Qt::green, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(60);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(70);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(80);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(90);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(110);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(120);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(130);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(140);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(160);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(170);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(180);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(190);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    // }
    // else if (*check_sMap_DrawArc &&(*sMap_MeterSize == 700))
    // {

    //     //QPainter painter(this);
    //     int centerX = f(0);
    //     int centerY = f(0);
    //     //int R = (460 / (7) / 2);//50米对应像素
    //     //int radius = (460 / (7));  // 半径  (默认100米)
    //     //int r = meter_To_Pixel(50);
    //     //painter.setPen(QPen(Qt::green, 1));
    //     //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     int r = meter_To_Pixel(100);
    //     painter.setPen(QPen(Qt::green, 2));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(150);
    //     painter.setPen(QPen(Qt::green, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(200);
    //     painter.setPen(QPen(Qt::green, 2));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(250);
    //     painter.setPen(QPen(Qt::red, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(300);
    //     painter.setPen(QPen(Qt::red, 2));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);



    //     painter.setCompositionMode(QPainter::CompositionMode_Clear);
    //     painter.setPen(QPen(Qt::green, 25));
    //     painter.drawLine(0, 0, width700, width700);
    //     painter.drawLine(0, width700, width700, 0);
    //     painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    //     painter.setPen(Qt::green);
    //     QFont font1;
    //     font1.setPointSizeF(7);
    //     painter.setFont(font1);
    //     painter.setBrush(Qt::NoBrush);
    //     int min = 7;
    //     int min2 = 5;
    //     int max = 5;
    //     painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
    //     painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
    //     painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
    //     painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
    //     painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
    //     //painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
    //     //painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
    //     //painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");
    //     painter.setPen(Qt::yellow);
    //     painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
    //     painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
    //     painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
    //     painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
    //     painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
    //     //painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
    //     //painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
    //     //painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");
    //     painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
    //     painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
    //     painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
    //     painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
    //     painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
    //     //painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
    //     //painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
    //     //painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");
    //     painter.setPen(Qt::green);
    //     painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
    //     painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
    //     painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
    //     painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
    //     painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
    //     //painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
    //     //painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
    //     //painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");
    //     //r = meter_To_Pixel(75);
    //     //painter.setPen(QPen(Qt::white, 0.5));
    //     //painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(40);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(50);
    //     painter.setPen(QPen(Qt::green, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(60);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(70);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(80);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(90);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(110);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(120);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(130);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(140);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(160);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(170);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(180);
    //     painter.setPen(QPen(Qt::white, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(190);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(210);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(220);
    //     painter.setPen(QPen(Qt::yellow, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(230);
    //     painter.setPen(QPen(Qt::yellow, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(240);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(260);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(270);
    //     painter.setPen(QPen(Qt::yellow, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(280);
    //     painter.setPen(QPen(Qt::yellow, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

    //     r = meter_To_Pixel(290);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    //     r = meter_To_Pixel(310);
    //     painter.setPen(QPen(Qt::black, 1));
    //     painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);





    // }

    //画310m的圈，以便用于显示弩箭的射程范围
    if (*sMap_MeterSize == 700)
    {
        //画圆
        int r = meter_To_Pixel(310);
        painter.setPen(QPen(penColor310m, 1));
        painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);
        //擦去圆上的四处，写字
        painter.setCompositionMode(QPainter::CompositionMode_Clear);
        painter.setPen(QPen(Qt::green, 25));
        painter.drawLine(0, 0, width700, width700);
        painter.drawLine(0, width700, width700, 0);
        painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
        painter.setPen(penColor310m);
        QFont font1;
        font1.setPointSizeF(7);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);
        int min = 7;
        int min2 = 5;
        int max = 5;

        painter.drawText(F(310 * sin(PI / 4)) - min, F(310 * cos(PI / 4)) + max, "310");
        painter.drawText(F(-310 * sin(PI / 4)) - min2, F(310 * cos(PI / 4)), "310");
        painter.drawText(F(310 * sin(PI / 4)) - min2, F(-310 * cos(PI / 4)), "310");
        painter.drawText(F(-310 * sin(PI / 4)) - min, F(-310 * cos(PI / 4)) + max, "310");



    }


    //画边框，确认小地图范围
    painter.setPen(QPen(penColor, 1.5));
    if (*sMap_MeterSize == 400)
    {
        painter.drawRect(0, 0, (sMap400_x2 - sMap400_x1) * magnify_n, (sMap400_y2 - sMap400_y1) * magnify_n);
    }
    else if (*sMap_MeterSize == 700)
    {
        painter.drawRect(0, 0, (sMap700_x2 - sMap700_x1) * magnify_n , (sMap700_y2 - sMap700_y1) * magnify_n);
    }


}

void C_sMap::startTimer()
{
    m_timer->start(67);
}

void C_sMap::stopTimer()
{
    m_timer->stop();
}

void C_sMap::getxy(int m_sMap400_x1, int m_sMap400_y1, int m_sMap400_x2, int m_sMap400_y2, int m_sMap700_x1, int m_sMap700_y1, int m_sMap700_x2, int m_sMap700_y2, double m_magnify_n, int& m_sMap_MeterSize)
{
    sMap400_x1 = m_sMap400_x1;
    sMap400_y1 = m_sMap400_y1;
    sMap400_x2 = m_sMap400_x2;
    sMap400_y2 = m_sMap400_y2;

    sMap700_x1 = m_sMap700_x1;
    sMap700_y1 = m_sMap700_y1;
    sMap700_x2 = m_sMap700_x2;
    sMap700_y2 = m_sMap700_y2;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    sMap_MeterSize = &m_sMap_MeterSize;

    if (*sMap_MeterSize==400)
    {
        resize
            (
                (sMap400_x2 - sMap400_x1) * magnify_n,
                (sMap400_y2 - sMap400_y1) * magnify_n
                );

        move
            (
                sMap400_x1 * magnify_n,
                sMap400_y1 * magnify_n
                );
    }
    else if (*sMap_MeterSize == 700)
    {
        resize
            (
                (sMap700_x2 - sMap700_x1) * magnify_n,
                (sMap700_y2 - sMap700_y1) * magnify_n
                );

        move
            (
                sMap700_x1 * magnify_n,
                sMap700_y1 * magnify_n
                );
    }

    width400 = (sMap400_x2 - sMap400_x1)* magnify_n;
    height400 = (sMap400_x2 - sMap400_x2) * magnify_n;

    width700 = (sMap700_x2 - sMap700_x1) * magnify_n;
    height700 = (sMap700_x2 - sMap700_x2) * magnify_n;
}

// void C_sMap::getcheck_sMap_DrawArc(int& m_check_sMap_DrawArc)
// {
//     check_sMap_DrawArc = &m_check_sMap_DrawArc;
// }



void C_sMap::updateWidget()
{

    GetAsyncKeyState(192);
    if (GetAsyncKeyState(192))
    {
        if (*sMap_MeterSize == 400)
        {
            *sMap_MeterSize = 700;

            resize
                (
                    (sMap700_x2 - sMap700_x1) * magnify_n,
                    (sMap700_y2 - sMap700_y1) * magnify_n
                    );

            move
                (
                    sMap700_x1 * magnify_n,
                    sMap700_y1 * magnify_n
                    );
        }
        else if (*sMap_MeterSize == 700)
        {
            *sMap_MeterSize = 400;

            resize
                (
                    (sMap400_x2 - sMap400_x1) * magnify_n,
                    (sMap400_y2 - sMap400_y1) * magnify_n
                    );

            move
                (
                    sMap400_x1 * magnify_n,
                    sMap400_y1 * magnify_n
                    );
        }
        update();
        Sleep(100);
    }
}


//输入以玩家为原点的坐标，返回,距离x/y轴的原始像素位置
int C_sMap::f(int x)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

    if (*sMap_MeterSize == 400)
    {
        int map_n = width400 / 2;

        int res = x + map_n;

        return res;
    }
    else if (*sMap_MeterSize == 700)
    {
        int map_n = width700 / 2;

        int res = x + map_n;

        return res;
    }

    return -1;
}

//输入以玩家为原点,距离x/y轴的米数，返回原始像素位置
int C_sMap::F(int meter)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

    if (*sMap_MeterSize == 400)
    {
        int map = width400;

        int map_n = map / 2;

        double n = map / static_cast<double>(400);//每1米对应的像素值

        int x = meter * n;

        int res = x + map_n;

        return res;
    }
    else if (*sMap_MeterSize == 700)
    {
        int map = width700;

        int map_n = map / 2;

        double n = map / static_cast<double>(700);//每1米对应的像素值

        int x = meter * n;

        int res = x + map_n;

        return res;
    }

    return -1;

}

//输入米数，返回对应像素值（单位：n个像素点/米）
int C_sMap::meter_To_Pixel(int meter)
{
    if (*sMap_MeterSize == 400)
    {
        int map = width400;

        double n = map / static_cast<double>(400);//每1米对应的像素值

        int Pixel = meter * n;

        return Pixel;
    }
    else if (*sMap_MeterSize == 700)
    {
        int map = width700;

        double n = map / static_cast<double>(700);//每1米对应的像素值

        int Pixel = meter * n;

        return Pixel;
    }

    return -1;

}

void C_sMap::getpenColor(QMap<int, QColor> QColorMapData)
{
    penColor = QColorMapData[SMAP_COLOR];
    penColor310m = QColorMapData[SMAP_COLOR310M];
    update();
}


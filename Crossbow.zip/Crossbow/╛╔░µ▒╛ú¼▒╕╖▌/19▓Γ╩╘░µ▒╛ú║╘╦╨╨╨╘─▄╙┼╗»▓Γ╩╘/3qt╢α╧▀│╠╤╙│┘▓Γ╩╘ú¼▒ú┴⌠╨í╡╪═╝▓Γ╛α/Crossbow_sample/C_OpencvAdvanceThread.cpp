#include "C_OpencvAdvanceThread.h"

void C_OpencvAdvanceThread::run()
{
    while (true)
    {
        start_time = std::chrono::high_resolution_clock::now();

        count++;

        emit newValue(start_time,count);

        Sleep(1000);
    }
}

C_OpencvAdvanceThread::C_OpencvAdvanceThread() {}

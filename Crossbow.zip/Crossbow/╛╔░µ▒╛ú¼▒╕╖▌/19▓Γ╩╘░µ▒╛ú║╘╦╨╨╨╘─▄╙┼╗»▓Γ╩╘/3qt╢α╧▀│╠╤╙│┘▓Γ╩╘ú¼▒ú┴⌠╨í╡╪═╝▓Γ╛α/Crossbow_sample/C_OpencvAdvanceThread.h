#ifndef C_OPENCVADVANCETHREAD_H
#define C_OPENCVADVANCETHREAD_H

#include"Defines.h"
#include<QThread>

class C_OpencvAdvanceThread:public QThread
{
    Q_OBJECT
private:
    std::chrono::steady_clock::time_point start_time;//计时器起点，草，还不能命名为start
    int count =0;//用于计算循环次数
signals:
    void newValue(std::chrono::steady_clock::time_point start_time,int count);
protected:
    void run()override;//写override提高代码可读性，说明这个函数是重载的
public:
    C_OpencvAdvanceThread();
};

#endif // C_OPENCVADVANCETHREAD_H

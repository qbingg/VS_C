#ifndef DEFINE_VAR_H
#define DEFINE_VAR_H

#include "Defines.h"

//创建文件夹
namespace fs = std::filesystem;
fs::path relative_Path = PATH; //项目文件夹的相对路径
fs::path shareInfo_Path = SHAREINFO_PATH;////共享文件夹路径
fs::path opencv_Path = OPENCV_PATH; //图像检测，模板图片文件夹路径
fs::path img_Path = IMG_PATH;//img文件夹路径


#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>

QMap<int,int> intMapData = {
    {SCREEN_RESOLUTION_X , 0},
    {SCREEN_RESOLUTION_Y , 0},
    {SMAP400_X1, 0},
    {SMAP400_Y1, 0},
    {SMAP400_X2, 0},
    {SMAP400_Y2, 0},
    {SMAP700_X1, 0},
    {SMAP700_Y1, 0},
    {SMAP700_X2, 0},
    {SMAP700_Y2, 0},
    {MAGNIFY_UPY0, 0},
    {POINT_PNG_TARGET_X, 0},
    {POINT_PNG_TARGET_Y, 0},
    {CROSSBOW_X1, 0},
    {CROSSBOW_Y1, 0},
    {CROSSBOW_X2, 0},
    {CROSSBOW_Y2, 0},
    {CROSSBOW_4_2R, 0},
    {CROSSBOW_4_PNGY, 0},
    {CROSSBOW_25M_X1, 0},
    {CROSSBOW_25M_Y1, 0},
    {CROSSBOW_25M_X2, 0},
    {CROSSBOW_25M_Y2, 0},
    {CROSSBOW_X1_BOTTOM, 0},
    {CROSSBOW_Y1_BOTTOM, 0},
    {CROSSBOW_X2_BOTTOM, 0},
    {CROSSBOW_Y2_BOTTOM, 0},
    {CROSSBOW_4_PNGY_BOTTOM, 0},
    {CHECK_SMAP_POINT_SOLO,0}   //有动态变化需求，数据库map只提供存储
};

QMap<int,double> doubleMapData = {
    {SCREEN_MAGNIFY , 0},
    {WINMAGNIFY_N,0}

};

int check_sMap_Point_Solo;//勾选框		0关闭 1打开

#endif // DEFINE_VAR_H

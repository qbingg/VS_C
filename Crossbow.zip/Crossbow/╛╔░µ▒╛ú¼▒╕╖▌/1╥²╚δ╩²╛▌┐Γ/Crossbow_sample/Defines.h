#ifndef DEFINES_H
#define DEFINES_H

//包含数据库变量的宏定义
#include "Defines_Data.h"

//宏定义、#include头文件


//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\SEenvironment\OpenCV\opencv\build\include
//                      D:\Softwares\SEenvironment\opencv\build\include\opencv2
// 4.库目录 D:\Softwares\SEenvironment\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
#include <opencv2/opencv.hpp>
#include <Windows.h>

#include <fstream>
#include <filesystem>



//res文件夹路径
#define PATH "res"

//res文件路径
#define FILE_PATH "res/"

//共享文件夹路径
#define SHAREINFO_PATH "res/shareInfo"

//共享文件路径
#define SHAREINFO_FILE_PATH "res/shareInfo/"

//图像检测，模板图片文件夹路径
#define OPENCV_PATH "res/opencvImg"

//图像检测，模板图片文件路径
#define OPENCV_FILE_PATH "res/opencvImg/"

//img文件夹路径
#define IMG_PATH "res/img"

//img文件路径
#define IMG_FILE_PATH "res/img/"



//Menu类
#define MENU_WIDTH 600//窗口宽
#define MENU_HEIGH 400//窗口高

#define TOOL_BTN_SIZE 50//图标按钮尺寸

#define BTNS_NUMBER 8	//子菜单按钮数量

//灰度截图类
//PUBG窗口句柄名
#define PUBGWINDOWNAME L"PUBG: BATTLEGROUNDS "//PUBG窗口句柄名

//图像检测，模板图片文件夹路径
#define OPENCVPATH "res/opencvImg"

//图像检测，模板图片文件路径
#define OPENCVFILEPATH "res/opencvImg/"


#define PI 3.1415926

#endif // DEFINES_H

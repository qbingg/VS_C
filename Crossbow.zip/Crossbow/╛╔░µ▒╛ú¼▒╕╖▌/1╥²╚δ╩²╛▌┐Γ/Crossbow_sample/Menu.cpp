#include "Menu.h"
#include "ui_Menu.h"

Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);
}

Menu::~Menu()
{
    delete ui;
}

void Menu::setDoubleMapData(const QMap<int, double> &newDoubleMapData)
{
    m_doubleMapData = newDoubleMapData;

    //将数据展示到ui控件上
    ui->screen_magnify->setValue(m_doubleMapData[SCREEN_MAGNIFY]);
    ui->winMagnify_n->setValue(m_doubleMapData[WINMAGNIFY_N]);
}

void Menu::getsMap_Point(int &check_sMap_Point_Solo)
{
    m_check_sMap_Point_Solo = &check_sMap_Point_Solo;

    connect(ui->checkBoxcheck_sMap_Point_Solo, &QCheckBox::stateChanged, this, &Menu::on_checkBoxcheck_sMap_Point_Solo);
    //将数据展示到ui控件上
    if (*m_check_sMap_Point_Solo==1)
    {
        ui->checkBoxcheck_sMap_Point_Solo->setChecked(true);
    }

}

bool Menu::on_checkBoxcheck_sMap_Point_Solo(bool checked)
{
    if (ui->checkBoxcheck_sMap_Point_Solo->isChecked())
    {
        *m_check_sMap_Point_Solo = 1;
    }
    else
    {
        *m_check_sMap_Point_Solo = 0;
    }

    return false;
}

void Menu::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;

    //将数据展示到ui控件上
    ui->screen_resolution_x->setValue(m_intMapData[SCREEN_RESOLUTION_X]);
    ui->screen_resolution_y->setValue(m_intMapData[SCREEN_RESOLUTION_Y]);

    ui->sMap400_x1->setValue(m_intMapData[SMAP400_X1]);
    ui->sMap400_y1->setValue(m_intMapData[SMAP400_Y1]);
    ui->sMap400_x2->setValue(m_intMapData[SMAP400_X2]);
    ui->sMap400_y2->setValue(m_intMapData[SMAP400_Y2]);

    ui->sMap700_x1->setValue(m_intMapData[SMAP700_X1]);
    ui->sMap700_y1->setValue(m_intMapData[SMAP700_Y1]);
    ui->sMap700_x2->setValue(m_intMapData[SMAP700_X2]);
    ui->sMap700_y2->setValue(m_intMapData[SMAP700_Y2]);

    ui->Magnify_UPy0->setValue(m_intMapData[MAGNIFY_UPY0]);

    ui->point_PngTarget_x->setValue(m_intMapData[POINT_PNG_TARGET_X]);
    ui->point_PngTarget_y->setValue(m_intMapData[POINT_PNG_TARGET_Y]);

    ui->crossbow_x1->setValue(m_intMapData[CROSSBOW_X1]);
    ui->crossbow_y1->setValue(m_intMapData[CROSSBOW_Y1]);
    ui->crossbow_x2->setValue(m_intMapData[CROSSBOW_X2]);
    ui->crossbow_y2->setValue(m_intMapData[CROSSBOW_Y2]);
    ui->crossbow_4_2R->setValue(m_intMapData[CROSSBOW_4_2R]);
    ui->crossbow_4_PngY->setValue(m_intMapData[CROSSBOW_4_PNGY]);
    ui->crossbow_25m_x1->setValue(m_intMapData[CROSSBOW_25M_X1]);
    ui->crossbow_25m_y1->setValue(m_intMapData[CROSSBOW_25M_Y1]);
    ui->crossbow_25m_x2->setValue(m_intMapData[CROSSBOW_25M_X2]);
    ui->crossbow_25m_y2->setValue(m_intMapData[CROSSBOW_25M_Y2]);
    ui->crossbow_x1_bottom->setValue(m_intMapData[CROSSBOW_X1_BOTTOM]);
    ui->crossbow_y1_bottom->setValue(m_intMapData[CROSSBOW_Y1_BOTTOM]);
    ui->crossbow_x2_bottom->setValue(m_intMapData[CROSSBOW_X2_BOTTOM]);
    ui->crossbow_y2_bottom->setValue(m_intMapData[CROSSBOW_Y2_BOTTOM]);
    ui->crossbow_4_PngY_bottom->setValue(m_intMapData[CROSSBOW_4_PNGY_BOTTOM]);

}



void Menu::on_btnSave_clicked()
{
    //将ui控件的数据写入Map
    //int
    m_intMapData[SCREEN_RESOLUTION_X] = ui->screen_resolution_x->value();
    m_intMapData[SCREEN_RESOLUTION_Y] = ui->screen_resolution_y->value();

    m_intMapData[SMAP400_X1] = ui->sMap400_x1->value();
    m_intMapData[SMAP400_Y1] = ui->sMap400_y1->value();
    m_intMapData[SMAP400_X2] = ui->sMap400_x2->value();
    m_intMapData[SMAP400_Y2] = ui->sMap400_y2->value();

    m_intMapData[SMAP700_X1] = ui->sMap700_x1->value();
    m_intMapData[SMAP700_Y1] = ui->sMap700_y1->value();
    m_intMapData[SMAP700_X2] = ui->sMap700_x2->value();
    m_intMapData[SMAP700_Y2] = ui->sMap700_y2->value();

    m_intMapData[MAGNIFY_UPY0]=ui->Magnify_UPy0->value();

    m_intMapData[POINT_PNG_TARGET_X]=ui->point_PngTarget_x->value();
    m_intMapData[POINT_PNG_TARGET_Y]=ui->point_PngTarget_y->value();

    m_intMapData[CROSSBOW_X1] = ui->crossbow_x1->value();
    m_intMapData[CROSSBOW_Y1] = ui->crossbow_y1->value();
    m_intMapData[CROSSBOW_X2] = ui->crossbow_x2->value();
    m_intMapData[CROSSBOW_Y2] = ui->crossbow_y2->value();
    m_intMapData[CROSSBOW_4_2R] = ui->crossbow_4_2R->value();
    m_intMapData[CROSSBOW_4_PNGY] = ui->crossbow_4_PngY->value();
    m_intMapData[CROSSBOW_25M_X1] = ui->crossbow_25m_x1->value();
    m_intMapData[CROSSBOW_25M_Y1] = ui->crossbow_25m_y1->value();
    m_intMapData[CROSSBOW_25M_X2] = ui->crossbow_25m_x2->value();
    m_intMapData[CROSSBOW_25M_Y2] = ui->crossbow_25m_y2->value();
    m_intMapData[CROSSBOW_X1_BOTTOM] = ui->crossbow_x1_bottom->value();
    m_intMapData[CROSSBOW_Y1_BOTTOM] = ui->crossbow_y1_bottom->value();
    m_intMapData[CROSSBOW_X2_BOTTOM] = ui->crossbow_x2_bottom->value();
    m_intMapData[CROSSBOW_Y2_BOTTOM] = ui->crossbow_y2_bottom->value();
    m_intMapData[CROSSBOW_4_PNGY_BOTTOM] = ui->crossbow_4_PngY_bottom->value();

    //特殊变量赋值, 到map里, 到指针内存里
    if (ui->checkBoxcheck_sMap_Point_Solo->isChecked())
    {
        m_intMapData[CHECK_SMAP_POINT_SOLO]=1;
        *m_check_sMap_Point_Solo = m_intMapData[CHECK_SMAP_POINT_SOLO];
    }
    else
    {
        m_intMapData[CHECK_SMAP_POINT_SOLO]=0;
        *m_check_sMap_Point_Solo = m_intMapData[CHECK_SMAP_POINT_SOLO];
    }



    //double
    m_doubleMapData[SCREEN_MAGNIFY] = ui->screen_magnify->value();
    m_doubleMapData[WINMAGNIFY_N]=ui->winMagnify_n->value();





    //将map写入数据库
    C_SQL sql;
    sql.write_intMapData(m_intMapData);
    sql.write_doubleMapData(m_doubleMapData);
    //将map更新到其他类里
}


#ifndef MENU_H
#define MENU_H

#include <QWidget>

#include "Defines.h"
#include "C_SQL.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Menu;
}
QT_END_NAMESPACE

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();





private:
    Ui::Menu *ui;

private:
    QMap<int,int> m_intMapData;
    QMap<int,double> m_doubleMapData;
    int* m_check_sMap_Point_Solo;
public:
    void setIntMapData(const QMap<int, int> &newIntMapData);

    void setDoubleMapData(const QMap<int, double> &newDoubleMapData);

    void getsMap_Point(int& check_sMap_Point_Solo);

private slots:
    void on_btnSave_clicked();
    bool on_checkBoxcheck_sMap_Point_Solo(bool checked);
};
#endif // MENU_H

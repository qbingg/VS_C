#include "Menu.h"

#include <QApplication>

#include "Defines.h"
#include "Define_Var.h"
#include "Define_Func.h"
#include "C_SQL.h"
//启动程序需要做的事
void function_StartALL()//启动程序需要做的事
{
    //1. 检查文件夹是否存在，如果不存在则创建
    if (!fs::exists(relative_Path))
    {
        fs::create_directories(relative_Path);
    }
    if (!fs::exists(shareInfo_Path))
    {
        fs::create_directories(shareInfo_Path);
    }
    if (!fs::exists(opencv_Path))
    {
        fs::create_directories(opencv_Path);
    }
    if (!fs::exists(img_Path))
    {
        fs::create_directories(img_Path);
    }

    //读取数据
    C_SQL sql;
    sql.read_intMapData(intMapData);
    sql.read_doubleMapData(doubleMapData);
    //特殊数据，赋值
    check_sMap_Point_Solo=intMapData[CHECK_SMAP_POINT_SOLO];










}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    function_StartALL();

    Menu w;

    w.setIntMapData(intMapData);
    w.setDoubleMapData(doubleMapData);
    w.getsMap_Point(check_sMap_Point_Solo);

    w.show();
    return a.exec();
}

#include "C_sMap_Point_Thread.h"

C_sMap_Point_Thread::C_sMap_Point_Thread()
{



    for (int i = 0; i < 5; i++) {
        //初始化opencv类
        C_opencv player;
        sMap_opencv[i]=player;//存在修改，不存在则插入

        //初始化模板图片
        QString strNumber = QString::number(i);
        QString STR = "res/opencvImg/point_" + strNumber + ".png";
        cv::String stdSTR = STR.toStdString();
        sMap_opencv[i].setImage_templ(cv::imread(stdSTR));
    }
}

void C_sMap_Point_Thread::getxy(int &m_sMap_MeterSize, int m_sMap400_x1, int m_sMap400_y1, int m_sMap400_x2, int m_sMap400_y2, int m_sMap700_x1, int m_sMap700_y1, int m_sMap700_x2, int m_sMap700_y2, int m_point_PngTarget_x, int m_point_PngTarget_y)
{
    sMap_MeterSize = &m_sMap_MeterSize;

    sMap400_x1 = m_sMap400_x1;
    sMap400_y1 = m_sMap400_y1;
    sMap400_x2 = m_sMap400_x2;
    sMap400_y2 = m_sMap400_y2;

    sMap700_x1 = m_sMap700_x1;
    sMap700_y1 = m_sMap700_y1;
    sMap700_x2 = m_sMap700_x2;
    sMap700_y2 = m_sMap700_y2;

    point_PngTarget_x = m_point_PngTarget_x;
    point_PngTarget_y = m_point_PngTarget_y;
}

void C_sMap_Point_Thread::function_screen(cv::Mat &output_colorful_screen, int x1, int y1, int x2, int y2)
{

    //PUBG窗口截图方式
    LPCWSTR str = PUBGWINDOWNAME;
    // 1. 查找窗口句柄

    //LPCWSTR str = L"**高校水电费管理系统——20231862卢伟明";

    //LPCWSTR str = L"PUBG：绝地求生 ";//md后面藏了个空格!!!!!!!!!!!!!!!!!       D:\SEenvironment\VisualSC2022\Community\Common7\Tools\spyxx_amd64.exe
    // LPCWSTR str = L"TslGame";

    HWND hwnd = FindWindowW(NULL, str);
    if (hwnd == NULL) {
        //exit(0);
        //QMessageBox::information(this, "错误", "截图失败，获取窗口失败");
        return;
    }
    //const char* processName = "your_process_name.exe"; // Replace with the actual process name
    //HWND hwnd = FindMainWindowByProcessName(processName);


    // 获取屏幕设备的上下文
    HDC hScreenDC = GetWindowDC(hwnd);

    // 3. 获取窗口尺寸
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) {
        //std::cerr << "无法获取窗口尺寸" << std::endl;
        //QMessageBox::information(this, "错误", "截图失败，无法获取窗口尺寸");
        ReleaseDC(hwnd, hScreenDC);
        return;
    }







    // 获取屏幕设备的上下文
    //HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

    // 锁定位图的像素区域以便访问
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像
    //cv::Mat grayScreenshot;
    //cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    output_colorful_screen = screenshot;

    //cv::Mat imgGRAY;
    //cv::cvtColor(screenshot, imgGRAY, cv::COLOR_BGRA2BGR);
    ////cv::cvtColor(imgGRAY, img_GRAY, cv::COLOR_BGR2GRAY);
    //img_GRAY = imgGRAY.clone();
}


void C_sMap_Point_Thread::run()
{
    while (true)
    {
        cv::Mat screen;

        if (*sMap_MeterSize == 400)
        {
            function_screen(screen,sMap400_x1, sMap400_y1, sMap400_x2, sMap400_y2);
        }
        else if (*sMap_MeterSize == 700)
        {
            function_screen(screen, sMap700_x1, sMap700_y1, sMap700_x2, sMap700_y2);
        }

        for (int key : sMap_opencv.keys())
        {
            sMap_opencv[key].setImage_screen(screen);
            sMap_opencv[key].use_function_matchTemplate_advance();
        }

        emit newValue(sMap_opencv);

        Sleep(1);
    }
}



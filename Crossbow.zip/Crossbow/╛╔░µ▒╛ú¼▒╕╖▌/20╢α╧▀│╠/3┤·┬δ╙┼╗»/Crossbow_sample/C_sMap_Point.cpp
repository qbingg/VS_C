#include "C_sMap_Point.h"

C_sMap_Point::C_sMap_Point(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setWindowTitle("小地图自动测距");
    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);

    setAttribute(Qt::WA_TranslucentBackground);

    //绑定槽函数：接受信号
    connect(&sMap_thread,&C_sMap_Point_Thread::newValue,this,&C_sMap_Point::receiveSignal);
}

C_sMap_Point::~C_sMap_Point()
{}

void C_sMap_Point::getxy(int& m_check_sMap_Point_Solo, int& m_sMap_MeterSize, int m_sMap400_x1, int m_sMap400_y1, int m_sMap400_x2, int m_sMap400_y2, int m_sMap700_x1, int m_sMap700_y1, int m_sMap700_x2, int m_sMap700_y2, double m_magnify_n, int m_point_PngTarget_x,int m_point_PngTarget_y)
{
    check_sMap_Point_Solo = &m_check_sMap_Point_Solo;
    sMap_MeterSize = &m_sMap_MeterSize;

    sMap400_x1 = m_sMap400_x1;
    sMap400_y1 = m_sMap400_y1;
    sMap400_x2 = m_sMap400_x2;
    sMap400_y2 = m_sMap400_y2;

    sMap700_x1 = m_sMap700_x1;
    sMap700_y1 = m_sMap700_y1;
    sMap700_x2 = m_sMap700_x2;
    sMap700_y2 = m_sMap700_y2;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    point_PngTarget_x = m_point_PngTarget_x;
    point_PngTarget_y = m_point_PngTarget_y;

    if (*sMap_MeterSize == 400)
    {
        resize
            (
                (sMap400_x2 - sMap400_x1) * magnify_n,
                (sMap400_y2 - sMap400_y1) * magnify_n
                );

        move
            (
                sMap400_x1 * magnify_n,
                sMap400_y1 * magnify_n
                );
    }
    else if (*sMap_MeterSize == 700)
    {
        resize
            (
                (sMap700_x2 - sMap700_x1) * magnify_n,
                (sMap700_y2 - sMap700_y1) * magnify_n
                );

        move
            (
                sMap700_x1 * magnify_n,
                sMap700_y1 * magnify_n
                );
    }

    width400 = (sMap400_x2 - sMap400_x1) * magnify_n;
    height400 = (sMap400_x2 - sMap400_x2) * magnify_n;

    width700 = (sMap700_x2 - sMap700_x1) * magnify_n;
    height700 = (sMap700_x2 - sMap700_x2) * magnify_n;

    //在获取数据的同时，将数据传到子线程里
    sMap_thread.getxy(
        m_sMap_MeterSize,

        m_sMap400_x1,
        m_sMap400_y1,
        m_sMap400_x2,
        m_sMap400_y2,

        m_sMap700_x1,
        m_sMap700_y1,
        m_sMap700_x2,
        m_sMap700_y2,

        point_PngTarget_x = m_point_PngTarget_x,
        point_PngTarget_y = m_point_PngTarget_y
        );

}

void C_sMap_Point::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);


    //画框
    for (int i = 0; i < 5; i++)
    {
        if (n[i] > 0.3)
        {
            if (i == 0 && *check_sMap_Point_Solo == 1)
            {
                painter.setPen(QPen(penColor[i], 2));
                int X = target_point_x[i] * magnify_n;
                int Y = target_point_y[i] * magnify_n;
                painter.drawRect(X, Y, point_PngTarget_x * 2, point_PngTarget_y);
            }

            if (i != 0 && *check_sMap_Point_Solo == 0)
            {
                painter.setPen(QPen(penColor[i], 2));
                int X = target_point_x[i] * magnify_n;
                int Y = target_point_y[i] * magnify_n;
                painter.drawRect(X, Y, point_PngTarget_x * 2, point_PngTarget_y);
            }
        }
    }

    //计算距离
    QFont font1;
    font1.setPointSizeF(13);
    painter.setFont(font1);
    //四排，只显示combobox选中的玩家
    int player = *crossbow_player_number + 1;//0123>>1234
    for (int i = 0; i < 5; i++)
    {
        if (n[i]>0.3)
        {
            if (i == 0 && *check_sMap_Point_Solo == 1)//单人
            {
                painter.setPen(QPen(penColor[i]));
                float meter = function_Pixels_To_Meters(target_point_x[i], target_point_y[i]);
                QString strNumber = QString::number(meter, 'f', 0);
                QString STR = " " + strNumber + " 米";
                painter.drawText(0, 20 * (i + 1), STR);

                *sendMeterToCrossbow = meter;
            }

            if (i != 0 && *check_sMap_Point_Solo == 0)//四排
            {
                painter.setPen(QPen(penColor[i]));
                float meter = function_Pixels_To_Meters(target_point_x[i], target_point_y[i]);
                QString strNumber = QString::number(meter, 'f', 1);
                QString STR = " " + strNumber + "";
                painter.drawText(0, 20 * (i), STR);


                if (i==player)
                {
                    //四舍五入为整数，仅限非负数（避免舍弃小数导致结果偏小）
                    *sendMeterToCrossbow = meter + 0.5;
                }
                //*sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[1], target_point_y[1]);
            }
        }
        else if ((n[0] < 0.3) && (n[player] < 0.3))//单排 和四排？号 都没有检测到标点
        {
            *sendMeterToCrossbow = 0;
        }
    }

    //if (*check_sMap_Point_Solo == 1)//单人
    //{
    //    *sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[0], target_point_y[0]);
    //
    //}
    //else//四排，只显示1号的
    //{
    //    *sendMeterToCrossbow = function_Pixels_To_Meters(target_point_x[1], target_point_y[1]);
    //
    //}
}

double C_sMap_Point::function_Pixels_To_Meters(int Pixel_x, int Pixel_y)
{

    //获取中心点
    double x0;
    double y0;
    //获取每1像素值对应米数
    double n;
    if (*sMap_MeterSize == 400)
    {
        //中心点坐标，玩家坐标
        x0 = (sMap400_x2 - sMap400_x1) / static_cast <double>(2);
        y0 = (sMap400_y2 - sMap400_y1) / static_cast <double>(2);

        n = static_cast<double>(400) / (sMap400_x2 - sMap400_x1);//每1像素值对应米数
    }
    else if (*sMap_MeterSize == 700)
    {
        //中心点坐标，玩家坐标
        x0 = (sMap700_x2 - sMap700_x1) / static_cast <double>(2);
        y0 = (sMap700_y2 - sMap700_y1) / static_cast <double>(2);

        n = static_cast<double>(700) / (sMap700_x2 - sMap700_x1);//每1像素值对应米数
    }

    //两点差,注意加上“目标像素位置”
    double Lx = x0 - (Pixel_x+ point_PngTarget_x);
    double Ly = y0 - (Pixel_y+ point_PngTarget_y);

    //double L = sqrt((Lx * Lx) + (Ly * Ly));
    // 可考虑使用hypot函数提高计算稳定性
    double L = hypot(Lx, Ly);  // 等价于 sqrt(Lx² + Ly²)，但数值稳定性更好


    return L * n;
}

void C_sMap_Point::getsendMeterToCrossbow(int& m_sendMeterToCrossbow)
{
    sendMeterToCrossbow = &m_sendMeterToCrossbow;
}

void C_sMap_Point::getcrossbow_player_number(int &m_crossbow_player_number)
{
    crossbow_player_number = & m_crossbow_player_number;
}

void C_sMap_Point::startThread()
{
    //与startTimer类似，运行多线程
    //注意要在数据获取getxy之后
    //在绑定槽函数之后
    sMap_thread.start();
}

void C_sMap_Point::receiveSignal(QMap<int, C_opencv> sMap_opencv)
{
    //获取值
    for(int key : sMap_opencv.keys())
    {
        n[key] = sMap_opencv[key].getN();

        target_point_x[key] =  sMap_opencv[key].getTarget_point().x;
        target_point_y[key] =  sMap_opencv[key].getTarget_point().y;
    }

    //检测小地图窗口尺寸
    if(1){
        //
        if (*sMap_MeterSize == 400)
        {
            resize
                (
                    (sMap400_x2 - sMap400_x1) * magnify_n,
                    (sMap400_y2 - sMap400_y1) * magnify_n
                    );

            move
                (
                    sMap400_x1 * magnify_n,
                    sMap400_y1 * magnify_n
                    );


            update();

        }
        else if (*sMap_MeterSize == 700)
        {
            resize
                (
                    (sMap700_x2 - sMap700_x1) * magnify_n,
                    (sMap700_y2 - sMap700_y1) * magnify_n
                    );

            move
                (
                    sMap700_x1 * magnify_n,
                    sMap700_y1 * magnify_n
                    );


            update();

        }
    }
    //更新窗口
    update();

}




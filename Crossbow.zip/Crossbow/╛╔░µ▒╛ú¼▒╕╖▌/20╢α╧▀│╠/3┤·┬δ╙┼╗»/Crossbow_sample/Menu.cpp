#include "Menu.h"

#include "ui_Menu.h"

#include <QDesktopServices>
#include <QUrl>

Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);

    connect(ui->checkBoxRunning, &QCheckBox::stateChanged, this, &Menu::on_checkBoxRunning);

    //去除窗口标题栏
    setWindowFlags(Qt::FramelessWindowHint);

    //设置窗口大小
    resize(1067,600);

    // 不允许子部件根据 QScrollArea 的大小调整自身大小
    ui->scrollArea->setWidgetResizable(false);
    ui->scrollArea->setWidget(ui->widget);

    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);
    //设置窗口名称
    setWindowTitle("弩箭终极优化工具");

    //创建超链接
    QLabel *label = ui->bilibili;
    // 使用 HTML 格式的文本创建超链接
    label->setText("<a href='https://space.bilibili.com/3546718385736271' style='color: #0245ff;'>作者B站UP： VS的C</a>");
    label->setTextFormat(Qt::RichText); // 确保文本格式为富文本
    label->setTextInteractionFlags(Qt::TextBrowserInteraction); // 启用交互
    label->setOpenExternalLinks(false); // 我们手动处理链接点击
    // 连接信号槽来处理点击事件
    connect(label, &QLabel::linkActivated, this, [](const QString &link) {
        QDesktopServices::openUrl(QUrl(link));
    });


}

Menu::~Menu()
{
    delete ui;
}

void Menu::closeEvent(QCloseEvent *event)
{
    //关闭菜单时，关闭其他窗口
    if(ui->checkBoxRunning->isChecked())
    {
        //小地图
        m_C_sMap->close();
        //小地图测距
        m_C_sMap_Point->close();
        //弩箭
        m_C_Crossbow->close();
    }
}

void Menu::setQColorMapData(const QMap<int, QColor> &newQColorMapData)
{
    m_QColorMapData = newQColorMapData;

    //将颜色添加到combobox
    int index=0;//combobox默认index
    for(int key :m_QColorMapData.keys())
    {
        ui->comboBoxColor->addItem(QString::number(key)+"\t 默认index:"+QString::number(index));
        ui->comboBoxColor->setItemData(index,key);// ItemData里就是 自定义索引

        index++;
    }

    //程序启动时，combobox默认为小地图边框的选项，获取该色的值，赋值到滑动条和QLabel上
    //要在槽函数绑定前！！！不然会执行三次槽函数
    //1、获取自定义index
    int defaultIndex = ui->comboBoxColor->currentIndex();
    int customIndex = ui->comboBoxColor->itemData(defaultIndex).toInt();
    int key = customIndex;
    ui->Red->setValue(m_QColorMapData[key].red());
    ui->Green->setValue(m_QColorMapData[key].green());
    ui->Blue->setValue(m_QColorMapData[key].blue());
    //将颜色值写到Label
    ui->labelR->setText(QString::number(ui->Red->value()));
    ui->labelG->setText(QString::number(ui->Green->value()));
    ui->labelB->setText(QString::number(ui->Blue->value()));
    ui->labelRGB->setStyleSheet("background-color:" + m_QColorMapData[key].name());


    //绑定槽函数
    //建立槽函数(actionTriggered没有valueChanged好用，值变化不够精确)
    connect(ui->Red, &QSlider::valueChanged, this, &Menu::slot_RGB_Setting);
    connect(ui->Green, &QSlider::valueChanged, this, &Menu::slot_RGB_Setting);
    connect(ui->Blue, &QSlider::valueChanged, this, &Menu::slot_RGB_Setting);






}



void Menu::setDoubleMapData(const QMap<int, double> &newDoubleMapData)
{
    m_doubleMapData = newDoubleMapData;

    //将数据展示到ui控件上
    ui->screen_magnify->setValue(m_doubleMapData[SCREEN_MAGNIFY]);

    //特殊变量，不通过map赋值到ui控件
    //ui->winMagnify_n->setValue(m_doubleMapData[WINMAGNIFY_N]);
}

void Menu::getsMap_Point(int &check_sMap_Point_Solo)
{
    m_check_sMap_Point_Solo = &check_sMap_Point_Solo;

    connect(ui->checkBoxcheck_sMap_Point_Solo, &QCheckBox::stateChanged, this, &Menu::on_checkBoxcheck_sMap_Point_Solo);
    //将数据展示到ui控件上
    if (*m_check_sMap_Point_Solo==1)
    {
        ui->checkBoxcheck_sMap_Point_Solo->setChecked(true);
    }

}

void Menu::getcrossbow_player_number(int &crossbow_player_number)
{
    m_crossbow_player_number =& crossbow_player_number;

    //QIcon icon0("res/opencvImg/point_0.png");
    QIcon icon1("res/opencvImg/point_1.png");
    QIcon icon2("res/opencvImg/point_2.png");
    QIcon icon3("res/opencvImg/point_3.png");
    QIcon icon4("res/opencvImg/point_4.png");

    // ui->comboBoxPlayerNumber->addItem(icon0,"0");
    // ui->comboBoxPlayerNumber->addItem(icon1,"1");
    // ui->comboBoxPlayerNumber->addItem(icon2,"2");
    // ui->comboBoxPlayerNumber->addItem(icon3,"3");
    // ui->comboBoxPlayerNumber->addItem(icon4,"4");

    //ui->comboBoxPlayerNumber->addItem(icon0,"单排/1号");
    ui->comboBoxPlayerNumber->addItem(icon1,"1号");
    ui->comboBoxPlayerNumber->addItem(icon2,"2号");
    ui->comboBoxPlayerNumber->addItem(icon3,"3号");
    ui->comboBoxPlayerNumber->addItem(icon4,"4号");

    ui->comboBoxPlayerNumber->setIconSize(QSize(32, 44));
    //ui->comboBoxPlayerNumber->setIconSize(QSize(64, 88));
}

void Menu::getsMap_MeterSize(int &sMap_MeterSize)
{
    m_sMap_MeterSize =&sMap_MeterSize;




}

bool Menu::on_checkBoxcheck_sMap_Point_Solo(bool checked)
{
    if (ui->checkBoxcheck_sMap_Point_Solo->isChecked())
    {
        *m_check_sMap_Point_Solo = 1;
    }
    else
    {
        *m_check_sMap_Point_Solo = 0;
    }

    return false;
}

void Menu::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;

    //将数据展示到ui控件上
    ui->screen_resolution_x->setValue(m_intMapData[SCREEN_RESOLUTION_X]);
    ui->screen_resolution_y->setValue(m_intMapData[SCREEN_RESOLUTION_Y]);

    ui->sMap400_x1->setValue(m_intMapData[SMAP400_X1]);
    ui->sMap400_y1->setValue(m_intMapData[SMAP400_Y1]);
    ui->sMap400_x2->setValue(m_intMapData[SMAP400_X2]);
    ui->sMap400_y2->setValue(m_intMapData[SMAP400_Y2]);

    ui->sMap700_x1->setValue(m_intMapData[SMAP700_X1]);
    ui->sMap700_y1->setValue(m_intMapData[SMAP700_Y1]);
    ui->sMap700_x2->setValue(m_intMapData[SMAP700_X2]);
    ui->sMap700_y2->setValue(m_intMapData[SMAP700_Y2]);

    //特殊变量，不通过map赋值到ui控件
    //ui->Magnify_UPy0->setValue(m_intMapData[MAGNIFY_UPY0]);

    ui->point_PngTarget_x->setValue(m_intMapData[POINT_PNG_TARGET_X]);
    ui->point_PngTarget_y->setValue(m_intMapData[POINT_PNG_TARGET_Y]);

    ui->crossbow_x1->setValue(m_intMapData[CROSSBOW_X1]);
    ui->crossbow_y1->setValue(m_intMapData[CROSSBOW_Y1]);
    ui->crossbow_x2->setValue(m_intMapData[CROSSBOW_X2]);
    ui->crossbow_y2->setValue(m_intMapData[CROSSBOW_Y2]);
    ui->crossbow_4_2R->setValue(m_intMapData[CROSSBOW_4_2R]);
    ui->crossbow_4_PngY->setValue(m_intMapData[CROSSBOW_4_PNGY]);
    ui->crossbow_25m_x1->setValue(m_intMapData[CROSSBOW_25M_X1]);
    ui->crossbow_25m_y1->setValue(m_intMapData[CROSSBOW_25M_Y1]);
    ui->crossbow_25m_x2->setValue(m_intMapData[CROSSBOW_25M_X2]);
    ui->crossbow_25m_y2->setValue(m_intMapData[CROSSBOW_25M_Y2]);
    ui->crossbow_x1_bottom->setValue(m_intMapData[CROSSBOW_X1_BOTTOM]);
    ui->crossbow_y1_bottom->setValue(m_intMapData[CROSSBOW_Y1_BOTTOM]);
    ui->crossbow_x2_bottom->setValue(m_intMapData[CROSSBOW_X2_BOTTOM]);
    ui->crossbow_y2_bottom->setValue(m_intMapData[CROSSBOW_Y2_BOTTOM]);
    ui->crossbow_4_PngY_bottom->setValue(m_intMapData[CROSSBOW_4_PNGY_BOTTOM]);

}



void Menu::on_btnSave_clicked()
{
    //特殊变量 ，先存到map里 ，在由map存入数据库
    if (ui->checkBoxcheck_sMap_Point_Solo->isChecked())
    {
        // m_intMapData[CHECK_SMAP_POINT_SOLO]=1;
        // *m_check_sMap_Point_Solo = m_intMapData[CHECK_SMAP_POINT_SOLO];
        *m_check_sMap_Point_Solo=1;
    }
    else
    {
        // m_intMapData[CHECK_SMAP_POINT_SOLO]=0;
        // *m_check_sMap_Point_Solo = m_intMapData[CHECK_SMAP_POINT_SOLO];
        *m_check_sMap_Point_Solo=0;
    }
    m_intMapData[CHECK_SMAP_POINT_SOLO]=*m_check_sMap_Point_Solo;

    *m_Magnify_UPy0 = ui->Magnify_UPy0->value();
    m_intMapData[MAGNIFY_UPY0]=*m_Magnify_UPy0;

    *m_winMagnify_n = ui->winMagnify_n->value();
    m_doubleMapData[WINMAGNIFY_N]=*m_winMagnify_n;

    //将ui控件的数据写入Map
    //int
    m_intMapData[SCREEN_RESOLUTION_X] = ui->screen_resolution_x->value();
    m_intMapData[SCREEN_RESOLUTION_Y] = ui->screen_resolution_y->value();

    m_intMapData[SMAP400_X1] = ui->sMap400_x1->value();
    m_intMapData[SMAP400_Y1] = ui->sMap400_y1->value();
    m_intMapData[SMAP400_X2] = ui->sMap400_x2->value();
    m_intMapData[SMAP400_Y2] = ui->sMap400_y2->value();

    m_intMapData[SMAP700_X1] = ui->sMap700_x1->value();
    m_intMapData[SMAP700_Y1] = ui->sMap700_y1->value();
    m_intMapData[SMAP700_X2] = ui->sMap700_x2->value();
    m_intMapData[SMAP700_Y2] = ui->sMap700_y2->value();

    m_intMapData[MAGNIFY_UPY0]=ui->Magnify_UPy0->value();

    m_intMapData[POINT_PNG_TARGET_X]=ui->point_PngTarget_x->value();
    m_intMapData[POINT_PNG_TARGET_Y]=ui->point_PngTarget_y->value();

    m_intMapData[CROSSBOW_X1] = ui->crossbow_x1->value();
    m_intMapData[CROSSBOW_Y1] = ui->crossbow_y1->value();
    m_intMapData[CROSSBOW_X2] = ui->crossbow_x2->value();
    m_intMapData[CROSSBOW_Y2] = ui->crossbow_y2->value();
    m_intMapData[CROSSBOW_4_2R] = ui->crossbow_4_2R->value();
    m_intMapData[CROSSBOW_4_PNGY] = ui->crossbow_4_PngY->value();
    m_intMapData[CROSSBOW_25M_X1] = ui->crossbow_25m_x1->value();
    m_intMapData[CROSSBOW_25M_Y1] = ui->crossbow_25m_y1->value();
    m_intMapData[CROSSBOW_25M_X2] = ui->crossbow_25m_x2->value();
    m_intMapData[CROSSBOW_25M_Y2] = ui->crossbow_25m_y2->value();
    m_intMapData[CROSSBOW_X1_BOTTOM] = ui->crossbow_x1_bottom->value();
    m_intMapData[CROSSBOW_Y1_BOTTOM] = ui->crossbow_y1_bottom->value();
    m_intMapData[CROSSBOW_X2_BOTTOM] = ui->crossbow_x2_bottom->value();
    m_intMapData[CROSSBOW_Y2_BOTTOM] = ui->crossbow_y2_bottom->value();
    m_intMapData[CROSSBOW_4_PNGY_BOTTOM] = ui->crossbow_4_PngY_bottom->value();





    //double
    m_doubleMapData[SCREEN_MAGNIFY] = ui->screen_magnify->value();
    m_doubleMapData[WINMAGNIFY_N]=ui->winMagnify_n->value();





    //将map写入数据库
    C_SQL sql;
    sql.write_intMapData(m_intMapData);
    sql.write_doubleMapData(m_doubleMapData);
    sql.write_QColorMapData(m_QColorMapData);

    //将map更新到其他类里
    if(ui->checkBoxRunning->isChecked())
    {
        //小地图
        if(1)
        {
            m_C_sMap->getxy
                (
                    m_intMapData[SMAP400_X1],
                    m_intMapData[SMAP400_Y1],
                    m_intMapData[SMAP400_X2],
                    m_intMapData[SMAP400_Y2],

                    m_intMapData[SMAP700_X1],
                    m_intMapData[SMAP700_Y1],
                    m_intMapData[SMAP700_X2],
                    m_intMapData[SMAP700_Y2],

                    m_doubleMapData[SCREEN_MAGNIFY],

                    *m_sMap_MeterSize
                    );
        }

        //小地图测距
        if(1)
        {
            m_C_sMap_Point->getxy
                (
                    *m_check_sMap_Point_Solo,
                    *m_sMap_MeterSize,


                    m_intMapData[SMAP400_X1],
                    m_intMapData[SMAP400_Y1],
                    m_intMapData[SMAP400_X2],
                    m_intMapData[SMAP400_Y2],

                    m_intMapData[SMAP700_X1],
                    m_intMapData[SMAP700_Y1],
                    m_intMapData[SMAP700_X2],
                    m_intMapData[SMAP700_Y2],

                    m_doubleMapData[SCREEN_MAGNIFY],

                    m_intMapData[POINT_PNG_TARGET_X],
                    m_intMapData[POINT_PNG_TARGET_Y]


                    );
        }

        //弩箭
        if(1)
        {
            m_C_Crossbow->getxy
                (
                    m_intMapData[CROSSBOW_X1],
                    m_intMapData[CROSSBOW_Y1],
                    m_intMapData[CROSSBOW_X2],
                    m_intMapData[CROSSBOW_Y2],
                    m_intMapData[CROSSBOW_4_2R],
                    m_intMapData[CROSSBOW_4_PNGY],

                    m_doubleMapData[SCREEN_MAGNIFY],

                    m_intMapData[SCREEN_RESOLUTION_X],
                    m_intMapData[SCREEN_RESOLUTION_Y],

                    m_intMapData[CROSSBOW_25M_X1],
                    m_intMapData[CROSSBOW_25M_Y1],
                    m_intMapData[CROSSBOW_25M_X2],
                    m_intMapData[CROSSBOW_25M_Y2],

                    m_intMapData[CROSSBOW_X1_BOTTOM],
                    m_intMapData[CROSSBOW_Y1_BOTTOM],
                    m_intMapData[CROSSBOW_X2_BOTTOM],
                    m_intMapData[CROSSBOW_Y2_BOTTOM],
                    m_intMapData[CROSSBOW_4_PNGY_BOTTOM]
                    );

            m_C_Crossbow->resize
                (
                    m_intMapData[SCREEN_RESOLUTION_X] / (m_doubleMapData[SCREEN_MAGNIFY]),
                    m_intMapData[SCREEN_RESOLUTION_Y] / (m_doubleMapData[SCREEN_MAGNIFY])
                    );
        }
    }


}


bool Menu::on_checkBoxRunning(bool checked)
{
    *m_use_winMagnify = true;

    //QMessageBox::information(this, "", "开始运行");

    //小地图
    if(ui->checkBoxRunning->isChecked())
    {
        m_C_sMap = new C_sMap;

        m_C_sMap->getxy
            (
            m_intMapData[SMAP400_X1],
            m_intMapData[SMAP400_Y1],
            m_intMapData[SMAP400_X2],
            m_intMapData[SMAP400_Y2],

            m_intMapData[SMAP700_X1],
            m_intMapData[SMAP700_Y1],
            m_intMapData[SMAP700_X2],
            m_intMapData[SMAP700_Y2],

            m_doubleMapData[SCREEN_MAGNIFY],

                *m_sMap_MeterSize
                );

        //m_C_sMap->getcheck_sMap_DrawArc(*m_check_sMap_DrawArc);

        m_C_sMap->getpenColor
            (
                m_QColorMapData
                //m_QColorMapData[SMAP_COLOR]
                // QColor
                // (
                //     ui.sMap_Manager_R->value(),
                //     ui.sMap_Manager_G->value(),
                //     ui.sMap_Manager_B->value()
                //     )
                );

        m_C_sMap->startTimer();

        m_C_sMap->show();
    }
    else
    {
        m_C_sMap->stopTimer();
        m_C_sMap->close();
        delete m_C_sMap;
        m_C_sMap = nullptr;
    }

    //小地图自动测距
    if (ui->checkBoxRunning->isChecked())
    {
        m_C_sMap_Point = new C_sMap_Point;

        m_C_sMap_Point->getxy
            (
                *m_check_sMap_Point_Solo,
                *m_sMap_MeterSize,


                m_intMapData[SMAP400_X1],
                m_intMapData[SMAP400_Y1],
                m_intMapData[SMAP400_X2],
                m_intMapData[SMAP400_Y2],

                m_intMapData[SMAP700_X1],
                m_intMapData[SMAP700_Y1],
                m_intMapData[SMAP700_X2],
                m_intMapData[SMAP700_Y2],

                m_doubleMapData[SCREEN_MAGNIFY],

                m_intMapData[POINT_PNG_TARGET_X],
                m_intMapData[POINT_PNG_TARGET_Y]


                );

        m_C_sMap_Point->getsendMeterToCrossbow(*m_sendMeterToCrossbow);

        m_C_sMap_Point->getcrossbow_player_number(*m_crossbow_player_number);

        //m_C_sMap_Point->startTimer();
        m_C_sMap_Point->startThread();

        m_C_sMap_Point->show();

    }
    else
    {
        //m_C_sMap_Point->stopTimer();
        m_C_sMap_Point->close();
        delete m_C_sMap_Point;
        m_C_sMap_Point = nullptr;
    }

    //弩箭动态准心
    if (ui->checkBoxRunning->isChecked())
    {
        m_C_Crossbow = new C_Crossbow;


        m_C_Crossbow->getxy
            (
                m_intMapData[CROSSBOW_X1],
                m_intMapData[CROSSBOW_Y1],
                m_intMapData[CROSSBOW_X2],
                m_intMapData[CROSSBOW_Y2],
                m_intMapData[CROSSBOW_4_2R],
                m_intMapData[CROSSBOW_4_PNGY],

                m_doubleMapData[SCREEN_MAGNIFY],

                m_intMapData[SCREEN_RESOLUTION_X],
                m_intMapData[SCREEN_RESOLUTION_Y],

                m_intMapData[CROSSBOW_25M_X1],
                m_intMapData[CROSSBOW_25M_Y1],
                m_intMapData[CROSSBOW_25M_X2],
                m_intMapData[CROSSBOW_25M_Y2],

                m_intMapData[CROSSBOW_X1_BOTTOM],
                m_intMapData[CROSSBOW_Y1_BOTTOM],
                m_intMapData[CROSSBOW_X2_BOTTOM],
                m_intMapData[CROSSBOW_Y2_BOTTOM],
                m_intMapData[CROSSBOW_4_PNGY_BOTTOM]
                );

        m_C_Crossbow->getsendMeterToCrossbow(*m_sendMeterToCrossbow);

        m_C_Crossbow->getcrossbow_player_number(*m_crossbow_player_number);

        m_C_Crossbow->resize
            (
                m_intMapData[SCREEN_RESOLUTION_X] / (m_doubleMapData[SCREEN_MAGNIFY]),
                m_intMapData[SCREEN_RESOLUTION_Y] / (m_doubleMapData[SCREEN_MAGNIFY])
                );

        m_C_Crossbow->setPenColor(m_QColorMapData);


        m_C_Crossbow->startTimer();

        m_C_Crossbow->show();

    }
    else
    {
        m_C_Crossbow->stopTimer();
        m_C_Crossbow->close();
        delete m_C_Crossbow;
        m_C_Crossbow = nullptr;
    }



    return false;
}

void Menu::getsendMeterToCrossbow(int &sendMeterToCrossbow)
{
    m_sendMeterToCrossbow = &sendMeterToCrossbow;
}

void Menu::getMagnify(int &Magnify_UPy0, float &winMagnify_n)
{
    m_Magnify_UPy0 = &Magnify_UPy0;
    m_winMagnify_n = &winMagnify_n;

    //赋值到菜单控件
    ui->Magnify_UPy0->setValue(*m_Magnify_UPy0);
    ui->winMagnify_n->setValue(*m_winMagnify_n);
}

void Menu::getuse_winMagnify(bool &use_winMagnify)
{
    m_use_winMagnify = &use_winMagnify;

    //ui->Magnify_UPy0->setValue(*m_Magnify_UPy0);
    //ui->winMagnify_n->setValue(*m_winMagnify_n);
}


void Menu::on_comboBoxPlayerNumber_activated(int index)
{
    *m_crossbow_player_number = index;

    ui->playerNumber->setText(QString::number(index));
}




void Menu::on_btnClose_clicked()
{
    close();
}


void Menu::on_btnMinimize_clicked()
{
    showMinimized();
}

void Menu::slot_RGB_Setting(int action)
{
    if(!isUserInteraction){
        //QMessageBox::information(this, "", "读取map[newKey]颜色，不触发槽函数");
        return;
    }

    //获取新的颜色
    QColor newColor =
    {
        ui->Red->value(),
        ui->Green->value(),
        ui->Blue->value()
    };

    //将颜色值写到Label
    ui->labelR->setText(QString::number(ui->Red->value()));
    ui->labelG->setText(QString::number(ui->Green->value()));
    ui->labelB->setText(QString::number(ui->Blue->value()));
    ui->labelRGB->setStyleSheet("background-color:" + newColor.name());

    //将颜色更新到map里
    //1、获取自定义index
    int defaultIndex = ui->comboBoxColor->currentIndex();

    int customIndex = ui->comboBoxColor->itemData(defaultIndex).toInt();

    int key = customIndex;

    //赋值
    m_QColorMapData[key]=newColor;

    //更新到类里
    if(ui->checkBoxRunning->isChecked())
    {
        //小地图
        m_C_sMap->getpenColor(m_QColorMapData);

        //弩箭
        m_C_Crossbow->setPenColor(m_QColorMapData);
    }


}



void Menu::on_comboBoxColor_activated(int index)
{
    isUserInteraction = false; // 标记为非用户操作，不能触发槽函数

    //读取map，切换颜色。修改滑轨的值，不能触发槽函数，否则会修改颜色
    //获取新的 自定义索引
    int key = ui->comboBoxColor->itemData(index).toInt();
    //将颜色值写到滑轨
    ui->Red->setValue(m_QColorMapData[key].red());
    ui->Green->setValue(m_QColorMapData[key].green());
    ui->Blue->setValue(m_QColorMapData[key].blue());
    //将颜色值写到Label
    ui->labelR->setText(QString::number(ui->Red->value()));
    ui->labelG->setText(QString::number(ui->Green->value()));
    ui->labelB->setText(QString::number(ui->Blue->value()));
    ui->labelRGB->setStyleSheet("background-color:" + m_QColorMapData[key].name());

    isUserInteraction = true;  // 恢复标志位（可选，因为滑动结束后会恢复）
}


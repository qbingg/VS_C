#ifndef C_SMAP_POINT_H
#define C_SMAP_POINT_H

#include <QWidget>

#include "C_sMap_Point_Thread.h"
#include "Defines.h"
#include <qtimer.h>
#include <qpainter.h>
#include <Windows.h>
#include <opencv2/opencv.hpp>

namespace Ui {
class C_sMap_Point;
}

class C_sMap_Point : public QWidget
{
    Q_OBJECT

public:
    explicit C_sMap_Point(QWidget *parent = nullptr);
    ~C_sMap_Point();

private:
    Ui::C_sMap_Point *ui;

    int* check_sMap_Point_Solo;
    int* sMap_MeterSize;

    int point_PngTarget_x;
    int point_PngTarget_y;

    int sMap400_x1;
    int sMap400_y1;
    int sMap400_x2;
    int sMap400_y2;

    int sMap700_x1;
    int sMap700_y1;
    int sMap700_x2;
    int sMap700_y2;

    double magnify_n;//125%->0.8



public:
    void getxy
        (
            int& m_check_sMap_Point_Solo,
            int& m_sMap_MeterSize,

            int m_sMap400_x1,
            int m_sMap400_y1,
            int m_sMap400_x2,
            int m_sMap400_y2,

            int m_sMap700_x1,
            int m_sMap700_y1,
            int m_sMap700_x2,
            int m_sMap700_y2,

            double m_magnify_n,

            int m_point_PngTarget_x,
            int m_point_PngTarget_y

            );

private:
    //QTimer* m_timer;
private slots:
    //void updateWidget();
public:
    void paintEvent(QPaintEvent* event);
    //void startTimer();
    //void stopTimer();


private:
    int target_point_x[5];
    int target_point_y[5];
    float n[5];
    //cv::Mat img_point[5];
    //cv::Mat screen[5];
    //QColor penColor[5] = { Qt::yellow, Qt::white,Qt::red, Qt::blue,Qt::green };
    QColor penColor[5] =
        {
            Qt::yellow,		//0黄
            Qt::yellow,		//1黄
            {255,127,0},	//2橙
            {0,165,255},	//3蓝
            Qt::green		//4绿
        };


public:
    //float function_templematch_advance(cv::Mat image,int i);
    //void function_screen(cv::Mat& image, int i,int x1, int y1, int x2, int y2);
    double function_Pixels_To_Meters(int Pixel_x, int Pixel_y);


    //将自动测距的米数穿透到弩箭自动测距上
private:
    int* sendMeterToCrossbow;
    int* crossbow_player_number;
public:
    void getsendMeterToCrossbow(int& m_sendMeterToCrossbow);
    void getcrossbow_player_number(int& m_crossbow_player_number);

    //多线程
private:
    C_sMap_Point_Thread sMap_thread;
public:
    void startThread();
private slots:
    void receiveSignal(QMap<int,C_opencv>);


    /*原小地图画圆，画框：*/
private:
    int width400, height400;
    int width700, height700;
    QColor penColorBorder = QColor::fromString("#00ff00");
    QColor penColor310m = QColor::fromString("#00ff00");
public:
    int f(int x);
    int F(int meter);
    int meter_To_Pixel(int meter);
    void getpenColor(QMap<int,QColor> QColorMapData);

private:
    std::chrono::steady_clock::time_point start;

};

#endif // C_SMAP_POINT_H

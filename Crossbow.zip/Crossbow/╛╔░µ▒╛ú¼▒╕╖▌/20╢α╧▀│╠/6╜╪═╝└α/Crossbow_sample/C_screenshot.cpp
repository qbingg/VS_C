#include "C_screenshot.h"

cv::Mat C_screenshot::function_colorfulScreenshotByHandle(const int x1, const int y1, const int x2, const int y2)
{

    //PUBG窗口截图方式
    LPCWSTR str = PUBGWINDOWNAME;
    // 1. 查找窗口句柄

    //LPCWSTR str = L"PUBG：绝地求生 ";//md后面藏了个空格!!!!!!!!!!!!!!!!!       D:\SEenvironment\VisualSC2022\Community\Common7\Tools\spyxx_amd64.exe
    // LPCWSTR str = L"TslGame";

    HWND hwnd = FindWindowW(NULL, str);
    if (hwnd == NULL) {
        //exit(0);
        //QMessageBox::information(this, "错误", "截图失败，获取窗口失败");
        // 返回一个空的 cv::Mat 对象
        return cv::Mat();
    }

    // 获取屏幕设备的上下文
    HDC hScreenDC = GetWindowDC(hwnd);

    // 3. 获取窗口尺寸
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) {
        //std::cerr << "无法获取窗口尺寸" << std::endl;
        //QMessageBox::information(this, "错误", "截图失败，无法获取窗口尺寸");
        ReleaseDC(hwnd, hScreenDC);
        // 返回一个空的 cv::Mat 对象
        return cv::Mat();
    }

    // 获取屏幕设备的上下文
    //HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

    // 锁定位图的像素区域以便访问
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像
    //cv::Mat grayScreenshot;
    //cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    return screenshot;
}

C_screenshot::C_screenshot() {}

// void C_screenshot::setScreenshotArea(const int x1, const int y1, const int x2, const int y2)
// {
//     m_x1=x1;
//     m_x2=x2;
//     m_y1=y1;
//     m_y2=y2;
// }

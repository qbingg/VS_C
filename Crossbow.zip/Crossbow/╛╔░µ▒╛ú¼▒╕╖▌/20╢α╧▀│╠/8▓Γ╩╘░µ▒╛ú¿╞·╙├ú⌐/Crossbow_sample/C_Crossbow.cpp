#include "C_Crossbow.h"

C_Crossbow::C_Crossbow(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
    setWindowTitle("弩箭动态准心");
    //设置图标
    QIcon icon("res/img/CrossbowIcon.png");
    setWindowIcon(icon);

    setAttribute(Qt::WA_TranslucentBackground);

    //绑定槽函数：接受信号
    connect(&crossbow_thread,&C_Crossbow_Thread::newValue,this,&C_Crossbow::receiveSignal);
    connect(&crossbow_thread,&C_Crossbow_Thread::sendUpdateOnceToClear,this,&C_Crossbow::receiveSignalUpdateOnceToClear);

    start = std::chrono::high_resolution_clock::now();

}

C_Crossbow::~C_Crossbow()
{}

void C_Crossbow::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);

    //松开右键后，清屏
    if(updateOnceToClear)
    {
        updateOnceToClear = false;

        return;
    }

    if (1)
    {


        painter.setPen(player_number_color[*crossbow_player_number]);
        QFont font1;
        font1.setPointSizeF(15);
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);


        //对个位数进行不足近似,米数
        int round = ((*sendMeterToCrossbow) / 10) * 10;//186m->180m

        //将“不足近似”输出到屏幕
        painter.drawText((screen_resolution_x / 2) * magnify_n + 480, res_y2 * magnify_n, QString::number(round));

        //4倍镜顶部输出参数
        QString top = "顶部y：" + QString::number(res_y2);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 550, res_y2 * magnify_n, top);
        QString n_top = "顶部n：" + QString::number(n2, 'f', 4);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 550, res_y2 * magnify_n+20, n_top);
        //4倍镜底部输出参数
        QString bottom = "底部y：" + QString::number(res_y2_bottom);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 700, res_y2 * magnify_n, bottom);
        QString n_bottom = "底部n：" + QString::number(n2_bottom, 'f', 4);
        painter.drawText((screen_resolution_x / 2) * magnify_n + 700, res_y2 * magnify_n+20, n_bottom);


        //如果不是弩箭开镜，则函数立刻结束，不划线
        if (n_25m < 0.8)
        {
            return;
        }

        //如果顶部和底部测得的y值相近，优先使用顶部的y2
        int res_y = res_y2;
        int differentResult = abs(res_y2 - res_y2_bottom);//计算两个res_y2的绝对差值

        //如果res_y2的绝对差值大于2
        if (differentResult > 2)
        {
            //如果底部拟合度大于顶部，使用底部数据划线
            if (n2_bottom>n2)
            {
                res_y = res_y2_bottom;

                painter.drawText((screen_resolution_x / 2) * magnify_n + 700, res_y * magnify_n + 40, "使用底部数据划线");
            }
        }



        //通过map查询刻度是否存在: round,和round+10
        if ((meterToPixel.count(round)) && (meterToPixel.count(round + 10)))
        {
            //通过map查询刻度 round,和round+10
            int sendMeterToCrossbowHeight =
                (
                    res_y //四倍镜准心高度

                    + meterToPixel[round]//180m刻度对应的高度

                    //186-180 = 6得到6/10=0.6  得到 0.6*（190m与180m对应刻度像素的差值）
                    + (((*sendMeterToCrossbow) - static_cast<double>(round)) / 10) * (meterToPixel[round + 10] - meterToPixel[round])

                    ) * magnify_n;


            //标出米数
            painter.drawText((screen_resolution_x / 2) * magnify_n - 60, sendMeterToCrossbowHeight - 3 , QString::number(*sendMeterToCrossbow));


            //大于等于40m，划线
            if (round >= 40)
            {
                //painter.setPen(Qt::yellow);

                painter.drawLine
                    (
                        ((screen_resolution_x - crossbow_4_R) / 2) * magnify_n,

                        sendMeterToCrossbowHeight,

                        ((screen_resolution_x + crossbow_4_R) / 2) * magnify_n,

                        sendMeterToCrossbowHeight
                        );
            }


        }
        else//如果不存在，则不划线
        {
            //标出米数
            painter.drawText((screen_resolution_x / 2) * magnify_n - 60, (res_y) * magnify_n - 3, QString::number(*sendMeterToCrossbow));
        }




        QFont meter_rank;
        font1.setPointSizeF(7);
        painter.setFont(meter_rank);
        painter.setBrush(Qt::NoBrush);


        int max = 4 * magnify_n;//字体误差

        int X = (screen_resolution_x / static_cast<double>(2)) * magnify_n;


        for (int meter = 40; meter <= 310; meter += 10)
        {
            painter.setPen(QPenMap[meter]);
            painter.drawLine
                (
                    X,

                    (res_y + meterToPixel[meter])* magnify_n,

                    X + LineMap[meter],

                    (res_y + meterToPixel[meter])* magnify_n
                    );
            painter.drawText
                (

                        X + LineMap[meter],

                    max + (res_y + meterToPixel[meter]) * magnify_n,

                    QString::number(meter)
                    );
        }

    }

    std::chrono::steady_clock::time_point end = std::chrono::high_resolution_clock::now();

    long long opencvDuration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    painter.setPen(player_number_color[*crossbow_player_number]);
    QFont font000;
    font000.setPointSizeF(15);
    painter.setFont(font000);
    painter.drawText(50, 100, "每次update()耗时ms：\t"+QString::number(opencvDuration));

    // 如果需要将 end 赋值给 start（例如重新开始计时）
    start = end;
}

void C_Crossbow::getxy(int m_crossbow_x1, int m_crossbow_y1, int m_crossbow_x2, int m_crossbow_y2, int m_crossbow_4_2R, int m_crossbow_4_PngY, double m_magnify_n, int m_screen_resolution_x, int m_screen_resolution_y, int m_crossbow_25m_x1, int m_crossbow_25m_y1, int m_crossbow_25m_x2, int m_crossbow_25m_y2, int m_crossbow_x1_bottom, int m_crossbow_y1_bottom, int m_crossbow_x2_bottom, int m_crossbow_y2_bottom, int m_crossbow_4_PngY_bottom)
{
    crossbow_x1 = m_crossbow_x1;
    crossbow_y1 = m_crossbow_y1;
    crossbow_x2 = m_crossbow_x2;
    crossbow_y2 = m_crossbow_y2;
    crossbow_4_R = m_crossbow_4_2R / static_cast<double>(2);//直径-》》半径
    crossbow_4_PngY = m_crossbow_4_PngY;

    magnify_n = (static_cast<double>(1) / m_magnify_n);//125%->0.8

    screen_resolution_x = m_screen_resolution_x;
    screen_resolution_y = m_screen_resolution_y;

    crossbow_25m_x1 = m_crossbow_25m_x1;
    crossbow_25m_y1 = m_crossbow_25m_y1;
    crossbow_25m_x2 = m_crossbow_25m_x2;
    crossbow_25m_y2 = m_crossbow_25m_y2;



    crossbow_x1_bottom = m_crossbow_x1_bottom;
    crossbow_y1_bottom = m_crossbow_y1_bottom;
    crossbow_x2_bottom = m_crossbow_x2_bottom;
    crossbow_y2_bottom = m_crossbow_y2_bottom;
    crossbow_4_PngY_bottom = m_crossbow_4_PngY_bottom;

    //m_k = crossbow_4_310m / static_cast<double>(479);

    // 提前算好 【四倍镜半径像素 *（百分比刻度）】
    for (auto& [key, value] : percentage)
    {
        //meterToPixel.insert({ key,value * crossbow_4_R });//百分比*4倍镜半径 //insert不能插入已经存在的键，及不能修改覆盖
        //解决方法也非常简单，先初始化meterToPixel[40]~[310],值为0，先占茅坑不拉屎。省去第一次插入，只有修改
        meterToPixel[key] = value * crossbow_4_R;
    }

    crossbow_thread.getxy(
        m_crossbow_x1,
        m_crossbow_y1,
        m_crossbow_x2,
        m_crossbow_y2,
        m_crossbow_4_2R,//直径-》》半径
        m_crossbow_4_PngY,

        m_magnify_n,//125%->0.8

        m_screen_resolution_x,
        m_screen_resolution_y,

        m_crossbow_25m_x1,
        m_crossbow_25m_y1,
        m_crossbow_25m_x2,
        m_crossbow_25m_y2,

        m_crossbow_x1_bottom,
        m_crossbow_y1_bottom,
        m_crossbow_x2_bottom,
        m_crossbow_y2_bottom,
        m_crossbow_4_PngY_bottom
        );


}

void C_Crossbow::getsendMeterToCrossbow(int& m_sendMeterToCrossbow)
{
    sendMeterToCrossbow = &m_sendMeterToCrossbow;
}

void C_Crossbow::getcrossbow_player_number(int &m_crossbow_player_number)
{
    crossbow_player_number=&m_crossbow_player_number;
}

void C_Crossbow::setPenColor(QMap<int, QColor> QColorMapData)
{
    for(int key :QPenMap.keys()){

        QPen newPen = QPen(QColorMapData[key], 1);

        QPenMap[key] = newPen;

    }
}

void C_Crossbow::startThread()
{
    //与startTimer类似，运行多线程
    //注意要在数据获取getxy之后
    //在绑定槽函数之后
    crossbow_thread.start();
}

void C_Crossbow::receiveSignal(QMap<int, C_opencv> crossbow_opencv)
{
    ///////////////////////////////////

    // n_25m
    // n2
    // n2_bottom

    // res_y2
    // res_y2_bottom

    n_25m       = crossbow_opencv[0].getN();
    n2          = crossbow_opencv[1].getN();
    n2_bottom   = crossbow_opencv[2].getN();

    res_y2 = crossbow_y1 + crossbow_4_PngY + crossbow_4_R + crossbow_opencv[1].getTarget_point().y;

    res_y2_bottom = crossbow_y1_bottom + crossbow_4_PngY_bottom - crossbow_4_R + crossbow_opencv[2].getTarget_point().y;

    update();
}

void C_Crossbow::receiveSignalUpdateOnceToClear(bool newUpdateOnceToClear)
{
    updateOnceToClear = newUpdateOnceToClear;
    update();
}



#ifndef C_CROSSBOW_H
#define C_CROSSBOW_H

#include <QWidget>

#include "Defines.h"
#include <qtimer.h>
#include <qpainter.h>
#include <Windows.h>
#include "C_Crossbow_Thread.h"

namespace Ui {
class C_Crossbow;
}

class C_Crossbow : public QWidget
{
    Q_OBJECT

public:
    explicit C_Crossbow(QWidget *parent = nullptr);
    ~C_Crossbow();

private:
    Ui::C_Crossbow *ui;


public:
    void paintEvent(QPaintEvent* event);


private:
    int crossbow_x1;
    int crossbow_y1;
    int crossbow_x2;
    int crossbow_y2;
    int crossbow_4_R;
    int crossbow_4_PngY;
    double magnify_n;//125%->0.8
    int screen_resolution_x;
    int screen_resolution_y;

    int crossbow_25m_x1;
    int crossbow_25m_y1;
    int crossbow_25m_x2;
    int crossbow_25m_y2;

    int crossbow_x1_bottom;
    int crossbow_y1_bottom;
    int crossbow_x2_bottom;
    int crossbow_y2_bottom;
    int crossbow_4_PngY_bottom;
public:
    void getxy
        (
            int m_crossbow_x1,
            int m_crossbow_y1,
            int m_crossbow_x2,
            int m_crossbow_y2,
            int m_crossbow_4_2R,//直径
            int m_crossbow_4_PngY,
            double m_magnify_n,
            int m_screen_resolution_x,
            int m_screen_resolution_y,

            int m_crossbow_25m_x1,
            int m_crossbow_25m_y1,
            int m_crossbow_25m_x2,
            int m_crossbow_25m_y2,

            int m_crossbow_x1_bottom,
            int m_crossbow_y1_bottom,
            int m_crossbow_x2_bottom,
            int m_crossbow_y2_bottom,
            int m_crossbow_4_PngY_bottom
            );

private:


    int res_y2,res_y2_bottom;//最终输出的y坐标	res_y2_bottom需要特殊处理
    float n2,n2_bottom;
    float n_25m;//确定是否为弩箭开镜

    //将自动测距的米数穿透到弩箭自动测距上
private:
    int* sendMeterToCrossbow;
    // 米数对应刻度表，注意：四倍镜半径像素 *（百分比刻度）*窗口缩放倍率= 最终的像素
    // 在初始化后，meterToPixel会自动乘上： 四倍镜半径
    //
    // meterToPixel[40]*窗口缩放倍率 = 40m的最终的像素
    const std::map<int, double> percentage = {//310在2k对应400个像素，4倍镜半径为409个像素：[（x/479）* 400]/409
        {       40      ,       0.0326679               },
        {       50      ,       0.0571688               },
        {       60      ,       0.0857532               },
        {       70      ,       0.124546                },
        {       80      ,       0.157214                },
        {       90      ,       0.193966                },
        {       100     ,       0.226634                },
        {       110     ,       0.259301                },
        {       120     ,       0.296053                },
        {       130     ,       0.328721                },
        {       140     ,       0.367514                },
        {       150     ,       0.400182                },
        {       160     ,       0.43285					},
        {       170     ,       0.469601                },
        {       180     ,       0.504311                },
        {       190     ,       0.543104                },
        {       200     ,       0.577813                },
        {       210     ,       0.614565                },
        {       220     ,       0.651316                },
        {       230     ,       0.686026                },
        {       240     ,       0.720735                },
        {       250     ,       0.759529                },
        {       260     ,       0.792196                },
        {       270     ,       0.820781                },
        {       280     ,       0.859574                },
        {       290     ,       0.898367                },
        {       300     ,       0.939202                },
        {       310     ,       0.977995                }

    };
    //初始化，值为0，不insert，只修改值
    std::map<int, double> meterToPixel = {
        {       40      ,       0               },
        {       50      ,       0               },
        {       60      ,       0               },
        {       70      ,       0               },
        {       80      ,       0               },
        {       90      ,       0               },
        {       100     ,       0               },
        {       110     ,       0               },
        {       120     ,       0               },
        {       130     ,       0               },
        {       140     ,       0               },
        {       150     ,       0               },
        {       160     ,       0               },
        {       170     ,       0               },
        {       180     ,       0               },
        {       190     ,       0               },
        {       200     ,       0               },
        {       210     ,       0               },
        {       220     ,       0               },
        {       230     ,       0               },
        {       240     ,       0               },
        {       250     ,       0               },
        {       260     ,       0               },
        {       270     ,       0               },
        {       280     ,       0               },
        {       290     ,       0               },
        {       300     ,       0               },
        {       310     ,       0               }
    };

    QMap<int, QPen> QPenMap ={
        {	40	,	QPen(Qt::black, 1)	},
        {	50	,	QPen(Qt::blue, 1)	},
        {   60	,	QPen(Qt::black, 1)	},
        {	70	,	QPen(Qt::white, 1)	},
        {	80	,	QPen(Qt::white, 1)  },
        {	90	,	QPen(Qt::black, 1)  },
        {	100	,	QPen(Qt::green, 1) },

        {	110	,	QPen(Qt::black, 1) },
        {	120	,	QPen(Qt::white, 1) },
        {	130	,	QPen(Qt::white, 1) },
        {	140	,	QPen(Qt::black, 1) },
        {	150	,	QPen(Qt::blue, 1) },

        {	160	,	QPen(Qt::black, 1) },
        {	170	,	QPen(Qt::white, 1) },
        {	180	,	QPen(Qt::white, 1) },
        {	190	,	QPen(Qt::black, 1) },
        {	200	,	QPen(Qt::green, 1) },

        {	210	,	QPen(Qt::black, 1) },
        {	220	,	QPen(Qt::white, 1) },
        {	230	,	QPen(Qt::white, 1) },
        {	240	,	QPen(Qt::black, 1) },
        {	250	,	QPen(Qt::blue, 1) },

        {	260	,	QPen(Qt::black, 1) },
        {	270	,	QPen(Qt::white, 1)},
        {	280	,	QPen(Qt::white, 1) },
        {	290	,	QPen(Qt::black, 1) },
        {	300	,	QPen(Qt::green, 1) },

        {	310	,	QPen(Qt::red, 1) }

    };

    std::map<int, int> LineMap = {
        {	40	,	100	},
        {	50	,	100	},
        {   60	,	20	},
        {	70	,	40	},
        {	80	,	60  },
        {	90	,	80  },
        {	100	,	120 },

        {	110	,	20 },
        {	120	,	40 },
        {	130	,	60 },
        {	140	,	80 },
        {	150	,	100 },

        {	160	,	20 },
        {	170	,	40 },
        {	180	,	60 },
        {	190	,	80 },
        {	200	,	120 },

        {	210	,	20 },
        {	220	,	40 },
        {	230	,	60 },
        {	240	,	80 },
        {	250	,	100 },

        {	260	,	20 },
        {	270	,	40 },
        {	280	,	60 },
        {	290	,	80 },
        {	300	,	120 },

        {	310	,	200 }

    };

    int* crossbow_player_number;
    QColor player_number_color[5] =
        {
            Qt::yellow,		//1黄
            {255,127,0},	//2橙
            {0,165,255},	//3蓝
            Qt::green		//4绿
        };

public:
    void getsendMeterToCrossbow(int& m_sendMeterToCrossbow);
    void getcrossbow_player_number(int& m_crossbow_player_number);
    void setPenColor(QMap<int,QColor> QColorMapData);


    //多线程
private:
    C_Crossbow_Thread crossbow_thread;
    //退出准心时，调用一次以清除画面
    bool updateOnceToClear = true;//初始化为true，因为Crossbow类初始化时，show()会调用一次paintEvent函数，导致启动程序时，绘画异常
public:
    void startThread();
private slots:
    void receiveSignal(QMap<int,C_opencv> crossbow_opencv);
    void receiveSignalUpdateOnceToClear(bool newUpdateOnceToClear);

private:
    std::chrono::steady_clock::time_point start;

};

#endif // C_CROSSBOW_H

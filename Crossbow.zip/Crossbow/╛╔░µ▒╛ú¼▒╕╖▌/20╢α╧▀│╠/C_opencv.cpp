#include "C_opencv.h"

C_opencv::C_opencv() {}

void C_opencv::setImage_screen(const cv::Mat &newImage_screen)
{
    image_screen = newImage_screen;
}

void C_opencv::setImage_templ(const cv::Mat &newImage_templ)
{
    image_templ = newImage_templ;
}

cv::Point C_opencv::getTarget_point() const
{
    return target_point;
}

double C_opencv::getN() const
{
    return n;
}

void C_opencv::function_matchTemplate(const cv::Mat &intput_src, const cv::Mat &intput_templ, cv::Point &output_point, double &output_n)
{

}



#ifndef C_OPENCV_H
#define C_OPENCV_H

#include"Defines.h"

class C_opencv
{
private:
    cv::Mat image_screen;//截图
    cv::Mat image_templ;//模板图像
    cv::Point target_point;//目标所在位置
    double n;//拟合度
public:
    C_opencv();

    void setImage_screen(const cv::Mat &newImage_screen);//设置截图

    void setImage_templ(const cv::Mat &newImage_templ);//设置模板图像

    cv::Point getTarget_point() const;//返回图像检测到的位置

    double getN() const;//返回图像检测的拟合度


    void function_matchTemplate(
        const cv::Mat &intput_src,
        const cv::Mat &intput_templ,
        cv::Point &output_point,
        double &output_n
        );

};

#endif // C_OPENCV_H

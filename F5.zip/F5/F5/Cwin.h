﻿#pragma once

#include <QWidget>
#include "ui_Cwin.h"
#include "VS_C.h"

class Cwin : public QWidget
{
	Q_OBJECT

public:
	Cwin(QWidget *parent = nullptr);
	~Cwin();

private:
	int time_n=500;
	Ui::CwinClass ui;
	QTimer* m_timer;
	const bool* m_Click;
private slots:
	void updateWidget();
public:
	void getClick(bool& Click);
	void paintEvent(QPaintEvent* event);
	void startTimer();
	void stopTimer();
};

﻿#pragma once

#include <qtimer.h>
#include <qpainter.h>
#include <Windows.h>
#include <thread>

//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\SEenvironment\OpenCV\opencv\build\include
//                      D:\SEenvironment\OpenCV\opencv\build\include\opencv2
// 4.库目录 D:\SEenvironment\OpenCV\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
//#include <opencv2/opencv.hpp>

#define S1 Sleep(1);
#define S30 Sleep(30);
#define S100 Sleep(100);
#define S1000 Sleep(1000);

#define GET_LB GetAsyncKeyState(VK_LBUTTON) 
#define GET_RB GetAsyncKeyState(VK_RBUTTON) 
#define GET_LSHIFT GetAsyncKeyState(VK_LSHIFT)
#define GET_R GetAsyncKeyState(82) 

#define USE_NUM keybd_event(VK_NUMLOCK, 0, 0, 0);keybd_event(VK_NUMLOCK, 0, KEYEVENTF_KEYUP, 0);

#define th std::thread

#define USE_F7 keybd_event(VK_F7, 0, 0, 0);keybd_event(VK_F7, 0, KEYEVENTF_KEYUP, 0);

#define PUBGWINDOWNAME L"PUBG: BATTLEGROUNDS "


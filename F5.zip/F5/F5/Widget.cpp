﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent, Qt::WindowStaysOnTopHint)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);

}

Widget::~Widget()
{}

void Widget::getkeeping(bool& keeping)
{
    m_keeping = &keeping;
}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_Cwin = new Cwin;

        m_Cwin->getClick(*m_keeping);

        m_Cwin->startTimer();

        m_Cwin->show();
    }
    else
    {
        m_Cwin->stopTimer();
        m_Cwin->close();
        delete m_Cwin;
        m_Cwin = nullptr;
    }
    return false;
}

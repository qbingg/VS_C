﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include "Cwin.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    bool* m_keeping;
public:
    void getkeeping(bool& keeping);
private slots:
    bool on_checkBox(bool checked);
private:
    Cwin* m_Cwin;
};

﻿#include "Cwin.h"

Cwin::Cwin(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);
	m_timer = new QTimer(this);
	connect(m_timer, &QTimer::timeout, this, &Cwin::updateWidget);
	resize(500, 500);
    move(1152, 290);//调整位置
}

Cwin::~Cwin()
{}

void Cwin::getClick(bool& Click)
{
    m_Click = &Click;
}

void Cwin::paintEvent(QPaintEvent* event)
{
    if (*m_Click)
    {
        QPainter painter(this);

        painter.begin(this);///////////////////////////////////////

        // 设置画笔  
        //painter.setPen(QPen(Qt::white, 4));//修改不了字体大小
        painter.setPen(Qt::white);
        QFont font1;
        font1.setPointSizeF(15);//字体大小
        painter.setFont(font1);
        painter.setBrush(Qt::NoBrush);

        painter.drawText(10, 100 + 8, "——— 10米");//字体误差+15/2
        painter.drawText(10, 125 + 8, "——— 20米");
        painter.drawText(10, 188 + 8, "——— 30米");
        painter.drawText(10, 250 + 8, "——— 40米");
        painter.drawText(10, 313 + 8, "——— 50米");

        painter.end();//////////////////////////////////////////////




        painter.begin(this);////////////////////////////////////////

        painter.setPen(QPen(Qt::green, 6));
        painter.setBrush(Qt::NoBrush);
        painter.drawLine(36, 0, 36, time_n);
        time_n -= 1;//每隔10ms，500-1，500*10=5000ms=5秒
        painter.end();//////////////////////////////////////////////




        painter.begin(this);////////////////////////////////////////
        float times = time_n * 0.01;
        QString strNumber = QString::number(times, 'f', 3);
        QString STR = "" + strNumber + " 秒";

        painter.setPen(Qt::red);
        QFont font;
        font.setPointSizeF(50);
        painter.setFont(font);

        painter.drawText(180, 250,STR );
        painter.end();//////////////////////////////////////////////
    }
    else
    {
        time_n = 500;
    }


}

void Cwin::startTimer()
{
	m_timer->start(10);//每隔10ms触发一次
}

void Cwin::stopTimer()
{
	m_timer->stop();
}

void Cwin::updateWidget()
{
    if (*m_Click)
    {
        update();
        
    }
    else
    {
        update();
    }
}
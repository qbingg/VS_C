﻿#pragma once

#include <QWidget>
#include "ui_Cwin.h"
#include "VS_C.h"

class Cwin : public QWidget
{
	Q_OBJECT

public:
	Cwin(QWidget *parent = nullptr);
	~Cwin();

private:
	int time_n=500;//500个像素=5秒	//计时器储存的时间
	Ui::CwinClass ui;
	QTimer* m_timer;//每个X秒触发，此为计时器的指针
	const bool* m_Click;//接收捏雷的信号
private slots:
	void updateWidget();
public:
	void getClick(bool& Click);
	void paintEvent(QPaintEvent* event);//绘图事件，由update()函数触发
	void startTimer();
	void stopTimer();
};

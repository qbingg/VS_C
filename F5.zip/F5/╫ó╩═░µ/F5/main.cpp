﻿#include "Widget.h"
#include <QtWidgets/QApplication>


bool keeping = false;

void f_keep()
{
    while (true)
    {
        GET_LB;
        while (GET_LB)
        {
            GET_R;
            if (GET_R) 
            {
                keeping = true;//按着鼠标左键按R触发
            }
            S1
        }
        if (keeping)
        {
            keeping = false;//投出手雷，重置状态
        }
        S1
    }
}

int main(int argc, char *argv[])
{
    th th_f_keep(f_keep);
    QApplication a(argc, argv);
    Widget w;
    w.getkeeping(keeping);
    w.show();
    return a.exec();
}

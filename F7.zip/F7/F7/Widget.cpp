#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent, Qt::WindowStaysOnTopHint)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);

}

Widget::~Widget()
{}

void Widget::getisCheck(bool& isCheck)
{
    m_isCheck = &isCheck;
}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        *m_isCheck = true;
    }
    else
    {
        *m_isCheck = false;
    }
    return false;
}

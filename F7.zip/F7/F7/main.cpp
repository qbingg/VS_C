#include "Widget.h"
#include <QtWidgets/QApplication>
#include "VS_C.h"

bool isCheck = false;

void f_F7()
{
    while (true)
    {
        GET_LB;
        while (isCheck  &&  GET_LB)
        {
            USE_F7
                bool push_LB = true;
                do {
                    for (int i = 0; i <= 13; i++) 
                    {
                        GET_LB;
                        if (GET_LB) 
                        {
                            break;
                        }

                        if (i == 13) 
                        {
                            push_LB = false;
                        }
                        S30
                    }
                    S1
                } while (push_LB);
            USE_F7
            S1
        }
        S1
    }
}

int main(int argc, char *argv[])
{
    th th_F7(f_F7);
    QApplication a(argc, argv);
    Widget w;
    w.getisCheck(isCheck);
    w.show();
    return a.exec();
}

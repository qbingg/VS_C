﻿#include "Csql.h"

Csql::Csql()//构造函数，尝试打开数据库，失败则创建新的数据库
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("./Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return;
    }
    QSqlQuery query;
    QString sql = QString
    (
        "create table if not exists tb_sleep"
        "(id INTEGER PRIMARY KEY AUTOINCREMENT,"         //自动增长，初始值1，增长步长1(identity不可用，INTEGER PRIMARY KEY AUTOINCREMENT)
        "name varchar(50),"
        "sleepTime int);"
    );
    if (!query.exec(sql))
    {
        qDebug() << "Failed to create table";
        qDebug() << query.lastQuery();
        return;
    }
    m_db.close();
}

bool Csql::readDatas(QList<Data>& datas)
{
    if (!m_db.open())
    {
        qDebug() << "Failed to open database :Database";
        return false;
    }
    QSqlQuery query;
    QString sql = "Select * from tb_sleep;";//tb_sleep 这个是表格名字
    if (!query.exec(sql))
    {
        qDebug() << "Failed to select tb_sleep";//tb_sleep 这个是表格名字
        return false;
    }


    while (query.next())
    {
        Data Data;
        int id = query.value("id").toInt();
        QString name = query.value("name").toString();
        int sleepTime = query.value("sleepTime").toInt();

        //放入链表里
        Data.setData(id, name, sleepTime);
        datas.append(Data);
    }



    m_db.close();

    return true;
}

bool Csql::addData(Data& data)
{

    if (!m_db.open())
    {
        qDebug() << "Failed to open ,addData";
        return false;
    }

    QSqlQuery query;
    //id主键使用了AUTOINCREMENT，相当于identity，不需要插入值//写入不需要，读取需要
    //query.prepare("insert into tb_sleep (id,name,sleepTime)"
    //    "values(:id,:name,:sleepTime)");
    //query.bindValue(":id", data.id());
    query.prepare("insert into tb_sleep (name,sleepTime)"
        "values(:name,:sleepTime)");
    //query.bindValue(":id", data.id());
    query.bindValue(":name", data.name());
    query.bindValue(":sleepTime", data.sleepTime());

    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }
    m_db.close();

    return true;
}

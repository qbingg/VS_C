﻿#pragma once
#include "Data.h"
class Csql
{
private:
    QSqlDatabase m_db;  //数据库连接
public:
    Csql();//构造函数，尝试打开数据库，失败则创建新的数据库
    ~Csql();
    bool readDatas(QList<Data>& datas);//读取数据库，获取数据返回到Qlist里，执行成功返回true
    bool addData(Data& data);//向数据库插入数据，执行成功返回true
};


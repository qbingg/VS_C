﻿#pragma once
#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>
class Data
{
private:
	int m_id;
	QString m_name;
	int m_sleepTime;
public:
	bool setData(int id, QString name, int sleepTime);

	int id() const;
	void setId(int newId);

	QString name() const;
	void setName(const QString& newName);

	int sleepTime() const;
	void setSleepTime(const int& newSleepTime);
};


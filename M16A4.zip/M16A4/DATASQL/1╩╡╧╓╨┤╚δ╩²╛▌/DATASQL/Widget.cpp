﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    m_Csql = new Csql;
    showDatas();//初始化程序时，读取一次数据

    connect(ui.btnAdd, &QPushButton::clicked, this, &Widget::slot_btnAdd);
}

Widget::~Widget()
{}

void Widget::showDatas()
{
    //实例化model
    m_standardModel = new QStandardItemModel(this);

    //查询数据
    QList<Data> datas;
    bool res = m_Csql->readDatas(datas);
    if (!res)
    {
        QMessageBox::information(this, "提示", "查询信息失败");
        return;
    }
    qDebug() << datas.size();

    for (int i = 0; i < datas.size(); ++i)
    {
        appendToModel(datas[i]);
    }
    //添加表头tianjiabiaotou
    QStringList heardList;
    heardList << "id" << "枪名" << "开火间隔";
    m_standardModel->setHorizontalHeaderLabels(heardList);

    //隐藏垂直表头yincang chuizhibiaotou
    ui.tableView->verticalHeader()->setVisible(false);

    ui.tableView->setModel(m_standardModel);

    //设置列宽shezhi liekuan
    for (int col = 0; col < 3; ++col)
    {
        ui.tableView->setColumnWidth(col, (width() - 50) / 3);//列宽跟widget窗口宽度有关
    }
}

bool Widget::appendToModel(Data& data)
{
    //QStandardItem* itemId = new QStandardItem(data.id());//直接输入数字不能正常显示
    //QStandardItem* itemName = new QStandardItem(data.name());
     //QStandardItem* itemSleepTime = new QStandardItem(data.sleepTime());
    QStandardItem* itemId = new QStandardItem(QString::number(data.id()));//QString::number(data.id())

    //复选框，问了ai，这个好像没有单选框
    itemId->setCheckable(true);
    itemId->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);//ju zhong

    QStandardItem* itemName = new QStandardItem(data.name());
    QStandardItem* itemSleepTime = new QStandardItem(QString::number(data.sleepTime()));//QString::number(data.sleepTime())

    QList<QStandardItem*> rowItem;
    rowItem.append(itemId);
    rowItem.append(itemName);
    rowItem.append(itemSleepTime);

    m_standardModel->appendRow(rowItem);

    return true;
}

bool Widget::slot_btnAdd()
{
    Data data;

    //// 获取 tableView 的模型
    //QAbstractItemModel* model = ui.tableView->model();
    //int n = model->rowCount();
    //data.setId(n);

    data.setName(ui.gunName->text());
    data.setSleepTime(ui.gunSleep->value());

    bool res = m_Csql->addData(data);
    if (!res)
    {
        QMessageBox::information(this, "提示", "插入失败!");
        return false;
    }
    appendToModel(data);


    return true;
}
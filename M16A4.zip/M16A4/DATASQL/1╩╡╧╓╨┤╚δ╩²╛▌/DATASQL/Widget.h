﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"

#include "Csql.h"
#include <QStandardItemModel>
#include <qmessagebox.h>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;


private:
    Csql* m_Csql;
    QStandardItemModel* m_standardModel;//tableview通过model显示数据
public:
    void showDatas();//查询数据，从数据库中查询数据，并显示到tableview上
    bool appendToModel(Data& data);//把数据先传到model上，再显示到tableview
private slots:
    bool slot_btnAdd();//添加数据按钮
};

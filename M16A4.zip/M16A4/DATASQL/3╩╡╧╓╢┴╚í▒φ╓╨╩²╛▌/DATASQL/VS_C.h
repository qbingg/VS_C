#pragma once

#include <Windows.h>
#include <thread>

#define S1 Sleep(1);
#define S1000 Sleep(1000);

#define GET_LB GetAsyncKeyState(VK_LBUTTON) 

#define USE_NUM keybd_event(VK_NUMLOCK, 0, 0, 0);keybd_event(VK_NUMLOCK, 0, KEYEVENTF_KEYUP, 0);

#define th std::thread


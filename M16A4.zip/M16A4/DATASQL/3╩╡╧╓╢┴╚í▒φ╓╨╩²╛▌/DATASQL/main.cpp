﻿#include "Widget.h"
#include <QtWidgets/QApplication>
#include "VS_C.h"

int fireTime = 1000;


void f_fire()
{
    while (true)
    {
        GET_LB;
        while (GET_LB)
        {
            USE_NUM
                Sleep(fireTime);
            S1
        }
        S1
    }
}

int main(int argc, char *argv[])
{
    th th_f_fire(f_fire);
    QApplication a(argc, argv);
    Widget w;
    w.getfireTime(fireTime);
    w.show();
    return a.exec();
}

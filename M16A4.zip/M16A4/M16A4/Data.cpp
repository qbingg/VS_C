﻿#include "Data.h"

bool Data::setData(int id, QString name, int sleepTime)
{
    m_id = id;
    m_name = name;
    m_sleepTime = sleepTime;


    return true;
}

int Data::id() const
{
    return m_id;
}

void Data::setId(int newId)
{
    m_id = newId;
}

QString Data::name() const
{
    return m_name;
}

void Data::setName(const QString& newName)
{
    m_name = newName;
}

int Data::sleepTime() const
{
    return m_sleepTime;
}

void Data::setSleepTime(const int& newSleepTime)
{
    m_sleepTime = newSleepTime;
}

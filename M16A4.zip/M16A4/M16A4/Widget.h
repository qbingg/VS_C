﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"

#include <qmessagebox.h>
#include "DataSQL.h"//
#include <QStandardItemModel>//

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    int* m_fireTime;
public:
    void getfireTime(int& fireTime);
private slots:
    bool slot_pushButton(bool checked);
//////////////////////////////////////////
private:
    DataSQL* m_DataSQL;
    QStandardItemModel* m_standardModel;//model
public:
    void showDatas();//查询数据
    bool appendToModel(Data& data);
private slots:
    bool slot_btnAdd();//添加数据按钮
};

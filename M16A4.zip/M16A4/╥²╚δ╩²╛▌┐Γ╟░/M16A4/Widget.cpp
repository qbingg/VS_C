#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent, Qt::WindowStaysOnTopHint)
{
    ui.setupUi(this);

    connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);


}

Widget::~Widget()
{}

void Widget::getfireTime(int& fireTime)
{
    m_fireTime = &fireTime;

    ui.spinBox->setValue(*m_fireTime);
}

bool Widget::slot_pushButton(bool checked)
{
    *m_fireTime = ui.spinBox->value();

    return false;
}

﻿#pragma once
#include <qstring.h>
class Data
{
private:
    int m_id;//学生id 八位数字
    QString m_name;
    int m_sleepTime;
public:
    bool setData(int id, QString name, int sleepTime);

    int id() const;
    void setId(int newId);

    QString name() const;
    void setName(const QString& newName);

    int sleepTime() const;
    void sleepTime(const int& newSleepTime);
};


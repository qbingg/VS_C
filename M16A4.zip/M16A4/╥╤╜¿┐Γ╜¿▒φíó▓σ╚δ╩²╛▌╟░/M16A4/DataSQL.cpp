﻿#include "DataSQL.h"

DataSQL::DataSQL()//构造函数，尝试打开数据库，失败则创建新的数据库
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName("./Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return;
    }
    QSqlQuery query;
    QString sql = QString
    (
        "create table if not exists tb_sleep"
        "(id int primary key not null,"         //自动增长，初始值1，增长步长1(identity不可用？！不知道)
        "name varchar(50),"
        "sleepTime int);"
    );
    if (!query.exec(sql))
    {
        qDebug() << "Failed to create table";
        qDebug() << query.lastQuery();
        return;
    }
    m_db.close();
}

DataSQL::~DataSQL()
{

}

bool DataSQL::selectDatas(QList<Data>& datas)
{
    if (!m_db.open())
    {
        qDebug() << "Failed to open database :Database";
        return false;
    }
    QSqlQuery query;
    QString sql = "Select * from tb_sleep;";//tb_sleep 这个是表格名字
    if (!query.exec(sql))
    {
        qDebug() << "Failed to select tb_sleep";//tb_sleep 这个是表格名字
        return false;
    }


    while (query.next())
    {
        Data Data;
        int id = query.value("id").toInt();
        QString name = query.value("name").toString();
        int sleepTime = query.value("sleepTime").toInt();

        //放入链表里
        Data.setData(id, name, sleepTime);
        datas.append(Data);
    }



    m_db.close();

    return true;
}

﻿#pragma once

#include <qstring.h>
#include <qsqldatabase.h>//属性管理器/   Qt project settings/   勾选sql
#include <QSqlQuery>

#include "Data.h"

class DataSQL
{
private:

    QSqlDatabase m_db;  //数据库连接


public:
    DataSQL();
    ~DataSQL();
    bool selectDatas(QList<Data> & datas);//读取数据库，获取数据返回到Qlist里
};


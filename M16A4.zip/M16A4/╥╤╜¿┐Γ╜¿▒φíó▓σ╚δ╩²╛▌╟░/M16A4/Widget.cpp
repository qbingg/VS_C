﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent, Qt::WindowStaysOnTopHint)
{
    ui.setupUi(this);

    connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);


    m_DataSQL = new DataSQL;//
    connect(ui.btnAdd, &QPushButton::clicked, this, &Widget::slot_btnAdd);
    showDatas();//初始化程序时，读取一次数据
}

Widget::~Widget()
{}

void Widget::getfireTime(int& fireTime)
{
    m_fireTime = &fireTime;

    ui.spinBox->setValue(*m_fireTime);
}

void Widget::showDatas()
{
    //实例化model
    m_standardModel = new QStandardItemModel(this);

    //查询数据
    QList<Data> datas;
    bool res = m_DataSQL->selectDatas(datas);
    if (!res)
    {
        QMessageBox::information(this, "提示", "查询信息失败");
        return;
    }
    qDebug() << datas.size();

    for (int i = 0; i < datas.size(); ++i)
    {
        appendToModel(datas[i]);
    }
    //添加表头tianjiabiaotou
    QStringList heardList;
    heardList << "id" << "枪名" << "开火间隔" ;
    m_standardModel->setHorizontalHeaderLabels(heardList);

    //隐藏垂直表头yincang chuizhibiaotou
    ui.tableView->verticalHeader()->setVisible(false);

    ui.tableView->setModel(m_standardModel);
}

bool Widget::appendToModel(Data& data)
{
    QStandardItem* itemId = new QStandardItem(data.id());
    QStandardItem* itemName = new QStandardItem(data.name());
    QStandardItem* itemSleepTime = new QStandardItem(data.sleepTime());

    QList<QStandardItem*> rowItem;
    rowItem.append(itemId);
    rowItem.append(itemName);
    rowItem.append(itemSleepTime);

    m_standardModel->appendRow(rowItem);

    return true;
}

bool Widget::slot_pushButton(bool checked)
{
    *m_fireTime = ui.spinBox->value();

    return false;
}

bool Widget::slot_btnAdd(bool checked)
{
    //bool res = m_dataSource->addPeoInfo(peoInfo);
    //if (!res)
    //{
    //    QMessageBox::information(this, "提示", "插入失败!");
    //    return false;
    //}
    //appendToModel(peoInfo);
    return true;
}

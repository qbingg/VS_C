﻿#pragma once

//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\SEenvironment\OpenCV\opencv\build\include
//                      C:\opencv\opencv\build\include\opencv2
// 4.库目录 C:\opencv\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
#include <opencv2/opencv.hpp>
#include <Windows.h>
#include <filesystem>
#include <fstream>
namespace fs = std::filesystem;

#define JUMP 32 //跳跃
#define ESC 27 //退出键盘

//开始
bool startCycle = false;
//存档编号，起始为1
int saveNumber = 1;
cv::Mat image;

//在（x,y）处触发一次鼠标左键点击
void SendMouseClick(int x, int y) {
    INPUT input[2] = { 0 };
    MOUSEINPUT mi = { 0 };

    // 设置鼠标位置
    SetCursorPos(x, y);

    Sleep(500);

    // 按下鼠标左键
    //mi.type = INPUT_MOUSE;
    mi.dx = 0; // 相对移动，这里设置为0
    mi.dy = 0; // 相对移动，这里设置为0
    mi.mouseData = 0; // 通常设置为0，对于左键点击不需要特殊值
    mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    input[0].mi = mi;

    // 释放鼠标左键
    mi.dwFlags = MOUSEEVENTF_LEFTUP;
    input[1].mi = mi;

    // 发送输入事件
    SendInput(2, input, sizeof(INPUT));
}

//单人游戏
int Singleplayer_x;
int Singleplayer_y;

//选择存档
int SelectWorld_x;
int SelectWorld_y;

//安全模式
int SafeMode_x;
int SafeMode_y;

//重生
int Respawn_x;
int Respawn_y;

//截图
int screen_x1;
int screen_y1;
int screen_x2;
int screen_y2;

//保存并退出标题
int SaveAndQuitToTitle_x;
int SaveAndQuitToTitle_y;

std::string copy_save;
std::string play_save;
//std::string backup_save;


//函数：复制存档(备份存档，要替换的地址)
void copy_files(const fs::path& source_dir, const fs::path& target_dir) {
    if (!fs::exists(target_dir)) {
        fs::create_directories(target_dir);
    }

    for (const auto& entry : fs::directory_iterator(source_dir)) {
        const auto& source_path = entry.path();
        const auto& target_path = target_dir / source_path.filename();

        if (fs::is_regular_file(source_path)) {
            try {
                fs::copy_file(source_path, target_path, fs::copy_options::overwrite_existing);
                std::cout << "Copied " << source_path << " to " << target_path << std::endl;
            }
            catch (const fs::filesystem_error& e) {
                std::cerr << "Error copying file: " << e.what() << std::endl;
            }
        }
        else if (fs::is_directory(source_path)) {
            // If you need to copy subdirectories recursively, uncomment the following lines:
            copy_files(source_path, target_path);
        }
    }
}
void copy_files(std::string str_source_dir, std::string str_target_dir) {

    const fs::path& source_dir = str_source_dir;
    const fs::path& target_dir = str_target_dir;

    if (!fs::exists(target_dir)) {
        fs::create_directories(target_dir);
    }

    for (const auto& entry : fs::directory_iterator(source_dir)) {
        const auto& source_path = entry.path();
        const auto& target_path = target_dir / source_path.filename();

        if (fs::is_regular_file(source_path)) {
            try {
                fs::copy_file(source_path, target_path, fs::copy_options::overwrite_existing);
                //std::cout << "Copied " << source_path << " to " << target_path << std::endl;
            }
            catch (const fs::filesystem_error& e) {
                //std::cerr << "Error copying file: " << e.what() << std::endl;
            }
        }
        else if (fs::is_directory(source_path)) {
            // If you need to copy subdirectories recursively, uncomment the following lines:
            copy_files(source_path, target_path);
        }
    }
}


//截取指定区域灰度图像函数
void function_screen(int x1, int y1, int x2, int y2)
{
    //全屏截图方式：指定区域截图
    if (1)
    {
        // 获取屏幕设备的上下文  
        HDC hScreenDC = GetDC(NULL);
        // 计算截图区域的宽度和高度  
            // 获取屏幕的宽度和高度  
        //int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        //int screenHeight = GetSystemMetrics(SM_CYSCREEN);
        //int x1 = 0, y1 = 0;
        //int x2 = screenWidth;
        //int y2 = screenHeight;


        int width = x2 - x1;
        int height = y2 - y1;

        // 创建一个与屏幕设备上下文兼容的内存设备上下文  
        HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

        // 创建一个与屏幕兼容的位图，用于存储截图数据  
        HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

        // 将位图选入内存设备上下文  
        HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

        // 将指定区域的屏幕内容拷贝到位图上  
        BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

        // 创建OpenCV Mat来存储图像数据  
        cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth  

        // 锁定位图的像素区域以便访问  
        BITMAPINFOHEADER bi;
        bi.biSize = sizeof(BITMAPINFOHEADER);
        bi.biWidth = width;
        bi.biHeight = -height; // Negative height for top-down DIB  
        bi.biPlanes = 1;
        bi.biBitCount = 32;
        bi.biCompression = BI_RGB;
        bi.biSizeImage = 0;
        bi.biXPelsPerMeter = 0;
        bi.biYPelsPerMeter = 0;
        bi.biClrUsed = 0;
        bi.biClrImportant = 0;

        // 获取位图的像素数据，并将其存储在OpenCV Mat中  
        GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

        // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道  
        cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

        //// 将图像转换为灰度图像  
        //cv::Mat grayScreenshot;
        //cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

        // 清理资源  
        SelectObject(hMemoryDC, hOldBitmap);
        DeleteObject(hBitmap);
        DeleteDC(hMemoryDC);
        ReleaseDC(NULL, hScreenDC);


        image = screenshot;

        //cv::imshow("", grayScreenshot);
        //cv::waitKey(0);
        //cv::namedWindow("screen_resolutionPreview", cv::WINDOW_FREERATIO);//opencv这里使用中文窗口名字，中文会乱码
        //cv::imshow("screen_resolutionPreview", image);
        //cv::waitKey(0);

        ////
        //std::string file = "res/" + saveNumber;
        //std::string filename = file + ".png";
        //cv::imwrite(filename, image);

        return;
    }


}

//如果文件夹不存在，则创建文件夹
void function_directoryCreate(std::string directory)
{
    fs::path dir = directory;
    //1. 检查文件夹是否存在，如果不存在则创建  
    if (!fs::exists(dir))
    {
        fs::create_directories(dir);
    }
}


﻿#include "Menu.h"

Menu::Menu(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBoxstartCycle, &QCheckBox::stateChanged, this, &Menu::slot_checkBoxstartCycle);
}

Menu::~Menu()
{}

void Menu::getData(int& Singleplayer_x, int& Singleplayer_y, int& SelectWorld_x, int& SelectWorld_y, int& SafeMode_x, int& SafeMode_y, int& Respawn_x, int& Respawn_y, int& screen_x1, int& screen_y1, int& screen_x2, int& screen_y2, int& SaveAndQuitToTitle_x, int& SaveAndQuitToTitle_y, std::string & copy_save, std::string & play_save, bool& startCycle)
{
    //单人游戏
    m_Singleplayer_x = &Singleplayer_x;
    m_Singleplayer_y = &Singleplayer_y;

    //选择存档
    m_SelectWorld_x = &SelectWorld_x;
    m_SelectWorld_y = &SelectWorld_y;

    //安全模式
    m_SafeMode_x = &SafeMode_x;
    m_SafeMode_y = &SafeMode_y;

    //重生
    m_Respawn_x = &Respawn_x;
    m_Respawn_y = &Respawn_y;

    //截图
    m_screen_x1 = &screen_x1;
    m_screen_y1 = &screen_y1;
    m_screen_x2 = &screen_x2;
    m_screen_y2 = &screen_y2;

    //保存并退出标题
    m_SaveAndQuitToTitle_x = &SaveAndQuitToTitle_x;
    m_SaveAndQuitToTitle_y = &SaveAndQuitToTitle_y;

    m_copy_save = &copy_save;
    m_play_save = &play_save;

    //开始
    m_startCycle = &startCycle;

    





    //默认赋值（2560x1440，mc窗口在左上角）
    // 
    //单人游戏
    ui.Singleplayer_x->setValue(423);
    ui.Singleplayer_y->setValue(272);
    //选择存档
    ui.SelectWorld_x->setValue(195);
    ui.SelectWorld_y->setValue(170);
    //安全模式
    ui.SafeMode_x->setValue(270);
    ui.SafeMode_y->setValue(320);
    //重生
    ui.Respawn_x->setValue(425);
    ui.Respawn_y->setValue(320);
    //截图
    ui.screen_x1->setValue(0);
    ui.screen_y1->setValue(0);
    ui.screen_x2->setValue(854);
    ui.screen_y2->setValue(510);
    //保存并退出标题
    ui.SaveAndQuitToTitle_x->setValue(435);
    ui.SaveAndQuitToTitle_y->setValue(384);

}

bool Menu::slot_checkBoxstartCycle(bool checked)
{
    if (ui.checkBoxstartCycle->isChecked())
    {
        //单人游戏
        *m_Singleplayer_x = ui.Singleplayer_x->value();
        *m_Singleplayer_y = ui.Singleplayer_y->value();

        //选择存档
        *m_SelectWorld_x = ui.SelectWorld_x->value();
        *m_SelectWorld_y = ui.SelectWorld_y->value();

        //安全模式
        *m_SafeMode_x = ui.SafeMode_x->value();
        *m_SafeMode_y = ui.SafeMode_y->value();

        //重生
        *m_Respawn_x = ui.Respawn_x->value();
        *m_Respawn_y = ui.Respawn_y->value();

        //截图
        *m_screen_x1 = ui.screen_x1->value();
        *m_screen_y1 = ui.screen_y1->value();
        *m_screen_x2 = ui.screen_x2->value();
        *m_screen_y2 = ui.screen_y2->value();

        //保存并退出标题
        *m_SaveAndQuitToTitle_x = ui.SaveAndQuitToTitle_x->value();
        *m_SaveAndQuitToTitle_y = ui.SaveAndQuitToTitle_y->value();

        *m_copy_save = ui.copy_save->text().toStdString();
        *m_play_save = ui.play_save->text().toStdString();

        Sleep(5000);//勾上选择框，5秒后启动

        *m_startCycle = true;
    }
    else
    {
        *m_startCycle = false;
    }

    return false;
}

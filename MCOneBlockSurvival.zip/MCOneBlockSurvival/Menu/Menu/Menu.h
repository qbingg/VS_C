﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Menu.h"
#include<Windows.h>

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();

private:
    Ui::MenuClass ui;

private:
    //单人游戏
    int* m_Singleplayer_x;
    int* m_Singleplayer_y;

    //选择存档
    int* m_SelectWorld_x;
    int* m_SelectWorld_y;

    //安全模式
    int* m_SafeMode_x;
    int* m_SafeMode_y;

    //重生
    int* m_Respawn_x;
    int* m_Respawn_y;

    //截图
    int* m_screen_x1;
    int* m_screen_y1;
    int* m_screen_x2;
    int* m_screen_y2;

    //保存并退出标题
    int* m_SaveAndQuitToTitle_x;
    int* m_SaveAndQuitToTitle_y;

    std::string* m_copy_save;
    std::string* m_play_save;

    //开始
    bool* m_startCycle;

public:
    void getData
    (
        //单人游戏
        int& Singleplayer_x,
        int& Singleplayer_y,

        //选择存档
        int& SelectWorld_x,
        int& SelectWorld_y,

        //安全模式
        int& SafeMode_x,
        int& SafeMode_y,

        //重生
        int& Respawn_x,
        int& Respawn_y,

        //截图
        int& screen_x1,
        int& screen_y1,
        int& screen_x2,
        int& screen_y2,

        //保存并退出标题
        int& SaveAndQuitToTitle_x,
        int& SaveAndQuitToTitle_y,

        std::string& copy_save,
        std::string& play_save,

        bool& startCycle
    );
private slots:
    bool slot_checkBoxstartCycle(bool checked);
};

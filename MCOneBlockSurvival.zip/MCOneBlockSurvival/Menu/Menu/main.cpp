﻿#include "Menu.h"
#include <QtWidgets/QApplication>
#include <Define.h>
#include <thread>
void function_cycle()
{
#define S Sleep(500);
    while (true)
    {
        while (startCycle)
        {
            //复制存档到游戏中
            copy_files(copy_save, play_save);
            S

            //点击“单人游戏”
            SendMouseClick(Singleplayer_x, Singleplayer_y);
            S S
                
            //点击“选择存档”
            SendMouseClick(SelectWorld_x, SelectWorld_y);
            S S

            //点击“安全模式”
            SendMouseClick(SafeMode_x, SafeMode_y); 

            //掉入虚空等待重生按钮出现......
            Sleep(5000);

            //点击“重生”
            SendMouseClick(Respawn_x, Respawn_y);
            Sleep(350);

            //截图命名编号并保存
            function_screen(screen_x1, screen_y1, screen_x2, screen_y2);
            Sleep(150);

            //ESC
            keybd_event(ESC, 0, 0, 0);
            Sleep(100);
            keybd_event(ESC, 0, KEYEVENTF_KEYUP, 0);
            Sleep(100);

            //点击“保存并退出标题”
            SendMouseClick(SaveAndQuitToTitle_x, SaveAndQuitToTitle_y);
            S S 
                
            //保留存档，并命名编号
            QString Number = QString::number(saveNumber);
            std::string saveTo = "res/" + Number.toStdString() + "/One Block Survival";
            function_directoryCreate(saveTo);
            copy_files(play_save, saveTo);
            //保存图片
            std::string file = "res/" + Number.toStdString()+".png";
            cv::imwrite(file, image);
            //保存图片-负片
            cv::Mat imageNegative;
            cv::subtract(cv::Scalar(255, 255, 255), image, imageNegative);// 将图像转为负片  
            std::string fileNegative = "res/Negative/" + Number.toStdString() + ".png";
            cv::imwrite(fileNegative, imageNegative);

            saveNumber++;
        }
        Sleep(1000);
    }
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    function_directoryCreate("res");
    function_directoryCreate("res/Negative");
    std::thread thread1(function_cycle);
    Menu w;
    w.getData
    (
        //单人游戏
        Singleplayer_x,
        Singleplayer_y,

        //选择存档
        SelectWorld_x,
        SelectWorld_y,

        //安全模式
        SafeMode_x,
        SafeMode_y,

        //重生
        Respawn_x,
        Respawn_y,

        //截图
        screen_x1,
        screen_y1,
        screen_x2,
        screen_y2,

        //保存并退出标题
        SaveAndQuitToTitle_x,
        SaveAndQuitToTitle_y,

        copy_save,
        play_save,
        startCycle
    );
    w.show();
    return a.exec();
}

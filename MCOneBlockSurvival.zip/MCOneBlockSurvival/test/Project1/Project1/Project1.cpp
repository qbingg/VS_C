﻿

#include <iostream>
#include <Windows.h>

#define JUMP 32 //跳跃
#define ESC 27 //退出键盘
//#define  //
//#define  //

// 辅助函数，用于创建一个 KEYBDINPUT 结构
void SendKey(WORD vkCode, BOOL bKeyDown) {
    KEYBDINPUT kb = { 0 };
    INPUT input = { 0 };

    kb.wVk = vkCode;
    kb.wScan = 0; // 如果指定了虚拟键码，则此字段通常为0
    kb.dwFlags = bKeyDown ? 0 : KEYEVENTF_KEYUP;
    kb.time = 0; // 0表示使用当前时间戳
    kb.dwExtraInfo = 0; // 通常设置为0

    input.type = INPUT_KEYBOARD;
    input.ki = kb;

    // 发送输入事件
    SendInput(1, &input, sizeof(INPUT));
}

// 辅助函数，用于创建一个 MOUSEINPUT 结构
void SendMouseClick(int x, int y) {
    INPUT input[2] = { 0 };
    MOUSEINPUT mi = { 0 };

    // 设置鼠标位置
    SetCursorPos(x, y);

    // 按下鼠标左键
    //mi.type = INPUT_MOUSE;
    mi.dx = 0; // 相对移动，这里设置为0
    mi.dy = 0; // 相对移动，这里设置为0
    mi.mouseData = 0; // 通常设置为0，对于左键点击不需要特殊值
    mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    input[0].mi = mi;

    // 释放鼠标左键
    mi.dwFlags = MOUSEEVENTF_LEFTUP;
    input[1].mi = mi;

    // 发送输入事件
    SendInput(2, input, sizeof(INPUT));
}

int main()
{
    std::cout << "Hello World!\n";

    //while (true)
    //{
    //    keybd_event(ESC, 0, 0, 0);
    //    Sleep(100);
    //    keybd_event(ESC, 0, KEYEVENTF_KEYUP, 0);
    //
    //    Sleep(2000);
    //}

    //检测鼠标位置，注意受窗口缩放倍率影响
    POINT cursorPos; // 定义一个POINT结构体来存储鼠标坐标  
    while (true)
    {
        // 调用GetCursorPos函数，将鼠标坐标存储在cursorPos中  
        if (GetCursorPos(&cursorPos)) {
            // 如果调用成功  
            std::cout << "鼠标当前坐标：(" << cursorPos.x << ", " << cursorPos.y << ")" << std::endl;
        }
        else {
            // 如果调用失败  
            std::cerr << "获取鼠标坐标失败！" << std::endl;
        }
        Sleep(200);
        system("cls");//清除屏幕
    }

    //// 将鼠标移动到指定位置,也受窗口缩放倍率影响！！！
    //POINT currentPosition;// 获取当前鼠标位置
    //GetCursorPos(&currentPosition);
    ////std::cout << "当前鼠标位置：(" << currentPosition.x << ", " << currentPosition.y << ")" << std::endl;
    //int targetX = 800;   // 目标 x 坐标
    //int targetY = 0;   // 目标 y 坐标
    //SetCursorPos(targetX, targetY);   // 将鼠标移动到指定位置

    Sleep(5000);
    //点击单人游戏
    POINT currentPosition;// 获取当前鼠标位置
    GetCursorPos(&currentPosition);
    //SetCursorPos(1474, 312);   // 将鼠标移动到指定位置
    //keybd_event(VK_LBUTTON, 0, 0, 0);
    //Sleep(1000);
    //keybd_event(VK_LBUTTON, 0, KEYEVENTF_KEYUP, 0);
    
    //// 模拟按下 Num Lock
    //SendKey(VK_LBUTTON, TRUE);
    //// 为了确保系统有足够的时间处理按下事件，可以添加一个小延迟
    //// 注意：这个延迟不是必需的，但在某些情况下可能是有用的
    //Sleep(50); // 50毫秒延迟
    //// 模拟释放 Num Lock
    //SendKey(VK_LBUTTON, FALSE);

    SendMouseClick(950, 600);






    //Sleep(100);
    ////点击地图
    //SetCursorPos(666, 363);   // 将鼠标移动到指定位置
    //keybd_event(VK_LBUTTON, 0, 0, 0);
    //Sleep(100);
    //keybd_event(VK_LBUTTON, 0, KEYEVENTF_KEYUP, 0);

    //Sleep(3000);
    ////ESC点击
    //keybd_event(ESC, 0, 0, 0);
    //Sleep(100);
    //keybd_event(ESC, 0, KEYEVENTF_KEYUP, 0);

    //Sleep(100);
    ////返回标题
    //SetCursorPos(900, 590);   // 将鼠标移动到指定位置
    //keybd_event(VK_LBUTTON, 0, 0, 0);
    //Sleep(100);
    //keybd_event(VK_LBUTTON, 0, KEYEVENTF_KEYUP, 0);
}



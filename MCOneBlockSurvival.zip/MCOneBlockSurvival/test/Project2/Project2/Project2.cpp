﻿#include <iostream>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;

void copy_files(const fs::path& source_dir, const fs::path& target_dir) {
    if (!fs::exists(target_dir)) {
        fs::create_directories(target_dir);
    }

    for (const auto& entry : fs::directory_iterator(source_dir)) {
        const auto& source_path = entry.path();
        const auto& target_path = target_dir / source_path.filename();

        if (fs::is_regular_file(source_path)) {
            try {
                fs::copy_file(source_path, target_path, fs::copy_options::overwrite_existing);
                std::cout << "Copied " << source_path << " to " << target_path << std::endl;
            }
            catch (const fs::filesystem_error& e) {
                std::cerr << "Error copying file: " << e.what() << std::endl;
            }
        }
        else if (fs::is_directory(source_path)) {
            // If you need to copy subdirectories recursively, uncomment the following lines:
            copy_files(source_path, target_path);
        }
    }
}

int main() {
    fs::path source_dir = u8"D:\\LaJiRuanJian\\MC\\copy\\test2";
    fs::path target_dir = u8"D:\\LaJiRuanJian\\MC\\.minecraft\\saves\\test2";

    copy_files(source_dir, target_dir);

    return 0;
}
﻿//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\Softwares\SEenvironment\opencv\build\include
//                      D:\Softwares\SEenvironment\opencv\build\include\opencv2
// 4.库目录 D:\Softwares\SEenvironment\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;

//图像检测函数
double function_matchTemplate(cv::Mat& src, cv::Mat& templ)//截图，模板图
{

    //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
    if ((src.cols == 0) || (templ.cols == 0) || (src.cols < templ.cols))
    {
        // 这是程序会崩溃的情况：

        //截图为空，返回-1值
        //模板图为空，返回-1值
        //截图小于模板图，返回-1值
        return 0;
    }

    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点
    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(src, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("src", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("src", src);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/

    return dMaxVal;
}

int main()
{
    Mat templ = imread("Colorful/templ.png", 0);
    //Mat templ = imread("Negative/templ.png", 0);

	int number=1;

	while (true)
	{
		Mat src = imread(("Colorful/" + std::to_string(number) + ".png"), 0);
		//Mat src = imread(("Negative/" + std::to_string(number) + ".png"), 0);
		if (src.empty())
		{
			break;
		}

        double n = function_matchTemplate(src, templ);

        if (n <1)
        {
        cout << number << ": \t" << n << endl;

        }


        number++;
	}
    waitKey(0);
    system("pause");
}



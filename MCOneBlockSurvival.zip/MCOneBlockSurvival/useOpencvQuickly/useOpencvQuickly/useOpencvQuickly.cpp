﻿// 使用opencv图像检测精准点击鼠标事件
//
// 用于快速开发，最快速地投入到mc里使用的脚本
//
// 不使用QT，所有数据都事先编译在程序里
//
//

//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\Softwares\SEenvironment\opencv\build\include
//                      D:\Softwares\SEenvironment\opencv\build\include\opencv2
// 4.库目录 D:\Softwares\SEenvironment\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
#include <opencv2/opencv.hpp>
#include <iostream>
#include <Windows.h>
#include <filesystem>
#include <fstream>
namespace fs = std::filesystem;
#define ESC 27 //退出键盘

// 变量声明

//单人游戏
int Singleplayer_x1=348;
int Singleplayer_y1=247;
int Singleplayer_x2=506;
int Singleplayer_y2=286;
cv::Mat Singleplayer=cv::imread("opencvImg/Singleplayer.png",0);

//选择存档
int SelectWorld_x1=150;
int SelectWorld_y1=120;
int SelectWorld_x2=232;
int SelectWorld_y2=207;
cv::Mat SelectWorld = cv::imread("opencvImg/SelectWorld.png", 0);

//安全模式
int SafeMode_x1=198;
int SafeMode_y1=294;
int SafeMode_x2=338;
int SafeMode_y2=350;
cv::Mat SafeMode = cv::imread("opencvImg/SafeMode.png", 0);

//重生
int Respawn_x1=366;
int Respawn_y1=281;
int Respawn_x2=496;
int Respawn_y2=335;
cv::Mat Respawn = cv::imread("opencvImg/Respawn.png", 0);

//截图
int screen_x1=0;
int screen_y1=0;
int screen_x2=854;
int screen_y2=510;

//保存并退出标题
int SaveAndQuitToTitle_x1=407;
int SaveAndQuitToTitle_y1=353;
int SaveAndQuitToTitle_x2=463;
int SaveAndQuitToTitle_y2=402;
cv::Mat SaveAndQuitToTitle = cv::imread("opencvImg/SaveAndQuitToTitle.png", 0);

std::string copy_save="Z:\\MC\\One Block Survival";//复制地址
std::string stickup_save="Z:\\MC\\.minecraft\\saves\\One Block Survival";//粘贴地址

//在（x,y）处触发一次鼠标左键点击 （sleepTime为移动至按下的等待时间，默认500ms）
void SendMouseClick(int x, int y, int sleepTime = 500)
{
    INPUT input[2] = { 0 };
    MOUSEINPUT mi = { 0 };

    // 设置鼠标位置
    SetCursorPos(x, y);

    Sleep(sleepTime);

    // 按下鼠标左键
    //mi.type = INPUT_MOUSE;
    mi.dx = 0; // 相对移动，这里设置为0
    mi.dy = 0; // 相对移动，这里设置为0
    mi.mouseData = 0; // 通常设置为0，对于左键点击不需要特殊值
    mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    input[0].mi = mi;

    // 释放鼠标左键
    mi.dwFlags = MOUSEEVENTF_LEFTUP;
    input[1].mi = mi;

    // 发送输入事件
    SendInput(2, input, sizeof(INPUT));
}

//截取全屏灰度图像函数
cv::Mat function_screenGray(int x1, int y1, int x2, int y2)
{
    //截图
    // 获取屏幕设备的上下文  
    HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度  
    int width = x2 - x1;
    int height = y2 - y1;

    // 创建一个与屏幕设备上下文兼容的内存设备上下文  
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据  
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文  
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上  
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据  
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth  

    // 锁定位图的像素区域以便访问  
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB  
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中  
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道  
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像  
    cv::Mat grayScreenshot;
    cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源  
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    //cv::namedWindow("hist", cv::WINDOW_FREERATIO);
    //cv::imshow("hist", grayScreenshot);

    return grayScreenshot;
}

//图像检测函数，返回中心坐标 (截图，模板图，n值 ,截图左上角)  point= -1 时请弃用
cv::Point function_matchTemplate(cv::Mat& src, cv::Mat& templ,double n,int x1,int y1)//截图，模板图，n值
{

    //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
    cv::Point pFault(-1, -1);
    if ((src.cols == 0) || (templ.cols == 0) || (src.cols < templ.cols))
    {
        // 这是程序会崩溃的情况：

        //截图为空，返回-1值
        //模板图为空，返回-1值
        //截图小于模板图，返回-1值
        return pFault;
    }

    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点
    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(src, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("src", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("src", src);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    std::cout<< dMaxVal<<std::endl;

    cv::Point p(x1 + ptMaxLoc.x + (templ.cols) / 2, y1 + ptMaxLoc.y + (templ.rows) / 2);

    //// 在图像上画点
    //cv::circle(src, p, 5, cv::Scalar(0, 255, 0), -1, cv::LINE_AA); // -1表示填充圆形，cv::LINE_AA表示抗锯齿
    //namedWindow("src", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("src", src);


    if (dMaxVal > n)
    {
        return p;
    }
    else
    {
        return pFault;
    }

}

//图像检测区域，在区域中心按下左键，鼠标移动后等待时间
bool function_click
(
    int x1,
    int y1,
    int x2,
    int y2,
    cv::Mat templ,
    int sleepTime = 500
)
{
    cv::Mat srcGray = function_screenGray(x1, y1, x2, y2);

    cv::Point p = function_matchTemplate(srcGray, templ, 0.8 ,x1 , y1);

    if (p.x != -1)
    {
        SendMouseClick(p.x, p.y, sleepTime);

        return true;
    }
    else
    {
        return false;
    }
}

//图像检测函数
double function_matchTemplate(cv::Mat& src, cv::Mat& templ)//截图，模板图
{

    //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
    if ((src.cols == 0) || (templ.cols == 0) || (src.cols < templ.cols))
    {
        // 这是程序会崩溃的情况：

        //截图为空，返回-1值
        //模板图为空，返回-1值
        //截图小于模板图，返回-1值
        return 0;
    }

    cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
    matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

    double dMaxVal; //分数最大值
    cv::Point ptMaxLoc; //最大值坐标
    minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

    //匹配结果的四个顶点
    //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
    //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
    //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
    //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

    //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
    //line(src, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
    //line(src, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

    //cv::namedWindow("src", cv::WindowFlags::WINDOW_FREERATIO);
    //imshow("src", src);
    //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


    //cv::imshow("image", src);
    //cv::waitKey(0);


    /*std::cout<< dMaxVal<<std::endl;*/

    return dMaxVal;
}


//函数：复制存档(备份存档，要替换的地址)
void copy_files(const fs::path& source_dir, const fs::path& target_dir) {
    if (!fs::exists(target_dir)) {
        fs::create_directories(target_dir);
    }

    for (const auto& entry : fs::directory_iterator(source_dir)) {
        const auto& source_path = entry.path();
        const auto& target_path = target_dir / source_path.filename();

        if (fs::is_regular_file(source_path)) {
            try {
                fs::copy_file(source_path, target_path, fs::copy_options::overwrite_existing);
                std::cout << "Copied " << source_path << " to " << target_path << std::endl;
            }
            catch (const fs::filesystem_error& e) {
                std::cerr << "Error copying file: " << e.what() << std::endl;
            }
        }
        else if (fs::is_directory(source_path)) {
            // If you need to copy subdirectories recursively, uncomment the following lines:
            copy_files(source_path, target_path);
        }
    }
}
void copy_files(std::string str_source_dir, std::string str_target_dir) {

    const fs::path& source_dir = str_source_dir;
    const fs::path& target_dir = str_target_dir;

    if (!fs::exists(target_dir)) {
        fs::create_directories(target_dir);
    }

    for (const auto& entry : fs::directory_iterator(source_dir)) {
        const auto& source_path = entry.path();
        const auto& target_path = target_dir / source_path.filename();

        if (fs::is_regular_file(source_path)) {
            try {
                fs::copy_file(source_path, target_path, fs::copy_options::overwrite_existing);
                //std::cout << "Copied " << source_path << " to " << target_path << std::endl;
            }
            catch (const fs::filesystem_error& e) {
                //std::cerr << "Error copying file: " << e.what() << std::endl;
            }
        }
        else if (fs::is_directory(source_path)) {
            // If you need to copy subdirectories recursively, uncomment the following lines:
            copy_files(source_path, target_path);
        }
    }
}
//如果文件夹不存在，则创建文件夹
void function_directoryCreate(std::string directory)
{
    fs::path dir = directory;
    //1. 检查文件夹是否存在，如果不存在则创建  
    if (!fs::exists(dir))
    {
        fs::create_directories(dir);
    }
}
//截取指定区域灰度图像函数
cv::Mat image;
void function_screen(int x1, int y1, int x2, int y2)
{
    //全屏截图方式：指定区域截图
    if (1)
    {
        // 获取屏幕设备的上下文  
        HDC hScreenDC = GetDC(NULL);
        // 计算截图区域的宽度和高度  
            // 获取屏幕的宽度和高度  
        //int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        //int screenHeight = GetSystemMetrics(SM_CYSCREEN);
        //int x1 = 0, y1 = 0;
        //int x2 = screenWidth;
        //int y2 = screenHeight;


        int width = x2 - x1;
        int height = y2 - y1;

        // 创建一个与屏幕设备上下文兼容的内存设备上下文  
        HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

        // 创建一个与屏幕兼容的位图，用于存储截图数据  
        HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

        // 将位图选入内存设备上下文  
        HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

        // 将指定区域的屏幕内容拷贝到位图上  
        BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

        // 创建OpenCV Mat来存储图像数据  
        cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth  

        // 锁定位图的像素区域以便访问  
        BITMAPINFOHEADER bi;
        bi.biSize = sizeof(BITMAPINFOHEADER);
        bi.biWidth = width;
        bi.biHeight = -height; // Negative height for top-down DIB  
        bi.biPlanes = 1;
        bi.biBitCount = 32;
        bi.biCompression = BI_RGB;
        bi.biSizeImage = 0;
        bi.biXPelsPerMeter = 0;
        bi.biYPelsPerMeter = 0;
        bi.biClrUsed = 0;
        bi.biClrImportant = 0;

        // 获取位图的像素数据，并将其存储在OpenCV Mat中  
        GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

        // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道  
        cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

        //// 将图像转换为灰度图像  
        //cv::Mat grayScreenshot;
        //cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

        // 清理资源  
        SelectObject(hMemoryDC, hOldBitmap);
        DeleteObject(hBitmap);
        DeleteDC(hMemoryDC);
        ReleaseDC(NULL, hScreenDC);


        image = screenshot;

        //cv::imshow("", grayScreenshot);
        //cv::waitKey(0);
        //cv::namedWindow("screen_resolutionPreview", cv::WINDOW_FREERATIO);//opencv这里使用中文窗口名字，中文会乱码
        //cv::imshow("screen_resolutionPreview", image);
        //cv::waitKey(0);

        ////
        //std::string file = "res/" + saveNumber;
        //std::string filename = file + ".png";
        //cv::imwrite(filename, image);

        return;
    }


}


cv::Mat templ = cv::imread("templ.png", 0);


int main()
{
    //存档编号，起始为1
    int saveNumber = 0;//第0次不用保存存档

    bool beginning = true;//启动程序时，第一次执行

    //读
    std::ifstream readFile("saveNumberCount.txt"); // 打开文件//M16_SleepTime.txt是否存在
    if (readFile.is_open()) //检查文件是否成功打开 
    {
        //存在，读取// 从文件中读取整数  
        readFile >> saveNumber;
        readFile.close(); // 关闭文件  


        std::cout << "获取上一次运行保存的计数：" << saveNumber << std::endl;;

    }

    std::cout << "十秒后开始\n";

    Sleep(10000);

    std::cout << "开始\n";

    //function_click(0, 0, 3200, 2000, Respawn, 0);//截图区域不受窗口缩放倍率影响

    //cv::Mat src = cv::imread("C:\\Users\\lwm\\Desktop\\src.png", 0);

    //cv::Mat templ = cv::imread("C:\\Users\\lwm\\Desktop\\templ.png", 0);

    //cv::Point p = function_matchTemplate( src,templ,0);

    //std::cout << p.x<<std::endl<<p.y;


    function_directoryCreate("res");
    function_directoryCreate("res/Colorful"); 
    function_directoryCreate("res/Negative");
    function_directoryCreate("opencvImg");

    while (true)
    {







        //点击“单人游戏”
        while (true)
        {
            bool res = function_click
            (
                Singleplayer_x1,
                Singleplayer_y1,
                Singleplayer_x2,
                Singleplayer_y2,
                Singleplayer
            );
            Sleep(500);

            if (res)
            {
                break;
            }
        }

        if (!beginning)//第一次执行跳过
        {
            ////保留存档，并命名编号
            //std::string saveTo = "res/" + std::to_string(saveNumber) + "/One Block Survival";
            //function_directoryCreate(saveTo);
            //copy_files(stickup_save, saveTo);

            //保存计数
            //写
            std::ofstream writeFile("saveNumberCount.txt"); // 创建或打开文件  
            if (writeFile.is_open()) { // 检查文件是否成功打开  
                writeFile << saveNumber; // 将数字206写入文件  
                writeFile.close(); // 关闭文件  
            }
            
            //保存图片
            std::string file = "res/Colorful/" + std::to_string(saveNumber) + ".png";
            cv::imwrite(file, image);
            //保存图片-负片
            cv::Mat imageNegative;
            cv::subtract(cv::Scalar(255, 255, 255), image, imageNegative);// 将图像转为负片  
            std::string fileNegative = "res/Negative/" + std::to_string(saveNumber) + ".png";
            cv::imwrite(fileNegative, imageNegative);

            //判断存档是否需要保存
            cv::Mat src;
            cv::cvtColor(image, src, cv::COLOR_BGRA2GRAY);
            double n = function_matchTemplate(src, templ);
            if (n < 0.87)
            {
                std::string files = "res/Colorful/s" + std::to_string(saveNumber) + ".png";
                cv::imwrite(files, image);

                //保留存档，并命名编号
                std::string saveTo = "res/" + std::to_string(saveNumber) + "/One Block Survival";
                function_directoryCreate(saveTo);
                copy_files(stickup_save, saveTo);
            }
        }
        else
        {
            beginning = false;
        }

        saveNumber++;

        //复制存档到游戏中
        copy_files(copy_save, stickup_save);
        Sleep(10);

        //点击“选择存档”
        while (true)
        {
            bool res = function_click
            (
                SelectWorld_x1,
                SelectWorld_y1,
                SelectWorld_x2,
                SelectWorld_y2,
                SelectWorld
            );
            Sleep(500);
            if (res)
            {
                break;
            }
        }

        //点击“安全模式”
        while (true)
        {
            bool res = function_click
            (

                SafeMode_x1,
                SafeMode_y1,
                SafeMode_x2,
                SafeMode_y2,
                SafeMode
            );
            Sleep(500);
            if (res)
            {
                break;
            }
        }

        //掉入虚空等待重生按钮出现......
        Sleep(4000);

        //点击“重生”
        while (true)
        {
            bool res = function_click
            (
                Respawn_x1,
                Respawn_y1,
                Respawn_x2,
                Respawn_y2,
                Respawn,
                1500
            );
            Sleep(1);
            if (res)
            {
                break;
            }
        }
        Sleep(310);
        //截图命名编号并保存
        function_screen(screen_x1, screen_y1, screen_x2, screen_y2);
        Sleep(150);

        //ESC
        keybd_event(ESC, 0, 0, 0);
        Sleep(100);
        keybd_event(ESC, 0, KEYEVENTF_KEYUP, 0);
        Sleep(100);

        //点击“保存并退出标题”
        while (true)
        {
            bool res = function_click
            (
                SaveAndQuitToTitle_x1,
                SaveAndQuitToTitle_y1,
                SaveAndQuitToTitle_x2,
                SaveAndQuitToTitle_y2,
                SaveAndQuitToTitle
            );
            Sleep(500);
            if (res)
            {
                break;
            }
        }

        Sleep(1);
    }


    cv::waitKey(0);
}


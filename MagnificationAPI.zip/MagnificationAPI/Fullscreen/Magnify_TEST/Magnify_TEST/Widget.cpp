﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);
}

Widget::~Widget()
{}

void Widget::getMagnify_n(float& Magnify_n)
{
    m_Magnify_n = &Magnify_n;
}

void Widget::getuse_Magnify(bool& use_Magnify)
{
    m_use_Magnify = &use_Magnify;
}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        *m_use_Magnify = true;
    }
    else
    {
        *m_use_Magnify = false;
    }
    return false;
}

bool Widget::slot_pushButton(bool checked)
{
    *m_Magnify_n = ui.doubleSpinBox->value();

    return false;
}
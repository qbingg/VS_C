﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"

#include "VS_C.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    float* m_Magnify_n;
    bool* m_use_Magnify;
public:
    void getMagnify_n(float& Magnify_n);
    void getuse_Magnify(bool& use_Magnify);
private slots:
    bool on_checkBox(bool checked);
    bool slot_pushButton(bool checked);
};

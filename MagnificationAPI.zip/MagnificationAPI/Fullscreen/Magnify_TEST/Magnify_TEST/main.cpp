﻿#include "Widget.h"
#include <QtWidgets/QApplication>

bool Magnify_Click = false;

float Magnify_n = 1;

bool use_Magnify = false;


MAGCOLOREFFECT g_MagEffectIdentity = { 1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
                                      0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
                                      0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
                                      0.0f,  0.0f,  0.0f,  1.0f,  0.0f,
                                      0.0f,  0.0f,  0.0f,  0.0f,  1.0f };

MAGCOLOREFFECT g_MagEffectGrayscale = { 0.3f,  0.3f,  0.3f,  0.0f,  0.0f,
                                       0.6f,  0.6f,  0.6f,  0.0f,  0.0f,
                                       0.1f,  0.1f,  0.1f,  0.0f,  0.0f,
                                       0.0f,  0.0f,  0.0f,  1.0f,  0.0f,
                                       0.0f,  0.0f,  0.0f,  0.0f,  1.0f };

MAGCOLOREFFECT g_MagEffectNegative = {//转置！！！！！！
    -1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Red: output = 1 - input  
    0.0f, -1.0f, 0.0f, 0.0f, 0.0f, // Green: output = 1 - input  
    0.0f, 0.0f, -1.0f, 0.0f, 0.0f, // Blue: output = 1 - input  
    0.5f, 0.5f, 0.5f, 1.0f, 0.0f,  // Alpha 通道通常不变或保持为1  
    0.0f, 0.0f, 0.0f, 0.0f, 1.0f   // 增益和偏移量通常用于调整亮度或对比度，这里不需要  
};





void f_Magnify()
{
    MagInitialize();
    while (true)
    {
        while (use_Magnify)
        {
            if (GET_RB && GET_LSHIFT == 0)
            {
                while (GET_RB)
                {
                    if (GET_LSHIFT)
                    {
                        while (GET_RB)
                        {
                            //确保每次只触发一次命令:启用放大镜
                            if (Magnify_Click == false)
                            {
                                Magnify_Click = true;

                                //获取放大倍数


                                //调用WindowsAPI
                                int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / Magnify_n)) / 2.0);
                                int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / Magnify_n)) / 2.0);
                                yDlg -= 15;//向下偏移量
                                MagSetFullscreenTransform(Magnify_n, xDlg, yDlg);

                                PMAGCOLOREFFECT pEffect = &g_MagEffectNegative;

                                MagSetFullscreenColorEffect(pEffect);




                            }
                            S1
                        }
                        //关闭放大镜
                        if (Magnify_Click == true)
                        {
                            Magnify_Click = false;

                            float reset_n = 1;

                            //调用WindowsAPI
                            int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / reset_n)) / 2.0);
                            int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / reset_n)) / 2.0);

                            MagSetFullscreenTransform(reset_n, xDlg, yDlg);

                            PMAGCOLOREFFECT pEffect = &g_MagEffectIdentity;


                            MagSetFullscreenColorEffect(pEffect);


                        }
                        S1
                    }
                    S1
                }
            }
            S100
        }
        S1000
    }
    MagUninitialize();
}

int main(int argc, char *argv[])
{
    th th_f_Magnify(f_Magnify);
    QApplication a(argc, argv);
    Widget w;
    w.getMagnify_n(Magnify_n);
    w.getuse_Magnify(use_Magnify);
    w.show();
    return a.exec();
}

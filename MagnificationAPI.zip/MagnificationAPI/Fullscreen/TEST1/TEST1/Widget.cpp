﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);
}

Widget::~Widget()
{}

bool Widget::slot_pushButton(bool checked)
{
    MagInitialize();
    //获取放大倍数
    float n = ui.doubleSpinBox->value();

    //调用WindowsAPI
    int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / n)) / 2.0);
    int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / n)) / 2.0);

    BOOL fSuccess = MagSetFullscreenTransform(n, xDlg, yDlg);

    return false;
}
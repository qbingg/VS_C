﻿#include "Widget.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();
    return a.exec();
}
//
//#include <iostream>
//
//#include "windows.h"
//#include "magnification.h"
//using namespace std;

//int main()
//{
//    HWND hWnd;
//    //获取放大倍数
//    float n = 2;
//
//    //调用WindowsAPI
//    int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / n)) / 2.0);
//    int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / n)) / 2.0);
//
//    BOOL fSuccess = MagSetFullscreenTransform(n, xDlg, yDlg);
//
//    system("pause");
//}
//int APIENTRY WinMain(_In_ HINSTANCE hInstance,
//    _In_opt_ HINSTANCE /*hPrevInstance*/,
//    _In_ LPSTR     /*lpCmdLine*/,
//    _In_ int       /*nCmdShow*/)
//{
//        //获取放大倍数
//    float n = 2;
//
//    //调用WindowsAPI
//    int xDlg = (int)((float)GetSystemMetrics(SM_CXSCREEN) * (1.0 - (1.0 / n)) / 2.0);
//    int yDlg = (int)((float)GetSystemMetrics(SM_CYSCREEN) * (1.0 - (1.0 / n)) / 2.0);
//
//    BOOL fSuccess = MagSetFullscreenTransform(n, xDlg, yDlg);
//
//    while (true)
//    {
//        Sleep(1000);
//    }
//}
//HWND hWnd;


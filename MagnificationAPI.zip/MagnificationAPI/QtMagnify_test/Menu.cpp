#include "Menu.h"
#include "ui_Menu.h"

#include <qmessagebox.h>

Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);

    connect(ui->checkBox, &QCheckBox::stateChanged, this, &Menu::on_checkBox);
}

Menu::~Menu()
{
    delete ui;
}

void Menu::on_checkBox(bool checked)
{
    if(ui->checkBox->isChecked())
    {
        MagInitialize();

            //QMessageBox::information(this, "", "STR");
        MagSetFullscreenColorEffect(&g_MagEffectNegative);
    }
    else
    {
        MagUninitialize();
    }

}


void Menu::on_pushButton_clicked()
{
    //PMAGCOLOREFFECT pEffect = &g_MagEffectNegative;

    //虽然是&，但是不会随着变量改变，还是等价于
    MagSetFullscreenColorEffect(&g_MagEffectNegative);

    Sleep(1000);

    // g_MagEffectNegative =   { 1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
    //                                       0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
    //                                       0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
    //                                       0.0f,  0.0f,  0.0f,  1.0f,  0.0f,
    //                                       0.0f,  0.0f,  0.0f,  0.0f,  1.0f };


}


void Menu::on_horizontalSlider_sliderPressed()
{
    //ui->label->setText(QString::number(ui->horizontalSlider->value()));
}


void Menu::on_horizontalSlider_actionTriggered(int action)
{
    //ui->label->setText(QString::number(action));
}


void Menu::on_horizontalSlider_valueChanged(int value)
{
    //ui->label->setText(QString::number(value));
}


void Menu::on_horizontalSlider_sliderReleased()
{
    ui->label->setText(QString::number(ui->horizontalSlider->value()));
}


#ifndef MENU_H
#define MENU_H

#include <QWidget>

#include <Windows.h>
#include <magnification.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class Menu;
}
QT_END_NAMESPACE

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();

private slots:
    void on_checkBox(bool checked);

    void on_pushButton_clicked();

    void on_horizontalSlider_sliderPressed();

    void on_horizontalSlider_actionTriggered(int action);

    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_sliderReleased();

private:
    Ui::Menu *ui;

    MAGCOLOREFFECT g_MagEffectNegative = { -0.3f,  -0.3f,  -0.3f,  0.0f,  0.0f,
                                          -0.6f,  -0.6f,  -0.6f,  0.0f,  0.0f,
                                          -0.1f,  -0.1f,  -0.1f,  0.0f,  0.0f,
                                          1.0f,  1.0f,  1.0f,  1.0f,  0.0f,
                                          0.0f,  0.0f,  0.0f,  0.0f,  1.0f };


    // MAGCOLOREFFECT g_MagEffectNegative ={ 1.0f,  1.0f,  1.0f,  0.0f,  0.0f,
    //                                       0.0f,  0.0f,  0.0f,  0.0f,  0.0f,
    //                                       0.0f,  0.0f,  0.0f,  0.0f,  0.0f,
    //                                       0.1f,  0.1f,  0.1f,  1.0f,  0.0f,
    //                                       0.0f,  0.0f,  0.0f,  0.0f,  1.0f };

    // MAGCOLOREFFECT g_MagEffectNegative ={ 0.3f,  0.3f,  0.3f,  0.0f,  0.0f,
    //                                            0.6f,  0.6f,  0.6f,  0.0f,  0.0f,
    //                                            0.1f,  0.1f,  0.1f,  0.0f,  0.0f,
    //                                            0.0f,  0.0f,  0.0f,  1.0f,  0.0f,
    //                                            0.0f,  0.0f,  0.0f,  0.0f,  1.0f };
    // MAGCOLOREFFECT g_MagEffectNegative = {
    //     0.3f, 0.0f, 0.0f,0.0f, 0.0f,
    //     0.0f, 0.3f, 0.0f, 0.0f, 0.0f,
    //     0.0f, 0.0f, 0.3f, 0.0f, 0.0f,
    //     0.5f, 0.5f, 0.5f, 1.0f, 0.0f,
    //     0.0f, 0.0f, 0.0f, 0.0f, 1.0f
    // };

};
#endif // MENU_H

// MAGCOLOREFFECT g_MagEffectIdentity = { 1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
//                                       0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
//                                       0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
//                                       0.0f,  0.0f,  0.0f,  1.0f,  0.0f,
//                                       0.0f,  0.0f,  0.0f,  0.0f,  1.0f };

// MAGCOLOREFFECT g_MagEffectGrayscale = { 0.3f,  0.3f,  0.3f,  0.0f,  0.0f,
//                                        0.6f,  0.6f,  0.6f,  0.0f,  0.0f,
//                                        0.1f,  0.1f,  0.1f,  0.0f,  0.0f,
//                                        0.0f,  0.0f,  0.0f,  1.0f,  0.0f,
//                                        0.0f,  0.0f,  0.0f,  0.0f,  1.0f };

// MAGCOLOREFFECT g_MagEffectNegative = {
//     -1.0f, 0.0f, 0.0f,0.0f, 0.0f,
//     0.0f, -1.0f, 0.0f, 0.0f, 0.0f,
//     0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
//     0.5f, 0.5f, 0.5f, 1.0f, 0.0f,
//     0.0f, 0.0f, 0.0f, 0.0f, 1.0f
// };

#include "Menu.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    //MagInitialize();

    QApplication a(argc, argv);
    Menu w;
    w.show();
    return a.exec();
}

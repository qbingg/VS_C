﻿

#include <Windows.h>
#include <iostream>

int main()
{
    while (true)
    {
       
        std::cout << GetAsyncKeyState(VK_XBUTTON1)<<"\n";

        Sleep(100);
    }

    std::cout << "Hello World!\n";
}


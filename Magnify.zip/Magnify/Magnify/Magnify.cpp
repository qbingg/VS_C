﻿#include "Magnify.h"

Magnify::Magnify(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint), m_Click()
{
	setAttribute(Qt::WA_TranslucentBackground); 
	m_timer = new QTimer(this);
	connect(m_timer, &QTimer::timeout, this, &Magnify::updateWidget);
    resize(1920, 1080);
}

Magnify::~Magnify()
{}

void Magnify::getClick(bool& Click)
{
	m_Click = &Click;
}

void Magnify::getn(int n)
{
    m_n = n;
}

void Magnify::Magnify_Screen(int x1, int y1, int x2, int y2)
{
    LPCWSTR str = PUBGWINDOWNAME;
    HWND hwnd = FindWindowW(NULL, str);
    HDC hScreenDC = GetWindowDC(hwnd);
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) 
    {
        ReleaseDC(hwnd, hScreenDC);
        return;
    }
    int width = x2 - x1;
    int height = y2 - y1;


    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);
    cv::Mat screenshot(height, width, CV_8UC4); 
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height;
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    cv::Size newSize(screenshot.cols * m_n, screenshot.rows * m_n); 

    cv::Mat resizedImg;

    cv::resize(screenshot, resizedImg, newSize, 0, 0, cv::INTER_LINEAR); 
    opencvImage = resizedImg;
}

void Magnify::paintEvent(QPaintEvent* event)
{
    QPainter painter(this);

    QImage qimg = QImage((const unsigned char*)(opencvImage.data), opencvImage.cols, opencvImage.rows,
        opencvImage.step, QImage::Format_RGB888).rgbSwapped(); 

    int imageWidth = qimg.width();
    int imageHeight = qimg.height();
    int windowWidth = this->width();
    int windowHeight = this->height();


    int x = ((windowWidth - imageWidth) / 2);
    int y = (windowHeight - imageHeight) / 2;

    painter.drawImage(x, y, qimg);
}

void Magnify::startTimer()
{
	m_timer->start(20);
}

void Magnify::stopTimer()
{
	m_timer->stop();
}

void Magnify::updateWidget()
{
    if (*m_Click)
    {
        Magnify_Screen(960 - 160, 540 - 138, 960 + 160, 540 + 122);
        update(); 
    }
    else
    {
        opencvImage.cols = 0;
        opencvImage.rows = 0;
        update();
    }
}
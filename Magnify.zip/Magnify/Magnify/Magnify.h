﻿#pragma once

#include <QWidget>
#include "ui_Magnify.h"
#include "VS_C.h"

class Magnify : public QWidget
{
	Q_OBJECT

public:
	Magnify(QWidget *parent = nullptr);
	~Magnify();

private:
	Ui::MagnifyClass ui;
private:
	const bool* m_Click;
	int m_n;
public:
	void getClick(bool& Click);
	void getn(int n);
private:
	cv::Mat opencvImage;
	QTimer* m_timer; 
private slots:
	void updateWidget(); 
public:
	void Magnify_Screen(int x1, int y1, int x2, int y2);
	void paintEvent(QPaintEvent* event);
	void startTimer();
	void stopTimer();
};

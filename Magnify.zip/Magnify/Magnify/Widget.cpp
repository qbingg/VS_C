﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent, Qt::WindowStaysOnTopHint)
{
    ui.setupUi(this);

    m_Magnify = new Magnify;

    connect(ui.X0, &QRadioButton::clicked, this, &Widget::on_Xn);
    connect(ui.X2, &QRadioButton::clicked, this, &Widget::on_Xn);
    connect(ui.X4, &QRadioButton::clicked, this, &Widget::on_Xn);
    connect(ui.X8, &QRadioButton::clicked, this, &Widget::on_Xn);
}

Widget::~Widget()
{}

void Widget::getMagnify_Click(bool& Magnify_Click)
{
    m_Magnify_Click = &Magnify_Click;
}

void Widget::getn(int n)
{
    m_n = n;
}

bool Widget::on_Xn(bool checked) 
{
    if (ui.X0->isChecked())
    {
        m_Magnify->stopTimer();
        m_Magnify->close();
    }
    else if (ui.X2->isChecked())
    {
        m_Magnify->getClick(*m_Magnify_Click);
        m_Magnify->getn(2);
        m_Magnify->startTimer();
        m_Magnify->show();
    }
    else if (ui.X4->isChecked())
    {
        m_Magnify->getClick(*m_Magnify_Click);
        m_Magnify->getn(4);
        m_Magnify->startTimer();
        m_Magnify->show();
    }
    else if (ui.X8->isChecked())
    {
        m_Magnify->getClick(*m_Magnify_Click);
        m_Magnify->getn(8);
        m_Magnify->startTimer();
        m_Magnify->show();
    }
    return false;
}
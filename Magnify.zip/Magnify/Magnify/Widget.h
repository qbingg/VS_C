﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include <Magnify.h>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    bool* m_Magnify_Click;
    int m_n;
public:
    void getMagnify_Click(bool& Magnify_Click);
    void getn(int n);

private:
    Magnify* m_Magnify;
private slots:
    bool on_Xn(bool checked);
};

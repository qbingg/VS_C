﻿#include "Widget.h"
#include <QtWidgets/QApplication>


bool Magnify_Click = false;

void f_Magnify()
{
    while (true)
    {
        if (GET_RB && GET_LSHIFT == 0)
        {
            while (GET_RB)
            {
                if (GET_LSHIFT)
                {
                    while (GET_RB)
                    {
                        if (Magnify_Click == false)
                        {
                            Magnify_Click = true;
                        }
                        S1
                    }
                    if (Magnify_Click == true)
                    {
                        Magnify_Click = false;
                    }
                    S1
                }
                S1
            }
        }
        S100
    }
}

int main(int argc, char *argv[])
{
    th th_f_Magnify(f_Magnify);
    QApplication a(argc, argv);
    Widget w;
    w.getMagnify_Click(Magnify_Click);
    w.show();
    return a.exec();
}

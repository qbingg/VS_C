﻿#pragma once

#include <QWidget>
#include "ui_Map.h"
#include "VS_C.h"

class Map : public QWidget
{
	Q_OBJECT

public:
	Map(QWidget *parent = nullptr);
	~Map();
	void paintEvent(QPaintEvent* event);
private:
	Ui::MapClass ui;
};

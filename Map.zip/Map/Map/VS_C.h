﻿#pragma once

#include <qtimer.h>
#include <qpainter.h>
#include <Windows.h>
#include <thread>
#include <cmath>

//配置OpenCV
// 1.Release x64
// 2.属性管理器，在Release|x64新建Microsoft.Cpp.x64.user
// 3.VC++目录 包含目录：D:\SEenvironment\OpenCV\opencv\build\include
//                      D:\SEenvironment\OpenCV\opencv\build\include\opencv2
// 4.库目录 D:\SEenvironment\OpenCV\opencv\build\x64\vc16\lib
// 5.连接器 输入 附加依赖项 opencv_world480.lib
//#include <opencv2/opencv.hpp>

#define S1 Sleep(1);
#define S30 Sleep(30);
#define S100 Sleep(100);
#define S1000 Sleep(1000);

#define GET_LB GetAsyncKeyState(VK_LBUTTON) 
#define GET_RB GetAsyncKeyState(VK_RBUTTON) 
#define GET_LSHIFT GetAsyncKeyState(VK_LSHIFT)
#define GET_R GetAsyncKeyState(82) 

#define USE_NUM keybd_event(VK_NUMLOCK, 0, 0, 0);keybd_event(VK_NUMLOCK, 0, KEYEVENTF_KEYUP, 0);

#define th std::thread

#define USE_F7 keybd_event(VK_F7, 0, 0, 0);keybd_event(VK_F7, 0, KEYEVENTF_KEYUP, 0);

#define PUBGWINDOWNAME L"PUBG: BATTLEGROUNDS "

//输入以玩家为原点的坐标，返回,距离x/y轴的原始像素位置
inline int f(int x)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】
	int map_n = 262 / 2;
	
	int res = x + map_n;

	return res;
}

//输入以玩家为原点,距离x/y轴的米数，返回原始像素位置
inline int F(int meter)
{//小地图像素展开区域为462*462【16/9】 512*512【16/10】

	int map = 262;

	int map_n = map / 2;

	double n = map / static_cast<double>(400);//每1米对应的像素值

	int x = meter * n;

	int res = x + map_n;

	return res;
}

//输入米数，返回对应像素值（单位：n个像素点/米）
inline int meter_To_Pixel(int meter)
{
	int map = 262;

	double n = map / static_cast<double>(400);//每1米对应的像素值

	int Pixel = meter * n;

	return Pixel;
}

#define PI 3.1415926
﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent, Qt::WindowStaysOnTopHint)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);

    connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);

    ui.map_x->setValue(1627);

    ui.map_y->setValue(790);
}

Widget::~Widget()
{}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_Map = new Map;

        m_Map->show();
    }
    else
    {

        delete m_Map;
        m_Map = nullptr;
    }
    return false;
}

bool Widget::slot_pushButton(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_Map->move(ui.map_x->value(), ui.map_y->value());
    }

    return false;
}
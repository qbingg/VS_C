﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include "Map.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    Map* m_Map;
private slots:
    bool on_checkBox(bool checked);
    bool slot_pushButton(bool checked);
};

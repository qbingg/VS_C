﻿#include "Map.h"

Map::Map(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);

	resize(462, 462);

}

Map::~Map()
{}

void Map::paintEvent(QPaintEvent * event)
{
	QPainter painter(this);
        
    // 圆弧的参数  
    int centerX = f(0); // 圆心x坐标  
    int centerY = f(0); // 圆心y坐标  
    int R = (462/(7)/2);//50米对应像素
    int radius =  (462 / (7) );  // 半径  (默认100米)

    int r = meter_To_Pixel(50);
    painter.setPen(QPen(Qt::black, 1));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


    for (int i = 2; i <= 14; i++)//100、150、200、250、300、350、400、450、500、550、600、650、700   十三个环
    {
        if (i == 2)//第一环不用操作
        {
            int startAngle = 0 * 16;  // 起始角度，以1/16度为单位（45度 * 16）  
            int spanAngle = 360 * 16;  // 跨越角度，以1/16度为单位（180度 * 16）  
            // 绘制圆弧的矩形边界  
            QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

            // 设置画笔  
            painter.setPen(QPen(Qt::green, 2));
            painter.setBrush(Qt::NoBrush);

            // 绘制圆弧  
            painter.drawArc(arcRect, startAngle, spanAngle);
        }
        else
        {
            //获取半径
            radius = i * R;
            //获取颜色（单黄/偶红）
            if (i % 2 == 0)
            {//偶数
                // 设置画笔  
                painter.setPen(QPen(Qt::green, 2));
                painter.setBrush(Qt::NoBrush);
            }
            else
            {
                // 设置画笔  
                painter.setPen(QPen(Qt::black, 1));
                painter.setBrush(Qt::NoBrush);
            }


            int startAngle = 0 * 16;  // 起始角度，以1/16度为单位（45度 * 16）  
            int spanAngle = 360 * 16;  // 跨越角度，以1/16度为单位（180度 * 16）  

            // 绘制圆弧的矩形边界  
            QRect arcRect(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

            // 绘制圆弧  
            painter.drawArc(arcRect, startAngle, spanAngle);


        }


    }

    //擦去圆弧
    painter.setCompositionMode(QPainter::CompositionMode_Clear);//清除模式
    painter.setPen(QPen(Qt::green, 25));
    //painter.setBrush(QColor(0, 0, 0, 0));
    painter.drawLine(0, 0, 462, 462);
    painter.drawLine(0, 462, 462, 0);
    //painter.drawEllipse(f(0), f(0), F(100), F(100));

    //画标尺
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);//返回默认模式
    painter.setPen(Qt::white);
    QFont font1;
    font1.setPointSizeF(7);
    painter.setFont(font1);
    painter.setBrush(Qt::NoBrush);

    int min = 7;//减去字体误差
    int min2 = 5;
    int max = 5;

    //第4象限
    painter.drawText(F(100 * sin(PI / 4)) - min, F(100 * cos(PI / 4)) + max, "100");
    painter.drawText(F(150 * sin(PI / 4)) - min, F(150 * cos(PI / 4)) + max, "150");
    painter.drawText(F(200 * sin(PI / 4)) - min, F(200 * cos(PI / 4)) + max, "200");
    painter.drawText(F(250 * sin(PI / 4)) - min, F(250 * cos(PI / 4)) + max, "250");
    painter.drawText(F(300 * sin(PI / 4)) - min, F(300 * cos(PI / 4)) + max, "300");
    painter.drawText(F(350 * sin(PI / 4)) - min, F(350 * cos(PI / 4)) + max, "350");
    painter.drawText(F(400 * sin(PI / 4)) - min, F(400 * cos(PI / 4)) + max, "400");
    painter.drawText(F(450 * sin(PI / 4)) - min, F(450 * cos(PI / 4)) + max, "450");

    //第3象限
    painter.drawText(F(-100 * sin(PI / 4)) - min2, F(100 * cos(PI / 4)), "100");
    painter.drawText(F(-150 * sin(PI / 4)) - min2, F(150 * cos(PI / 4)), "150");
    painter.drawText(F(-200 * sin(PI / 4)) - min2, F(200 * cos(PI / 4)), "200");
    painter.drawText(F(-250 * sin(PI / 4)) - min2, F(250 * cos(PI / 4)), "250");
    painter.drawText(F(-300 * sin(PI / 4)) - min2, F(300 * cos(PI / 4)), "300");
    painter.drawText(F(-350 * sin(PI / 4)) - min2, F(350 * cos(PI / 4)), "350");
    painter.drawText(F(-400 * sin(PI / 4)) - min2, F(400 * cos(PI / 4)), "400");
    painter.drawText(F(-450 * sin(PI / 4)) - min2, F(450 * cos(PI / 4)), "450");

    //第1象限
    painter.drawText(F(100 * sin(PI / 4)) - min2, F(-100 * cos(PI / 4)), "100");
    painter.drawText(F(150 * sin(PI / 4)) - min2, F(-150 * cos(PI / 4)), "150");
    painter.drawText(F(200 * sin(PI / 4)) - min2, F(-200 * cos(PI / 4)), "200");
    painter.drawText(F(250 * sin(PI / 4)) - min2, F(-250 * cos(PI / 4)), "250");
    painter.drawText(F(300 * sin(PI / 4)) - min2, F(-300 * cos(PI / 4)), "300");
    painter.drawText(F(350 * sin(PI / 4)) - min2, F(-350 * cos(PI / 4)), "350");
    painter.drawText(F(400 * sin(PI / 4)) - min2, F(-400 * cos(PI / 4)), "400");
    painter.drawText(F(450 * sin(PI / 4)) - min2, F(-450 * cos(PI / 4)), "450");

    //第2象限
    painter.drawText(F(-100 * sin(PI / 4)) - min, F(-100 * cos(PI / 4)) + max, "100");
    painter.drawText(F(-150 * sin(PI / 4)) - min, F(-150 * cos(PI / 4)) + max, "150");
    painter.drawText(F(-200 * sin(PI / 4)) - min, F(-200 * cos(PI / 4)) + max, "200");
    painter.drawText(F(-250 * sin(PI / 4)) - min, F(-250 * cos(PI / 4)) + max, "250");
    painter.drawText(F(-300 * sin(PI / 4)) - min, F(-300 * cos(PI / 4)) + max, "300");
    painter.drawText(F(-350 * sin(PI / 4)) - min, F(-350 * cos(PI / 4)) + max, "350");
    painter.drawText(F(-400 * sin(PI / 4)) - min, F(-400 * cos(PI / 4)) + max, "400");
    painter.drawText(F(-450 * sin(PI / 4)) - min, F(-450 * cos(PI / 4)) + max, "450");


    r = meter_To_Pixel(75);
    painter.setPen(QPen(Qt::white, 0.5));
    painter.drawArc(f(0) - r, f(0) - r, 2 * r, 2 * r, 0 * 16, 360 * 16);


}

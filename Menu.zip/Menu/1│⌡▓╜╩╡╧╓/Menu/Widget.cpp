#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    ui.body->setVisible(false);

    ui.body_7->setVisible(false);

    connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);

    connect(ui.pushButton_9, &QPushButton::clicked, this, &Widget::slot_pushButton2);
}

Widget::~Widget()
{}

bool Widget::slot_pushButton(bool checked)
{
    ui.body->setVisible(!ui.body->isVisible());

    return false;
}

bool Widget::slot_pushButton2(bool checked)
{
    ui.body_7->setVisible(!ui.body_7->isVisible());

    return false;
}
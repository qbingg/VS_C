﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    //ui.body->setVisible(false);

    //ui.body2->setVisible(false);

    //connect(ui.pushButton, &QPushButton::clicked, this, &Widget::slot_pushButton);

    //connect(ui.pushButton_2, &QPushButton::clicked, this, &Widget::slot_pushButton2);

    QStackedWidget* stackedWidget = ui.stackedWidget;

    QComboBox* pageComboBox = ui.comboBox;
    pageComboBox->addItem(tr("Page 1"));
    pageComboBox->addItem(tr("Page 2"));
    pageComboBox->addItem(tr("Page 3"));
    connect(pageComboBox, &QComboBox::activated,
        stackedWidget, &QStackedWidget::setCurrentIndex);

    QToolButton* btn0 = ui.toolButton;
    QToolButton* btn1 = ui.toolButton_2;
    QToolButton* btn2 = ui.toolButton_3;

    connect(btn0, &QToolButton::clicked,
        this, &Widget::slot_btn0);
    connect(btn1, &QToolButton::clicked,
        this, &Widget::slot_btn1);
    connect(btn2, &QToolButton::clicked,
        this, &Widget::slot_btn2);



    //利用数组和for循环，只需要一个槽函数就可绑定：一个按钮对应一个stackedWidget
    QToolButton* btns[10];

    btns[0] = ui.toolButton_4;
    btns[1] = ui.toolButton_5;
    btns[2] = ui.toolButton_6;

    //可在这里为按钮单独设置名字等属性，也可以声明qstring数组，到for循环里自动逐个赋值上去
            //主要是因为我写的功能是数量不固定的，要考虑后期增加，那么设计之初数组数量就确定不了。

    for (int i = 0; i < 3; i++)
    {
        btns[i]->setText(QString::number(i));
        //设置按钮样式

        //设置按钮文字属性，图标

        //设置属性
        btns[i]->setProperty("index", i);
        connect(btns[i], &QToolButton::clicked, this, &Widget::slot_btns);
    }
    
}

Widget::~Widget()
{}

bool Widget::slot_pushButton(bool checked)
{
    //ui.body->setVisible(!ui.body->isVisible());

    return false;
}

bool Widget::slot_pushButton2(bool checked)
{
    //ui.body2->setVisible(!ui.body2->isVisible());

    return false;
}

bool Widget::slot_btn0(bool checked)
{
    ui.stackedWidget->setCurrentIndex(0);

    return false;
}
bool Widget::slot_btn1(bool checked)
{
    ui.stackedWidget->setCurrentIndex(1);

    return false;
}
bool Widget::slot_btn2(bool checked)
{
    ui.stackedWidget->setCurrentIndex(2);

    return false;
}






bool Widget::slot_btns(bool checked)
{
    //获取是哪个按钮
    QToolButton* button = qobject_cast<QToolButton*>(sender());
    if (button)
    {
        //获取按钮的属性的index值
        int index = button->property("index").toInt();

        ui.stackedWidget->setCurrentIndex(index);
    }

    return false;
}

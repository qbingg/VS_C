﻿#include "Widget.h"

constexpr auto BTNS_NUMBER = 3;

QString btns_names[BTNS_NUMBER] = { "头盔","防弹衣","背包" };
QString btns_icons[BTNS_NUMBER] = { "img/t.png","img/j.png","img/b.png" };

//利用数组和for循环，只需要一个槽函数就可绑定：一个按钮对应一个stackedWidget
QToolButton* btns[BTNS_NUMBER];

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);





    btns[0] = ui.toolButton_4;
    btns[1] = ui.toolButton_5;
    btns[2] = ui.toolButton_6;

    //可在这里为按钮单独设置名字等属性，也可以声明qstring数组，到for循环里自动逐个赋值上去
            //主要是因为我写的功能是数量不固定的，要考虑后期增加，那么设计之初数组数量就确定不了。

    for (int i = 0; i < BTNS_NUMBER; i++)
    {
        //btns[i]->setText(QString::number(i));
        btns[i]->setText(btns_names[i]);
        //设置按钮样式

        btns[i]->resize(150, 50);
        
        //btns[i]->setStyleSheet(R"(
        //    QToolButton
        //    {
        //        background-color:#999999 ;
        //
        //        border:1px solid #000000;
        //        border-radius: 5px;
        //
        //        font:16px "Microsoft YaHei";
        //        color:#000000;
        //
        //
        //    }
        //    QToolButton:hover
        //    {
        //        background-color:red;
        //    }
        //)");

        btns[i]->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        btns[i]->setIcon(QIcon(QPixmap(btns_icons[i])));
        btns[i]->setIconSize(QSize(50, 50));

        btns[i]->setStyleSheet(R"(
            QToolButton
            {
                background-color:#999999 ;

                border:1px solid #000000;
                border-radius: 5px;

                font:16px "Microsoft YaHei";
                color:#000000;

            }
            QToolButton:hover
            {
                background-color:white;
            }
        )");

        //设置按钮文字属性，图标

        //设置属性
        btns[i]->setProperty("index", i);
        connect(btns[i], &QToolButton::clicked, this, &Widget::slot_btns);
    }
    
}

Widget::~Widget()
{}

bool Widget::slot_btns(bool checked)
{

    //页面跳转
    //获取是哪个按钮
    QToolButton* button = qobject_cast<QToolButton*>(sender());
    if (button)
    {
        //获取按钮的属性的index值
        int index = button->property("index").toInt();

        ui.stackedWidget->setCurrentIndex(index);
    }

    //按钮变色
    //先重置所有按钮的颜色
    for (int i = 0; i < BTNS_NUMBER; i++)
    {
        btns[i]->setStyleSheet(R"(
            QToolButton
            {
                background-color:#999999 ;

                border:1px solid #000000;
                border-radius: 5px;

                font:16px "Microsoft YaHei";
                color:#000000;

            }
            QToolButton:hover
            {
                background-color:white;
            }
        )");
    }
    //在改变触发按钮的颜色
    //获取按钮的属性的index值       
    int index = button->property("index").toInt();
    btns[index]->setStyleSheet(R"(
            QToolButton
            {
                background-color:red ;

                border:1px solid #000000;
                border-radius: 5px;

                font:16px "Microsoft YaHei";
                color:#000000;

            }
        )");

    return false;
}

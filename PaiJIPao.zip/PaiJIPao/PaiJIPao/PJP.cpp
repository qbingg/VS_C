﻿#include "PJP.h"

PJP::PJP(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);

	resize(1920, 1080);

	m_timer = new QTimer(this);
	connect(m_timer, &QTimer::timeout, this, &PJP::updateWidget);
}

PJP::~PJP()
{}

void PJP::paintEvent(QPaintEvent * event)
{
	if (*uesPJP_map)
	{
		int x0 = 1920 / 2;//中心点
		int y0 = 1080 / 2;

		QPainter painter(this);

		//int r = PaiJiPao(100);
		//painter.setPen(QPen(Qt::green, 1));
		//painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		//r = PaiJiPao(1000);
		//painter.setPen(QPen(Qt::green, 1));
		//painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		int r = PaiJiPao(121);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(133);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(145);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(157);
		painter.setPen(QPen(Qt::red, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(169);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(181);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(193);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(204);
		painter.setPen(QPen(Qt::green, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(216);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(228);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(239);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(250);
		painter.setPen(QPen(Qt::red, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(262);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(273);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(284);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(295);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(307);
		painter.setPen(QPen(Qt::green, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(317);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(328);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(339);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(350);
		painter.setPen(QPen(Qt::red, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(360);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(371);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(381);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(391);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(401);
		painter.setPen(QPen(Qt::green, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(411);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(421);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(431);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(440);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(450);
		painter.setPen(QPen(Qt::red, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(459);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(468);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(477);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(486);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(495);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(503);
		painter.setPen(QPen(Qt::green, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(512);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(520);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(528);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(536);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(544);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(551);
		painter.setPen(QPen(Qt::red, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(559);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(566);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(573);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(580);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(587);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(593);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(600);
		painter.setPen(QPen(Qt::green, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//




		r = PaiJiPao(610);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(620);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(630);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(640);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(650);
		painter.setPen(QPen(Qt::red, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//

		r = PaiJiPao(660);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(670);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(680);
		painter.setPen(QPen(Qt::white, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(690);
		painter.setPen(QPen(Qt::black, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);

		r = PaiJiPao(700);
		painter.setPen(QPen(Qt::green, 1));
		painter.drawArc(x0 - r, y0 - r, 2 * r, 2 * r, 0 * 16, 360 * 16);//







		painter.setCompositionMode(QPainter::CompositionMode_Clear);
		painter.setPen(QPen(Qt::green, 25));
		painter.drawLine(420, 0, 1500, 1080);
		painter.drawLine(420, 1080, 1500, 0);
		painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
		painter.setPen(Qt::green);
		QFont font1;
		font1.setPointSizeF(7);
		painter.setFont(font1);
		painter.setBrush(Qt::NoBrush);
		int min = 7;
		int min2 = 5;
		int max = 5;
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(157 * sin(PI / 4)) - min, PaiJiPao_Fy(157 * cos(PI / 4)) + max, "157");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(204 * sin(PI / 4)) - min, PaiJiPao_Fy(204 * cos(PI / 4)) + max, "204");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(250 * sin(PI / 4)) - min, PaiJiPao_Fy(250 * cos(PI / 4)) + max, "250");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(307 * sin(PI / 4)) - min, PaiJiPao_Fy(307 * cos(PI / 4)) + max, "307");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(350 * sin(PI / 4)) - min, PaiJiPao_Fy(350 * cos(PI / 4)) + max, "350");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(401 * sin(PI / 4)) - min, PaiJiPao_Fy(401 * cos(PI / 4)) + max, "401");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(450 * sin(PI / 4)) - min, PaiJiPao_Fy(450 * cos(PI / 4)) + max, "450");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(503 * sin(PI / 4)) - min, PaiJiPao_Fy(503 * cos(PI / 4)) + max, "503");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(551 * sin(PI / 4)) - min, PaiJiPao_Fy(551 * cos(PI / 4)) + max, "551");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(600 * sin(PI / 4)) - min, PaiJiPao_Fy(600 * cos(PI / 4)) + max, "600");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(650 * sin(PI / 4)) - min, PaiJiPao_Fy(650 * cos(PI / 4)) + max, "650");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(700 * sin(PI / 4)) - min, PaiJiPao_Fy(700 * cos(PI / 4)) + max, "700");

		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-157 * sin(PI / 4)) - min, PaiJiPao_Fy(157 * cos(PI / 4)) + max, "157");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-204 * sin(PI / 4)) - min, PaiJiPao_Fy(204 * cos(PI / 4)) + max, "204");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-250 * sin(PI / 4)) - min, PaiJiPao_Fy(250 * cos(PI / 4)) + max, "250");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-307 * sin(PI / 4)) - min, PaiJiPao_Fy(307 * cos(PI / 4)) + max, "307");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-350 * sin(PI / 4)) - min, PaiJiPao_Fy(350 * cos(PI / 4)) + max, "350");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-401 * sin(PI / 4)) - min, PaiJiPao_Fy(401 * cos(PI / 4)) + max, "401");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-450 * sin(PI / 4)) - min, PaiJiPao_Fy(450 * cos(PI / 4)) + max, "450");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-503 * sin(PI / 4)) - min, PaiJiPao_Fy(503 * cos(PI / 4)) + max, "503");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-551 * sin(PI / 4)) - min, PaiJiPao_Fy(551 * cos(PI / 4)) + max, "551");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-600 * sin(PI / 4)) - min, PaiJiPao_Fy(600 * cos(PI / 4)) + max, "600");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-650 * sin(PI / 4)) - min, PaiJiPao_Fy(650 * cos(PI / 4)) + max, "650");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-700 * sin(PI / 4)) - min, PaiJiPao_Fy(700 * cos(PI / 4)) + max, "700");

		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(157 * sin(PI / 4)) - min, PaiJiPao_Fy(-157 * cos(PI / 4)) + max, "157");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(204 * sin(PI / 4)) - min, PaiJiPao_Fy(-204 * cos(PI / 4)) + max, "204");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(250 * sin(PI / 4)) - min, PaiJiPao_Fy(-250 * cos(PI / 4)) + max, "250");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(307 * sin(PI / 4)) - min, PaiJiPao_Fy(-307 * cos(PI / 4)) + max, "307");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(350 * sin(PI / 4)) - min, PaiJiPao_Fy(-350 * cos(PI / 4)) + max, "350");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(401 * sin(PI / 4)) - min, PaiJiPao_Fy(-401 * cos(PI / 4)) + max, "401");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(450 * sin(PI / 4)) - min, PaiJiPao_Fy(-450 * cos(PI / 4)) + max, "450");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(503 * sin(PI / 4)) - min, PaiJiPao_Fy(-503 * cos(PI / 4)) + max, "503");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(551 * sin(PI / 4)) - min, PaiJiPao_Fy(-551 * cos(PI / 4)) + max, "551");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(600 * sin(PI / 4)) - min, PaiJiPao_Fy(-600 * cos(PI / 4)) + max, "600");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(650 * sin(PI / 4)) - min, PaiJiPao_Fy(-650 * cos(PI / 4)) + max, "650");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(700 * sin(PI / 4)) - min, PaiJiPao_Fy(-700 * cos(PI / 4)) + max, "700");

		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-157 * sin(PI / 4)) - min, PaiJiPao_Fy(-157 * cos(PI / 4)) + max, "157");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-204 * sin(PI / 4)) - min, PaiJiPao_Fy(-204 * cos(PI / 4)) + max, "204");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-250 * sin(PI / 4)) - min, PaiJiPao_Fy(-250 * cos(PI / 4)) + max, "250");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-307 * sin(PI / 4)) - min, PaiJiPao_Fy(-307 * cos(PI / 4)) + max, "307");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-350 * sin(PI / 4)) - min, PaiJiPao_Fy(-350 * cos(PI / 4)) + max, "350");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-401 * sin(PI / 4)) - min, PaiJiPao_Fy(-401 * cos(PI / 4)) + max, "401");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-450 * sin(PI / 4)) - min, PaiJiPao_Fy(-450 * cos(PI / 4)) + max, "450");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-503 * sin(PI / 4)) - min, PaiJiPao_Fy(-503 * cos(PI / 4)) + max, "503");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-551 * sin(PI / 4)) - min, PaiJiPao_Fy(-551 * cos(PI / 4)) + max, "551");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-600 * sin(PI / 4)) - min, PaiJiPao_Fy(-600 * cos(PI / 4)) + max, "600");
		painter.setPen(Qt::red);
		painter.drawText(PaiJiPao_Fx(-650 * sin(PI / 4)) - min, PaiJiPao_Fy(-650 * cos(PI / 4)) + max, "650");
		painter.setPen(Qt::green);
		painter.drawText(PaiJiPao_Fx(-700 * sin(PI / 4)) - min, PaiJiPao_Fy(-700 * cos(PI / 4)) + max, "700");
	}



}

void PJP::getuesPJP_map(bool &m_uesPJP_map)
{
	uesPJP_map = &m_uesPJP_map;
}

void PJP::startTimer()
{
	m_timer->start(33);
}

void PJP::stopTimer()
{
	m_timer->stop();
}

void PJP::updateWidget()
{
	if (*uesPJP_map)
	{
		update();
	}
	else
	{
		update();
	}
}
﻿#pragma once

#include <QWidget>
#include "ui_PJP.h"
#include "VS_C.h"

class PJP : public QWidget
{
	Q_OBJECT

public:
	PJP(QWidget *parent = nullptr);
	~PJP();
	void paintEvent(QPaintEvent* event);
private:
	Ui::PJPClass ui;
	bool* uesPJP_map;
public:
	void getuesPJP_map(bool& m_uesPJP_map);

private:
	QTimer* m_timer;
private slots:
	void updateWidget();
public:
	void startTimer();
	void stopTimer();
};

﻿#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &Widget::on_checkBox);
}

Widget::~Widget()
{}

void Widget::getusePJP_Map(bool& usePJP_Map)
{
    m_usePJP_Map = &usePJP_Map;
}

bool Widget::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_PJP = new PJP;

        m_PJP->getuesPJP_map(*m_usePJP_Map);

        m_PJP->startTimer();

        m_PJP->show();
    }
    else
    {
        m_PJP->stopTimer();
        m_PJP->close();
        delete m_PJP;
        m_PJP = nullptr;
    }
    return false;
}

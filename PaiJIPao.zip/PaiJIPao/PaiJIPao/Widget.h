﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include"PJP.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    PJP* m_PJP;
private:
    Ui::WidgetClass ui;
    bool* m_usePJP_Map;

public:
    void getusePJP_Map(bool& usePJP_Map);
private slots:
    bool on_checkBox(bool checked);
};

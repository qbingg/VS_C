﻿#include "Widget.h"
#include <QtWidgets/QApplication>


bool usePJP_Map = false;

void f_M()
{
	while (true)
	{
		GET_M;
		GET_M2;
		if (GET_M || GET_M2)
		{
			if (usePJP_Map)
			{
				usePJP_Map = false;
			}
			else
			{
				usePJP_Map = true;
			}
			S300
		}
		S1
	}
}

int main(int argc, char *argv[])
{
	th th_f_M(f_M);
    QApplication a(argc, argv);
    Widget w;
	w.getusePJP_Map(usePJP_Map);
    w.show();
    return a.exec();
}

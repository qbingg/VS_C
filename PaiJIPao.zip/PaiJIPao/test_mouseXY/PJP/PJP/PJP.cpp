﻿#include "PJP.h"

PJP::PJP(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);

    connect(ui.checkBox, &QCheckBox::stateChanged, this, &PJP::on_checkBox);

    connect(ui.pushButton, &QPushButton::clicked, this, &PJP::slot_pushButton);

    ui.spinBox->setValue(1315);

    ui.spinBox_2->setValue(520);
}

PJP::~PJP()
{}

void PJP::getenemyMeter(int& enemyMeter)
{
    m_enemyMeter = &enemyMeter;
}

bool PJP::slot_pushButton(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_ShowMeterWin->move(ui.spinBox->value(), ui.spinBox_2->value());
    }

    return false;
}

bool PJP::on_checkBox(bool checked)
{
    if (ui.checkBox->isChecked())
    {
        m_ShowMeterWin = new ShowMeterWin;

        m_ShowMeterWin->getenemyMeter(*m_enemyMeter);

        m_ShowMeterWin->startTimer();

        m_ShowMeterWin->show();
    }
    else
    {
        m_ShowMeterWin->stopTimer();
        m_ShowMeterWin->close();
        delete m_ShowMeterWin;
        m_ShowMeterWin = nullptr;
    }
    return false;
}

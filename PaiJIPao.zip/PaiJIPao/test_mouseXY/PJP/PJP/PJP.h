﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_PJP.h"
#include"ShowMeterWin.h"
class PJP : public QWidget
{
    Q_OBJECT

public:
    PJP(QWidget *parent = nullptr);
    ~PJP();

private:
    Ui::PJPClass ui;
    int* m_enemyMeter;
    ShowMeterWin* m_ShowMeterWin;
public:
    void getenemyMeter(int& enemyMeter);
private slots:
    bool on_checkBox(bool checked);
    bool slot_pushButton(bool checked);
};

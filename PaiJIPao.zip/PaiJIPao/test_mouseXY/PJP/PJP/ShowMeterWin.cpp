﻿#include "ShowMeterWin.h"

ShowMeterWin::ShowMeterWin(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);

	resize(100, 100);

	m_timer = new QTimer(this);
	connect(m_timer, &QTimer::timeout, this, &ShowMeterWin::updateWidget);
}

ShowMeterWin::~ShowMeterWin()
{}

void ShowMeterWin::startTimer()
{
	m_timer->start(500);
}

void ShowMeterWin::stopTimer()
{
	m_timer->stop();
}

void ShowMeterWin::paintEvent(QPaintEvent* event)
{
	QPainter painter(this);

	QString strNumber = QString::number(*enemyMeter); // X保留3位小数,转换为string，用QMessageBox以输出
	QString STR =  strNumber + " M";

	painter.setPen(Qt::green);
	QFont font1;
	font1.setPointSizeF(15);
	painter.setFont(font1);
	painter.setBrush(Qt::NoBrush);
	painter.drawText(2, 18, STR);//不能绘制在0,0	文字绘制在点的右上角
}

void ShowMeterWin::getenemyMeter(int& m_enemyMeter)
{
	enemyMeter = &m_enemyMeter;
}

void ShowMeterWin::updateWidget()
{
		update();
}




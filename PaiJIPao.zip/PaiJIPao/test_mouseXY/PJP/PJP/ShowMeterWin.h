﻿#pragma once

#include <QWidget>
#include "ui_ShowMeterWin.h"
#include "VS_C.h"

class ShowMeterWin : public QWidget
{
	Q_OBJECT

public:
	ShowMeterWin(QWidget *parent = nullptr);
	~ShowMeterWin();

private:
	Ui::ShowMeterWinClass ui;

private:
	QTimer* m_timer;
private slots:
	void updateWidget();
public:
	void startTimer();
	void stopTimer();
	void paintEvent(QPaintEvent* event);

private:
	int* enemyMeter;
public:
	void getenemyMeter(int& m_enemyMeter);
};

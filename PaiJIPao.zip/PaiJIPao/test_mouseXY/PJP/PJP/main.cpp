﻿#include "PJP.h"
#include <QtWidgets/QApplication>

int enemyMeter = 0;

#define X0 960
#define Y0 540

//比例尺，多少米=1像素,  2000米对应1080个像素
//#define POINT_METER (2000/1080)//=1?

int f_math(POINT& cursorPos)
{
    //两点差
    int Lx = (X0 - cursorPos.x);
    int Ly = (Y0 - cursorPos.y);

    //计算像素距离
    double L = sqrt((Lx * Lx) + (Ly * Ly));

    //换算比例尺
    //return (L * POINT_METER);
    //int meter = L * (static_cast<double>(2000) / 1080);
    return L * (static_cast<double>(2000) / 1080);
}

void f_RB()
{
    POINT cursorPos; // 定义一个POINT结构体来存储鼠标坐标  
    while (true)
    {
        GET_RB;
        if (GET_RB)
        {
            GetCursorPos(&cursorPos);
            enemyMeter = f_math(cursorPos);
            S100;
            while (GET_RB)
            {
                GET_RB;
                S1;
            }
        }
        S1
    }
}

int main(int argc, char *argv[])
{
    th th_f_RB(f_RB);
    QApplication a(argc, argv);
    PJP w;
    w.getenemyMeter(enemyMeter);
    w.show();
    return a.exec();
}

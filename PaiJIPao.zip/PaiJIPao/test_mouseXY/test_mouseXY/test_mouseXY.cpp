﻿#include <windows.h>  
#include <iostream>  

int main() {
    POINT cursorPos; // 定义一个POINT结构体来存储鼠标坐标  




    while (true)
    {
        // 调用GetCursorPos函数，将鼠标坐标存储在cursorPos中  
        if (GetCursorPos(&cursorPos)) {
            // 如果调用成功  
            std::cout << "鼠标当前坐标：(" << cursorPos.x << ", " << cursorPos.y << ")" << std::endl;
        }
        else {
            // 如果调用失败  
            std::cerr << "获取鼠标坐标失败！" << std::endl;
        }
        Sleep(200);
        system("cls");//清除屏幕
    }


    //int x = 2000 / 1080;
    //      std::cout<< x << std::endl;//x=1


    return 0;
}
#include "Panzerfaust.h"

Panzerfaust::Panzerfaust(QWidget *parent)
	: QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
{
	setAttribute(Qt::WA_TranslucentBackground);

	resize(1920, 1080);

}

Panzerfaust::~Panzerfaust()
{}

void Panzerfaust::paintEvent(QPaintEvent * event)
{
	int x0 = 1920 / 2;//��Ļ���ĵ�
	int y0 = 1080 / 2;//��Ļ���ĵ�

	QPainter painter(this);
	painter.setBrush(Qt::NoBrush);

	painter.setPen(QPen(Qt::green, 3));

	painter.drawLine(x0, y0 + 53, x0 + 80, y0 + 53);


	painter.drawLine(x0, y0 + 121, x0 + 100, y0 + 121);//100m

	painter.drawLine(x0, y0 + 237, x0 + 80, y0 + 237);//150m

	painter.setPen(QPen(Qt::black, 3));


	painter.drawLine(x0, y0 + 273, x0 + 80, y0 + 273);//160m

	painter.setPen(QPen(Qt::white, 3));

	painter.drawLine(x0, y0 + 325, x0 + 80, y0 + 325);//170m

	painter.drawLine(x0, y0 + y0 - 18, x0 + 100, y0 + y0 - 18);//180m
}

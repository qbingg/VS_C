#pragma once

#include <QWidget>
#include "ui_Panzerfaust.h"
#include "VS_C.h"

class Panzerfaust : public QWidget
{
	Q_OBJECT

public:
	Panzerfaust(QWidget *parent = nullptr);
	~Panzerfaust();
	void paintEvent(QPaintEvent* event);
private:
	Ui::PanzerfaustClass ui;
};

#pragma once

#include <QtWidgets/QWidget>
#include "ui_Widget.h"
#include "Panzerfaust.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::WidgetClass ui;
    Panzerfaust* m_Panzerfaust;
private slots:
    bool on_checkBox(bool checked);
};

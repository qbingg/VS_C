﻿// TEST1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <Windows.h>

void MoveMouseRelative(int dx, int dy) 
{
	INPUT input = { 0 };
	input.type = INPUT_MOUSE;
	input.mi.dx = dx;
	input.mi.dy = dy;
	input.mi.dwFlags = MOUSEEVENTF_MOVE;
	SendInput(1, &input, sizeof(INPUT));
}
void mouseMove_M16A4()
{
	int I = 0;
	while (true)
	{

		while (1)//仅在M16模式下有效
		{
			GetAsyncKeyState(VK_RBUTTON);
			GetAsyncKeyState(VK_LBUTTON);
			//仅在开镜时并开火时有效
			//按着鼠标右键&&按着鼠标左键
			while (GetAsyncKeyState(VK_RBUTTON) && GetAsyncKeyState(VK_LBUTTON))
			{
				//后坐力呈现分段线性变化，还带有随机性，不好拟合，等以后学了人体识别（框）之后再说
				//if (I < 60)
				//{
				//	MoveMouseRelative(0, 5);
				//	Sleep(1);
				//}
				//else if (I < 300)
				//{
				//	MoveMouseRelative(0, 7);
				//	Sleep(1);
				//}
				//else //if (I < 500)
				//{
				//	MoveMouseRelative(0, 10);
				//	Sleep(1);
				//}

				//I++;

				//if (I < 60)
				//{
				//	//MoveMouseRelative(0, 3);
				//	Sleep(1);
				//}
				//else 
				//{
					//MoveMouseRelative(0, 5);
					//Sleep(1);
				//}

				if (I < 30)//0~6发
				{
					MoveMouseRelative(0, 4);
					Sleep(1);
				}
				else if (I < 46)//6~9
				{
					MoveMouseRelative(0, 8);
					Sleep(1);
				}
				else //if (1)//
				{
					MoveMouseRelative(0, 9);
					Sleep(1);
				}


				I++;
				//刷新检测状态
				GetAsyncKeyState(VK_RBUTTON);
				GetAsyncKeyState(VK_LBUTTON);
			}
			I = 0;
			Sleep(1);
			//std::cout << I<<"\n";
		}
		Sleep(1000);
	}
}
int main()
{
	mouseMove_M16A4();

}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件

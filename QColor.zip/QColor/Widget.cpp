#include "Widget.h"
#include "ui_Widget.h"

#include <qmessagebox.h>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_horizontalSlider_r_actionTriggered(int action)
{
    color =
    {
        ui->horizontalSlider_r->value(),
        ui->horizontalSlider_g->value(),
        ui->horizontalSlider_b->value()
    };

    //QMessageBox::information(this, "",color.name() );

    ui->label_show->setStyleSheet("background-color:"+color.name());
    ui->label_2->setText(color.name());

}


void Widget::on_horizontalSlider_g_actionTriggered(int action)
{
    color =
        {
            ui->horizontalSlider_r->value(),
            ui->horizontalSlider_g->value(),
            ui->horizontalSlider_b->value()
        };



    ui->label_show->setStyleSheet("background-color:"+color.name());
    ui->label_2->setText(color.name());
}


void Widget::on_horizontalSlider_b_actionTriggered(int action)
{
    color =
        {
            ui->horizontalSlider_r->value(),
            ui->horizontalSlider_g->value(),
            ui->horizontalSlider_b->value()
        };



    ui->label_show->setStyleSheet("background-color:"+color.name());
    ui->label_2->setText(color.name());
}


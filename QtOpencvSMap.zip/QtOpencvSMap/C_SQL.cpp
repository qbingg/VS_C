#include "C_SQL.h"

C_SQL::C_SQL()
{
    initSQL();
}

C_SQL::~C_SQL(){}

void C_SQL::initSQL()
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return;
    }


    QSqlQuery query;
    QString sql = QString::fromUtf8(R"(
create table if not exists tb_data
(
id int PRIMARY KEY,
screen_resolution_x int ,
screen_resolution_y int ,
screen_magnify double ,

screenMethod int ,

sMap700_x1 int ,
sMap700_y1 int ,
sMap700_x2 int ,
sMap700_y2 int ,


point_PngTarget_x int ,
point_PngTarget_y int

)
)");
    if (!query.exec(sql))
    {
        qDebug() << "Failed to create table";
        qDebug() << query.lastQuery();
        return;
    }
    m_db.close();
}

bool C_SQL::readDatas(Data& data)
{
    if (!m_db.open())
    {
        qDebug() << "Failed to open database :Database";
        return false;
    }


    QSqlQuery query;
    QString sql = "Select * from tb_data where id = 1;";//tb_sleep 这个是表格名字
    if (!query.exec(sql))
    {
        qDebug() << "Failed to select tb_data";//tb_sleep 这个是表格名字
        return false;
    }

    //第一次循环返回true，第二次返回false
    //while (query.next())//如果当前行是结果集中的最后一行，那么再次调用 query.next() 将返回 false，表示没有更多的行可以遍历了
    if (query.next())
    {

        //将数据放入链表（Data& data）里
        data.setData(


            query.value("screen_resolution_x").toInt(),
            query.value("screen_resolution_y").toInt(),
            query.value("screen_magnify").toDouble(),



            query.value("sMap700_x1").toInt(),
            query.value("sMap700_y1").toInt(),
            query.value("sMap700_x2").toInt(),
            query.value("sMap700_y2").toInt(),



            query.value("point_PngTarget_x").toInt(),
            query.value("point_PngTarget_y").toInt()



            );
    }
    else//一行“id=1”都没有，说明数据库是空的，返回false不允许赋值到菜单控件上
    {
        m_db.close();

        return false;
    }





    m_db.close();

    return true;
}

bool C_SQL::addData(Data& data)
{
    //重进数据库，便于我修改表结构时，读取旧的数据库后，删除.db文件，保存的时候自动创建新的.db
    initSQL();

    if (!m_db.open())
    {
        qDebug() << "Failed to open ,addData";
        return false;
    }

    //添加数据前，删除表中旧的数据（因为insert只能插入，不能修改）
    QSqlQuery deleteQuery;
    deleteQuery.prepare("delete from tb_data");
    deleteQuery.exec();



    QSqlQuery query;
    query.prepare(R"(
insert into tb_data
(
id,


screen_resolution_x,
screen_resolution_y,
screen_magnify,



sMap700_x1 ,
sMap700_y1 ,
sMap700_x2 ,
sMap700_y2 ,



point_PngTarget_x ,
point_PngTarget_y






)
values
(
:id,


:screen_resolution_x,
:screen_resolution_y,
:screen_magnify,

:sMap700_x1 ,
:sMap700_y1 ,
:sMap700_x2 ,
:sMap700_y2 ,



:point_PngTarget_x ,
:point_PngTarget_y




)
)");

    query.bindValue(":id", 1);


    query.bindValue(":screen_resolution_x", data.screen_resolution_x());
    query.bindValue(":screen_resolution_y", data.screen_resolution_y());
    query.bindValue(":screen_magnify", data.screen_magnify());



    query.bindValue(":sMap700_x1", data.sMap700_x1());
    query.bindValue(":sMap700_y1", data.sMap700_y1());
    query.bindValue(":sMap700_x2", data.sMap700_x2());
    query.bindValue(":sMap700_y2", data.sMap700_y2());



    query.bindValue(":point_PngTarget_x", data.point_PngTarget_x());
    query.bindValue(":point_PngTarget_y", data.point_PngTarget_y());





    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }
    m_db.close();

    return true;
}



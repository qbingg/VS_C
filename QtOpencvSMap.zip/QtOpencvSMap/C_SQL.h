#ifndef C_SQL_H
#define C_SQL_H

#include "Data.h"

class C_SQL
{
private:
    QSqlDatabase m_db;  //数据库连接
public:
    C_SQL();//构造函数，尝试打开数据库，失败则创建新的数据库
    ~C_SQL();
    bool readDatas(Data& data);//读取数据库，获取数据返回到Qlist里，执行成功返回true
    bool addData(Data& data);//向数据库插入数据，执行成功返回true
    //重进数据库，便于我修改表结构时，读取旧的数据库后，删除.db文件，保存的时候自动创建新的.db
    void initSQL();
};

#endif // C_SQL_H

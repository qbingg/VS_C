#include "Data.h"

bool Data::setData
    (


        int screen_resolution_x,
        int screen_resolution_y,
        double screen_magnify,


        int sMap700_x1,
        int sMap700_y1,
        int sMap700_x2,
        int sMap700_y2,

        int point_PngTarget_x,
        int point_PngTarget_y
        )
{


    m_screen_resolution_x = screen_resolution_x;
    m_screen_resolution_y = screen_resolution_y;
    m_screen_magnify = screen_magnify;



    m_sMap700_x1 = sMap700_x1;
    m_sMap700_y1 = sMap700_y1;
    m_sMap700_x2 = sMap700_x2;
    m_sMap700_y2 = sMap700_y2;



    m_point_PngTarget_x = point_PngTarget_x;
    m_point_PngTarget_y = point_PngTarget_y;


    return true;//更改类中成员的值，返回true
}



int Data::screen_resolution_x() const
{
    return m_screen_resolution_x;
}

void Data::setscreen_resolution_x(const int& screen_resolution_x)
{
    m_screen_resolution_x = screen_resolution_x;
}

int Data::screen_resolution_y() const
{
    return m_screen_resolution_y;
}

void Data::setscreen_resolution_y(const int& screen_resolution_y)
{
    m_screen_resolution_y = screen_resolution_y;
}

double Data::screen_magnify() const
{
    return m_screen_magnify;
}

void Data::setscreen_magnify(const double& screen_magnify)
{
    m_screen_magnify = screen_magnify;
}



int Data::sMap700_x1() const
{
    return m_sMap700_x1;
}

void Data::setsMap700_x1(const int& sMap700_x1)
{
    m_sMap700_x1 = sMap700_x1;
}

int Data::sMap700_y1() const
{
    return m_sMap700_y1;
}

void Data::setsMap700_y1(const int& sMap700_y1)
{
    m_sMap700_y1 = sMap700_y1;
}

int Data::sMap700_x2() const
{
    return m_sMap700_x2;
}

void Data::setsMap700_x2(const int& sMap700_x2)
{
    m_sMap700_x2 = sMap700_x2;
}

int Data::sMap700_y2() const
{
    return m_sMap700_y2;
}

void Data::setsMap700_y2(const int& sMap700_y2)
{
    m_sMap700_y2 = sMap700_y2;
}



int Data::point_PngTarget_x() const
{
    return m_point_PngTarget_x;
}

void Data::setpoint_PngTarget_x(const int& point_PngTarget_x)
{
    m_point_PngTarget_x = point_PngTarget_x;
}

int Data::point_PngTarget_y() const
{
    return m_point_PngTarget_y;
}

void Data::setpoint_PngTarget_y(const int& point_PngTarget_y)
{
    m_point_PngTarget_y = point_PngTarget_y;
}



#ifndef DATA_H
#define DATA_H

#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>
class Data
{
private:


    int m_screen_resolution_x;//屏幕分辨率，宽x
    int m_screen_resolution_y;//屏幕分辨率，高y
    double m_screen_magnify;//1.25窗口缩放倍率125%

    int m_sMap700_x1;
    int m_sMap700_y1;
    int m_sMap700_x2;
    int m_sMap700_y2;

    int m_point_PngTarget_x;
    int m_point_PngTarget_y;

public:
    bool setData
        (
            int screen_resolution_x,
            int screen_resolution_y,
            double screen_magnify,

            int sMap700_x1,
            int sMap700_y1,
            int sMap700_x2,
            int sMap700_y2,



            int point_PngTarget_x,
            int point_PngTarget_y

            );

    int screen_resolution_x() const;
    void setscreen_resolution_x(const int& screen_resolution_x);

    int screen_resolution_y() const;
    void setscreen_resolution_y(const int& screen_resolution_y);

    double screen_magnify() const;
    void setscreen_magnify(const double& screen_magnify);




    int sMap700_x1() const;
    void setsMap700_x1(const int& sMap700_x1);
    int sMap700_y1() const;
    void setsMap700_y1(const int& sMap700_y1);
    int sMap700_x2() const;
    void setsMap700_x2(const int& sMap700_x2);
    int sMap700_y2() const;
    void setsMap700_y2(const int& sMap700_y2);


    int point_PngTarget_x() const;
    void setpoint_PngTarget_x(const int& point_PngTarget_x);
    int point_PngTarget_y() const;
    void setpoint_PngTarget_y(const int& point_PngTarget_y);


};


#endif // DATA_H

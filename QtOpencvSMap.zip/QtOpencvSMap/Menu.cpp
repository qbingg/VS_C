#include "Menu.h"
#include "ui_Menu.h"
#include <QMessageBox>

Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);

    connect(ui->checkBox, &QCheckBox::stateChanged, this, &Menu::on_checkBoxcheck_sMap_Point);

    this->setWindowTitle("标点自动测距学习样本源码编译");
}

Menu::~Menu()
{
    delete ui;
}

void Menu::getdata(int screen_resolution_x, int screen_resolution_y, double screen_magnify, int sMap700_x1, int sMap700_y1, int sMap700_x2, int sMap700_y2, int point_PngTarget_x, int point_PngTarget_y)
{
    m_screen_resolution_x = screen_resolution_x;
    m_screen_resolution_y = screen_resolution_y;
    m_screen_magnify = screen_magnify;

    m_sMap700_x1 = sMap700_x1;
    m_sMap700_y1 = sMap700_y1;
    m_sMap700_x2 = sMap700_x2;
    m_sMap700_y2 = sMap700_y2;

    m_point_PngTarget_x = point_PngTarget_x;
    m_point_PngTarget_y = point_PngTarget_y;

    ui->screen_resolution_x->setValue(m_screen_resolution_x);
    ui->screen_resolution_y->setValue(m_screen_resolution_y);
    ui->screen_magnify->setValue(m_screen_magnify);

    ui->sMap700_x1->setValue(m_sMap700_x1);
    ui->sMap700_y1->setValue(m_sMap700_y1);
    ui->sMap700_x2->setValue(m_sMap700_x2);
    ui->sMap700_y2->setValue(m_sMap700_y2);

    ui->point_PngTarget_x->setValue(m_point_PngTarget_x);
    ui->point_PngTarget_y->setValue(m_point_PngTarget_y);

}

void Menu::on_pushButton_clicked()
{
    C_SQL m_C_SQL;

    Data data;

    data.setscreen_resolution_x(ui->screen_resolution_x->value());
    data.setscreen_resolution_y(ui->screen_resolution_y->value());
    data.setscreen_magnify(ui->screen_magnify->value());

    data.setsMap700_x1(ui->sMap700_x1->value());
    data.setsMap700_y1(ui->sMap700_y1->value());
    data.setsMap700_x2(ui->sMap700_x2->value());
    data.setsMap700_y2(ui->sMap700_y2->value());

    //小地图测距
    data.setpoint_PngTarget_x(ui->point_PngTarget_x->value());
    data.setpoint_PngTarget_y(ui->point_PngTarget_y->value());

    m_screen_resolution_x = ui->screen_resolution_x->value();
    m_screen_resolution_y = ui->screen_resolution_y->value();
    m_screen_magnify = ui->screen_magnify->value();

    m_sMap700_x1 = ui->sMap700_x1->value();
    m_sMap700_y1 = ui->sMap700_y1->value();
    m_sMap700_x2 = ui->sMap700_x2->value();
    m_sMap700_y2 = ui->sMap700_y2->value();

    //小地图测距
    m_point_PngTarget_x = ui->point_PngTarget_x->value();
    m_point_PngTarget_y = ui->point_PngTarget_y->value();


    m_C_SQL.addData(data);
}


// void Menu::on_checkBox_checkStateChanged(const Qt::CheckState &arg1)
// {

// }

bool Menu::on_checkBoxcheck_sMap_Point(bool checked)
{
    if (ui->checkBox->isChecked())
    {




        m_C_sMap_Point = new C_sMap_Point;

        m_C_sMap_Point->resize(
                          (m_sMap700_x2-m_sMap700_x1)/m_screen_magnify,
                          (m_sMap700_y2-m_sMap700_y1)/m_screen_magnify
            );

        m_C_sMap_Point->getxy
            (




                m_sMap700_x1,
                m_sMap700_y1,
                m_sMap700_x2,
                m_sMap700_y2,

                m_screen_magnify,

                m_point_PngTarget_x,
                m_point_PngTarget_y

                );

        m_C_sMap_Point->startTimer();

        m_C_sMap_Point->show();

    }
    else
    {




        m_C_sMap_Point->stopTimer();
        m_C_sMap_Point->close();
        delete m_C_sMap_Point;
        m_C_sMap_Point = nullptr;
    }


    return false;
}


void Menu::on_pushButton_2_clicked()
{
    QMessageBox::information(this,"","1.游戏为繁体中文（更改后重启游戏）\n2.输入你的分辨率，窗口缩放倍率\n3.输入你屏幕小地图放大后(700mX700m)的左上角、右下角两个点的像素坐标\n4.把标点作截图，裁剪成如目录下：res/opencvImg那些点的格式，覆盖图片文件\n5.把截图的大小,x/2和y填入“目标像素位置”\n6.点击保存数据，然后勾选启动框，见绿框完全覆盖即可\n\n\n我写来锻炼代码的，请勿用于游戏对局");
}


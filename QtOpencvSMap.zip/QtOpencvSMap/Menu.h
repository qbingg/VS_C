#ifndef MENU_H
#define MENU_H

#include <QWidget>
#include "C_SQL.h"
#include "C_sMap_Point.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Menu;
}
QT_END_NAMESPACE

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();

private:
    Ui::Menu *ui;

    int m_screen_resolution_x;//屏幕分辨率，宽x
    int m_screen_resolution_y;//屏幕分辨率，高y
    double m_screen_magnify;//1.25窗口缩放倍率125%

    int m_sMap700_x1;
    int m_sMap700_y1;
    int m_sMap700_x2;
    int m_sMap700_y2;

    int m_point_PngTarget_x;
    int m_point_PngTarget_y;

 public:
    void getdata(        int screen_resolution_x,
                  int screen_resolution_y,
                  double screen_magnify,


                  int sMap700_x1,
                  int sMap700_y1,
                  int sMap700_x2,
                  int sMap700_y2,

                  int point_PngTarget_x,
                  int point_PngTarget_y);

 private slots:
     void on_pushButton_clicked();

//小地图测距
     //void on_checkBox_checkStateChanged(const Qt::CheckState &arg1);

 private:
     C_sMap_Point* m_C_sMap_Point;
 private slots:
     bool on_checkBoxcheck_sMap_Point(bool checked);
     void on_pushButton_2_clicked();
};
#endif // MENU_H

#include "Menu.h"

#include <QApplication>

#include "C_SQL.h"
int screen_resolution_x;//屏幕分辨率，宽x
int screen_resolution_y;//屏幕分辨率，高y
double screen_magnify;//1.25窗口缩放倍率125%

int sMap700_x1;
int sMap700_y1;
int sMap700_x2;
int sMap700_y2;

//小地图测距
//模板图片，目标像素位置
int point_PngTarget_x;
int point_PngTarget_y;

bool areYouGetDatas = true;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    if(true)
    {
        //读取数据库数据，并赋值到全局变量上
        C_SQL sql;
        Data data;
        bool res = sql.readDatas(data);

        if (!res)//读取数据失败
        {
            areYouGetDatas = false;
        }
        else//获取数据
        {

            screen_resolution_x = data.screen_resolution_x();
            screen_resolution_y = data.screen_resolution_y();
            screen_magnify = data.screen_magnify();



            sMap700_x1 = data.sMap700_x1();
            sMap700_y1 = data.sMap700_y1();
            sMap700_x2 = data.sMap700_x2();
            sMap700_y2 = data.sMap700_y2();



            point_PngTarget_x = data.point_PngTarget_x();
            point_PngTarget_y = data.point_PngTarget_y();


        }
    }

    Menu w;
    if(areYouGetDatas)
    {
        w.getdata
        (
            screen_resolution_x,
            screen_resolution_y,
            screen_magnify,

            sMap700_x1,
            sMap700_y1,
            sMap700_x2,
            sMap700_y2,

            point_PngTarget_x,
            point_PngTarget_y
            );
    }
    w.show();
    return a.exec();
}

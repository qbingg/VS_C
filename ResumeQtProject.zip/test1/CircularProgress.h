#ifndef CIRCULARPROGRESS_H
#define CIRCULARPROGRESS_H
#include <QPainter>
#include <QWidget>
#include <QPixmap>
#include <QTimer>
#include <QVector>
#include <qmessagebox.h>
#include <QPainterPath>


class CircularProgress : public QWidget
{
    Q_OBJECT

private:
    int m_powerLevel;
    bool m_isRed; // 添加颜色状态标志

    QTimer *m_timer;
    QVector<QPixmap> m_frames;
    QVector<QPixmap> m_greenFrames; // 绿色图片组
    QVector<QPixmap> m_redFrames;   // 红色图片组
    int m_currentFrame=0;

public:
    CircularProgress(QWidget *parent = nullptr)
        : QWidget(parent), m_isRed(false) // 默认绿色
    {
        // 移除窗口标志或条件性设置
        if (!parent) {
            setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
        }
        setAttribute(Qt::WA_TranslucentBackground);

        resize(100,100);

        // 加载所有绿色帧图片
        for (int i = 1; i <= 6; ++i) {
            QString filename = QString("g%1.png").arg(i, 2, 10, QLatin1Char('0'));
            QPixmap frame(filename);
            if (!frame.isNull()) {
                m_greenFrames.append(frame);
            }
        }

        // 加载所有红色帧图片
        for (int i = 1; i <= 6; ++i) {
            QString filename = QString("r%1.png").arg(i, 2, 10, QLatin1Char('0'));
            QPixmap frame(filename);
            if (!frame.isNull()) {
                m_redFrames.append(frame);
            }
        }

        // 设置默认使用绿色帧
        m_frames = m_greenFrames;

        // 创建定时器
        m_timer = new QTimer(this);
        connect(m_timer, &QTimer::timeout, this, [this]() {
            m_currentFrame = (m_currentFrame + 1) % m_frames.size();
            update(); // 触发重绘
        });

        // 每100毫秒切换一帧
        m_timer->start(100);
    }

    // 添加设置颜色的公共方法
    void setRed(bool isRed)
    {
        m_isRed = isRed;
        if (m_isRed) {
            m_frames = m_redFrames;
        } else {
            m_frames = m_greenFrames;
        }
        update(); // 更新显示
    }

    // 添加切换颜色的方法
    void toggleColor()
    {
        setRed(!m_isRed);
    }

    // 获取当前颜色状态
    bool isRed() const
    {
        return m_isRed;
    }

    void paintEvent(QPaintEvent* event)
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 创建圆形裁剪路径
        QPainterPath clipPath;
        int size = qMin(width(), height());
        int margin = 5;
        int diameter = size - 2 * margin;
        int x = (width() - diameter) / 2;
        int y = (height() - diameter) / 2;

        // 添加圆形到裁剪路径
        clipPath.addEllipse(x, y, diameter, diameter);

        // 设置裁剪区域
        painter.setClipPath(clipPath);

        // 如果有加载的帧，绘制当前帧（现在只会显示圆内的部分）
        if (!m_frames.isEmpty()) {
            QPixmap currentFrame = m_frames[m_currentFrame].scaled(
                width(), height(), Qt::KeepAspectRatio, Qt::SmoothTransformation);

            // 居中绘制图片（超出圆形的部分会被裁剪）
            int imgX = (width() - currentFrame.width()) / 2;
            int imgY = (height() - currentFrame.height()) / 2;
            painter.drawPixmap(imgX, imgY, currentFrame);
        }

        // 恢复裁剪区域，否则后面的绘制也会被裁剪
        painter.setClipping(false);

        // 根据当前颜色状态设置圆环颜色
        QPen pen(m_isRed ? QColor::fromString("#F75959") : QColor::fromString("#38CFB9"));
        pen.setWidth(5);
        painter.setPen(pen);
        painter.setBrush(Qt::NoBrush);
        painter.drawEllipse(x, y, diameter, diameter);

        // 输入文字
        painter.setPen(Qt::white);

        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        painter.setFont(font);

        QString text_up = "框架开发";
        QRect textRect1(0, 0, width(), height()-20);
        painter.drawText(textRect1, Qt::AlignCenter, text_up);

        font.setPointSize(15);
        font.setBold(true);
        painter.setFont(font);

        QString text_down = "50%";
        QRect textRect2(0, 0, width(), height()+20);
        painter.drawText(textRect2, Qt::AlignCenter, text_down);
    }
};


/*
class CircularProgress : public QWidget
{
    Q_OBJECT

private:
    int m_powerLevel;
    QTimer *m_timer;
    QVector<QPixmap> m_frames;
    int m_currentFrame = 0;
    bool m_inDesigner; // 添加设计器环境标志

public:
    CircularProgress(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        //this->setStyleSheet("background-color: lightgray;");

        // 检测是否在设计器环境中
        m_inDesigner = false;

        // 方法1：检查父对象是否为设计器组件
        if (parent && parent->objectName().contains("designer", Qt::CaseInsensitive)) {
            m_inDesigner = true;
        }

        // 方法2：检查是否有特定的元对象属性
        QVariant isDesigner = property("_q_designer_metaobject");
        if (isDesigner.isValid()) {
            m_inDesigner = true;
        }

        // 只在没有父窗口且不在设计器中时设置特殊标志
        if (!parent && !m_inDesigner) {
            setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
        }

        setAttribute(Qt::WA_TranslucentBackground);
        resize(100, 100);

        // 加载所有帧图片 - 使用资源系统
        loadFrames();

        // 只在非设计器环境中启动定时器
        if (!m_inDesigner) {
            m_timer = new QTimer(this);
            connect(m_timer, &QTimer::timeout, this, [this]() {
                m_currentFrame = (m_currentFrame + 1) % m_frames.size();
                update();
            });
            m_timer->start(100);
        } else {
            // 设计器环境中使用固定帧
            m_currentFrame = 0;
        }
    }

    // 加载帧图片
    void loadFrames()
    {
        m_frames.clear();

        // 尝试从资源系统加载
        for (int i = 1; i <= 6; ++i) {
            QString resourceName = QString(":/images/%1.png").arg(i, 2, 10, QLatin1Char('0'));
            QPixmap frame(resourceName);

            if (!frame.isNull()) {
                m_frames.append(frame);
                continue;
            }

            // 如果资源加载失败，尝试相对路径（运行时）
            if (!m_inDesigner) {
                QString fileName = QString("%1.png").arg(i, 2, 10, QLatin1Char('0'));
                QPixmap frameFile(fileName);
                if (!frameFile.isNull()) {
                    m_frames.append(frameFile);
                }
            }
        }

        // 如果仍然没有加载到图片，创建默认的彩色圆形作为预览
        if (m_frames.isEmpty() && m_inDesigner) {
            createPreviewFrames();
        }
    }

    // 为设计器创建预览帧
    void createPreviewFrames()
    {
        for (int i = 0; i < 6; ++i) {
            QPixmap frame(50, 50);
            frame.fill(Qt::transparent);

            QPainter painter(&frame);
            painter.setRenderHint(QPainter::Antialiasing);

            // 创建不同颜色的圆形作为预览
            QColor color = QColor::fromHsv(i * 60, 255, 255);
            painter.setBrush(color);
            painter.setPen(Qt::NoPen);
            painter.drawEllipse(5, 5, 40, 40);

            m_frames.append(frame);
        }
    }

    void paintEvent(QPaintEvent* event)
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 设计器预览时绘制背景以便查看
        if (m_inDesigner) {
            painter.fillRect(rect(), QColor(240, 240, 240, 200));
        }

        // 创建圆形裁剪路径
        QPainterPath clipPath;
        int size = qMin(width(), height());
        int margin = 5;
        int diameter = size - 2 * margin;
        int x = (width() - diameter) / 2;
        int y = (height() - diameter) / 2;

        // 添加圆形到裁剪路径
        clipPath.addEllipse(x, y, diameter, diameter);

        // 设置裁剪区域
        painter.setClipPath(clipPath);

        // 绘制当前帧或预览内容
        if (!m_frames.isEmpty()) {
            QPixmap currentFrame = m_frames[m_currentFrame].scaled(
                width(), height(), Qt::KeepAspectRatio, Qt::SmoothTransformation);

            int imgX = (width() - currentFrame.width()) / 2;
            int imgY = (height() - currentFrame.height()) / 2;
            painter.drawPixmap(imgX, imgY, currentFrame);
        } else {
            // 备用绘制
            painter.fillRect(rect(), Qt::blue);
        }

        // 恢复裁剪区域
        painter.setClipping(false);

        // 画圆环
        QPen pen(Qt::green);
        pen.setWidth(3); // 设计器预览时使用较细的线
        painter.setPen(pen);
        painter.setBrush(Qt::NoBrush);
        painter.drawEllipse(x, y, diameter, diameter);

        // 输入文字
        painter.setPen(m_inDesigner ? Qt::black : Qt::white);

        QFont font;
        font.setPointSize(8); // 设计器预览时使用较小的字体
        font.setBold(true);
        painter.setFont(font);

        QString text_up = "框架开发";
        QRect textRect1(0, 0, width(), height() - 15);
        painter.drawText(textRect1, Qt::AlignCenter, text_up);

        font.setPointSize(12);
        painter.setFont(font);

        QString text_down = "50%";
        QRect textRect2(0, 15, width(), height());
        painter.drawText(textRect2, Qt::AlignCenter, text_down);

        // 在设计器环境中显示提示
        if (m_inDesigner && m_frames.isEmpty()) {
            painter.setPen(Qt::red);
            painter.drawText(rect(), Qt::AlignBottom | Qt::AlignHCenter, "Preview Mode");
        }
    }
};
*/
/*
class CircularProgress : public QWidget
{
    Q_OBJECT

private:
    int m_powerLevel;

    QTimer *m_timer;
    QVector<QPixmap> m_frames;
    int m_currentFrame=0;
public:
    CircularProgress(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        // 移除窗口标志或条件性设置
        if (!parent) {
            setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
        }
        setAttribute(Qt::WA_TranslucentBackground);

        resize(100,100);

        // 加载所有帧图片
        for (int i = 1; i <= 6; ++i) {
            QString filename = QString("%1.png").arg(i, 2, 10, QLatin1Char('0'));

            //QMessageBox::information(this, "", filename);

            QPixmap frame(filename);
            if (!frame.isNull()) {
                m_frames.append(frame);
            }
        }

        // 创建定时器
        m_timer = new QTimer(this);
        connect(m_timer, &QTimer::timeout, this, [this]() {
            m_currentFrame = (m_currentFrame + 1) % m_frames.size();
            update(); // 触发重绘
        });

        // 每100毫秒切换一帧
        m_timer->start(100);
    }


    void paintEvent(QPaintEvent* event)
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 创建圆形裁剪路径
        QPainterPath clipPath;
        int size = qMin(width(), height());
        int margin = 5;
        int diameter = size - 2 * margin;
        int x = (width() - diameter) / 2;
        int y = (height() - diameter) / 2;

        // 添加圆形到裁剪路径
        clipPath.addEllipse(x, y, diameter, diameter);

        // 设置裁剪区域
        painter.setClipPath(clipPath);

        // 如果有加载的帧，绘制当前帧（现在只会显示圆内的部分）
        if (!m_frames.isEmpty()) {
            QPixmap currentFrame = m_frames[m_currentFrame];

            // 居中绘制图片（超出圆形的部分会被裁剪）
            int imgX = (width() - currentFrame.width()) / 2;
            int imgY = (height() - currentFrame.height()) / 2;
            painter.drawPixmap(imgX, imgY, currentFrame);
        }

        // 恢复裁剪区域，否则后面的绘制也会被裁剪
        painter.setClipping(false);

        // 画圆环（圆环不需要被裁剪，所以放在取消裁剪后）
        QPen pen(Qt::green);
        pen.setWidth(5);
        painter.setPen(pen);
        painter.setBrush(Qt::NoBrush);
        painter.drawEllipse(x, y, diameter, diameter);

        // 输入文字
        painter.setPen(Qt::white);

        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        painter.setFont(font);

        QString text_up = "框架开发";
        QRect textRect1(0, 0, width(), height()-20);
        painter.drawText(textRect1, Qt::AlignCenter, text_up);

        font.setPointSize(15);
        font.setBold(true);
        painter.setFont(font);

        QString text_down = "50%";
        QRect textRect2(0, 0, width(), height()+20);
        painter.drawText(textRect2, Qt::AlignCenter, text_down);
    }

    // void paintEvent(QPaintEvent* event)
    // {
    //     QPainter painter(this);
    //     painter.setRenderHint(QPainter::Antialiasing);

    //     painter.setRenderHint(QPainter::Antialiasing);

    //     // 如果有加载的帧，绘制当前帧
    //     if (!m_frames.isEmpty()) {
    //         QPixmap currentFrame = m_frames[m_currentFrame];

    //         // 居中绘制图片
    //         int x = (width() - currentFrame.width()) / 2;
    //         int y = (height() - currentFrame.height()) / 2;
    //         painter.drawPixmap(x, y, currentFrame);
    //     }

    //     // 画圆环

    //     // 设置绿色圆环
    //     QPen pen(Qt::green);
    //     pen.setWidth(5); // 圆环宽度
    //     painter.setPen(pen);
    //     painter.setBrush(Qt::NoBrush);

    //     // 计算最大内接圆
    //     int size = qMin(width(), height());
    //     int margin = 5;
    //     int diameter = size - 2 * margin;

    //     // 居中绘制圆环
    //     int x = (width() - diameter) / 2;
    //     int y = (height() - diameter) / 2;

    //     painter.drawEllipse(x, y, diameter, diameter);


    //     // 输入文字

    //     // 输入文字
    //     painter.setPen(Qt::black);

    //     QFont font;
    //     font.setPointSize(10);
    //     font.setBold(true);
    //     painter.setFont(font);

    //     QString text_up = "框架开发";


    //     // 使用QRect来精确居中文本
    //     QRect textRect1(0, 0, width(), height()-20);
    //     painter.drawText(textRect1, Qt::AlignCenter, text_up);



    //     font.setPointSize(15);
    //     font.setBold(true);
    //     painter.setFont(font);

    //     QString text_down = "50%";

    //     // 使用QRect来精确居中文本
    //     QRect textRect2(0, 0, width(), height()+20);
    //     painter.drawText(textRect2, Qt::AlignCenter, text_down);


    // }
};
*/
#endif // CIRCULARPROGRESS_H

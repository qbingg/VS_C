#ifndef RECTANGULARPROGRESS_H
#define RECTANGULARPROGRESS_H

#include <QWidget>
#include <QPixmap>
#include <QTimer>
#include <QVector>
#include <QPainter>

#include <QWidget>
#include <QPainter>

class RectangularProgress : public QWidget
{
    Q_OBJECT

private:
    int m_progress; // 进度值 0-100

public:
    RectangularProgress(QWidget *parent = nullptr)
        : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
        , m_progress(50) // 默认50%进度
    {
        setAttribute(Qt::WA_TranslucentBackground);
        resize(200, 60); // 适合进度条的尺寸
    }

    // 设置进度值
    void setProgress(int progress) {
        m_progress = qBound(0, progress, 100); // 限制在0-100之间
        update();
    }

    int progress() const { return m_progress; }

    void paintEvent(QPaintEvent* event)
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 绘制矩形边框（绿色边）
        QPen borderPen(Qt::green);
        borderPen.setWidth(3); // 边框宽度
        painter.setPen(borderPen);
        painter.setBrush(Qt::NoBrush);

        int borderMargin = 10; // 边框距离窗口边缘的间距
        int borderWidth = width() - 2 * borderMargin;
        int borderHeight = 20; // 进度条高度
        int borderY = (height() - borderHeight) / 2;

        // 绘制矩形边框
        painter.drawRect(borderMargin, borderY, borderWidth, borderHeight);

        // 绘制进度填充（很粗的绿色线）
        int fillMargin = 5; // 填充与边框的间隙
        int fillWidth = (borderWidth - 2 * fillMargin) * m_progress / 100;
        int fillHeight = borderHeight - 2 * fillMargin;
        int fillX = borderMargin + fillMargin;
        int fillY = borderY + fillMargin;

        painter.setPen(Qt::NoPen); // 无边框
        painter.setBrush(Qt::green); // 绿色填充
        painter.drawRect(fillX, fillY, fillWidth, fillHeight);
    }
};


#endif // RECTANGULARPROGRESS_H

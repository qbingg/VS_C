#ifndef SCATTERPLOT_H
#define SCATTERPLOT_H

#include <QWidget>
#include <QPainter>
#include <QVector>
#include <QPointF>
#include <QMouseEvent>
#include <QRandomGenerator>

class ScatterPlot : public QWidget
{
    Q_OBJECT

public:
    struct DataPoint {
        QPointF position;    // 位置 (综合能力, 单项能力)
        QString label;       // 标签
        bool isSelf;         // 是否本人
    };

    explicit ScatterPlot(QWidget *parent = nullptr)
        : QWidget(parent)
        , m_xMin(0), m_xMax(100)
        , m_yMin(0), m_yMax(100)
        , m_hoverPoint(nullptr)
    {
        setMouseTracking(true);
        // 设置默认数据
        setupDefaultData();

        //setStyleSheet("{background-color:#142445;}");
    }

    // 添加数据点
    void addDataPoint(double comprehensiveAbility, double singleAbility, const QString &label, bool isSelf = false) {
        DataPoint point;
        point.position = QPointF(comprehensiveAbility, singleAbility);
        point.label = label;
        point.isSelf = isSelf;
        m_dataPoints.append(point);
        update();
    }

    // 清空数据
    void clearData() {
        m_dataPoints.clear();
        update();
    }

    // 设置坐标轴范围
    void setAxisRange(double xMin, double xMax, double yMin, double yMax) {
        m_xMin = xMin;
        m_xMax = xMax;
        m_yMin = yMin;
        m_yMax = yMax;
        update();
    }

protected:
    void paintEvent(QPaintEvent *event) override {
        Q_UNUSED(event);
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 设置背景
        //painter.fillRect(rect(), QColor(240, 240, 240));

        // 绘制网格（只保留横向白色辅助线）
        drawGrid(painter);

        // 绘制数据点
        drawPoints(painter);

        // 绘制文字标注
        drawLabels(painter);

        // 绘制图例
        drawLegend(painter);

        // 绘制悬停信息
        if (m_hoverPoint) {
            drawHoverInfo(painter);
        }
    }

    void resizeEvent(QResizeEvent *event) override {
        Q_UNUSED(event);
        update();
    }

    void mouseMoveEvent(QMouseEvent *event) override {
        m_mousePos = event->pos();
        m_hoverPoint = nullptr;

        // 检测鼠标是否悬停在数据点上
        for (const DataPoint &point : m_dataPoints) {
            QPointF widgetPos = dataToWidget(point.position);
            QPointF diff = widgetPos - m_mousePos;
            double distance = std::sqrt(diff.x() * diff.x() + diff.y() * diff.y());

            if (distance < 8) { // 悬停半径
                m_hoverPoint = const_cast<DataPoint*>(&point);
                break;
            }
        }

        update();
    }

private:
    QVector<DataPoint> m_dataPoints;
    double m_xMin, m_xMax, m_yMin, m_yMax;
    QPoint m_mousePos;
    DataPoint* m_hoverPoint;

    // 设置默认数据
    void setupDefaultData() {
        QRandomGenerator random;

        // 添加本人数据（橙红色）
        addDataPoint(85, 92, "本人", true);

        // 添加其他人数据（浅蓝色）- 16个点
        for (int i = 0; i < 16; ++i) {
            // 使用整数随机数然后转换为double
            double compAbility = static_cast<double>(random.bounded(300, 950)) / 10.0;
            double singleAbility = static_cast<double>(random.bounded(250, 900)) / 10.0;
            addDataPoint(compAbility, singleAbility, QString("人员%1").arg(i+1), false);
        }
    }

    // 坐标转换：数据坐标 -> 控件坐标
    QPointF dataToWidget(const QPointF &dataPoint) const {
        double x = 60 + (dataPoint.x() - m_xMin) / (m_xMax - m_xMin) * (width() - 80);
        double y = height() - 40 - (dataPoint.y() - m_yMin) / (m_yMax - m_yMin) * (height() - 80);
        return QPointF(x, y);
    }

    // 绘制网格（只保留横向白色辅助线）- 改为5根
    void drawGrid(QPainter &painter) {
        painter.setPen(QPen(Qt::white, 1));

        // 改为5根线（包括顶部和底部的线）
        int lineCount = 5;
        for (int i = 0; i < lineCount; i++) {
            int y = height() - 40 - i * (height() - 80) / (lineCount - 1);
            painter.drawLine(60, y, width() - 20, y);
        }
    }

    // 绘制文字标注
    void drawLabels(QPainter &painter) {
        painter.setPen(QColor(0xDD, 0xCC, 0x8F)); // #DDCC8F
        painter.setFont(QFont("Arial", 12, QFont::Bold));

        // 综合能力文字（底部）
        painter.drawText(QRect(width() / 2 - 40, height() - 30, 80, 20),
                         Qt::AlignCenter, "综合能力");

        // 单项能力文字（左侧，垂直）
        painter.save();
        painter.translate(25, height() / 2);
        painter.rotate(-90);
        painter.drawText(QRect(-100, 0, 200, 20), Qt::AlignCenter, "单项能力");
        painter.restore();
    }

    // 绘制数据点
    void drawPoints(QPainter &painter) {
        for (const DataPoint &point : m_dataPoints) {
            QPointF pos = dataToWidget(point.position);

            if (point.isSelf) {
                // 本人 - 橙红色
                painter.setPen(QPen(QColor(255, 69, 0), 2));
                painter.setBrush(QColor(255, 69, 0));
                painter.drawEllipse(pos, 8, 8);
            } else {
                // 其他人 - 浅蓝色
                painter.setPen(QPen(QColor(100, 149, 237), 1));
                painter.setBrush(QColor(100, 149, 237, 180));
                painter.drawEllipse(pos, 6, 6);
            }
        }
    }

    // 绘制图例
    void drawLegend(QPainter &painter) {
        painter.setPen(QColor(0xDD, 0xCC, 0x8F)); // 使用相同的颜色
        painter.setFont(QFont("Arial", 9));

        // 本人图例
        painter.setPen(QPen(QColor(255, 69, 0), 2));
        painter.setBrush(QColor(255, 69, 0));
        painter.drawEllipse(QRectF(width() - 120, 20, 10, 10));
        painter.setPen(QColor(0xDD, 0xCC, 0x8F));
        painter.drawText(QRect(width() - 105, 15, 100, 20), "本人");

        // 其他人图例
        painter.setPen(QPen(QColor(100, 149, 237), 1));
        painter.setBrush(QColor(100, 149, 237, 180));
        painter.drawEllipse(QRectF(width() - 120, 45, 8, 8));
        painter.setPen(QColor(0xDD, 0xCC, 0x8F));
        painter.drawText(QRect(width() - 105, 40, 100, 20), "其他人");
    }

    // 绘制悬停信息
    void drawHoverInfo(QPainter &painter) {
        if (!m_hoverPoint) return;

        QPointF pos = dataToWidget(m_hoverPoint->position);
        QString info = QString("%1\n综合: %2\n单项: %3")
                           .arg(m_hoverPoint->label)
                           .arg(m_hoverPoint->position.x(), 0, 'f', 1)
                           .arg(m_hoverPoint->position.y(), 0, 'f', 1);

        painter.setPen(QColor(0xDD, 0xCC, 0x8F));
        painter.setBrush(QColor(255, 255, 225));
        painter.setFont(QFont("Arial", 8));

        QRect textRect = painter.fontMetrics().boundingRect(QRect(0, 0, 100, 60), Qt::AlignLeft, info);
        textRect.moveTo(pos.x() + 10, pos.y() - textRect.height() / 2);

        painter.drawRect(textRect.adjusted(-5, -5, 5, 5));
        painter.drawText(textRect, info);
    }
};

/*
class ScatterPlot : public QWidget
{
    Q_OBJECT

public:
    struct DataPoint {
        QPointF position;    // 位置 (综合能力, 单项能力)
        QString label;       // 标签
        bool isSelf;         // 是否本人
    };

    explicit ScatterPlot(QWidget *parent = nullptr)
        : QWidget(parent)
        , m_xMin(0), m_xMax(100)
        , m_yMin(0), m_yMax(100)
        , m_hoverPoint(nullptr)
    {
        setMouseTracking(true);
        // 设置默认数据
        setupDefaultData();
    }

    // 添加数据点
    void addDataPoint(double comprehensiveAbility, double singleAbility, const QString &label, bool isSelf = false) {
        DataPoint point;
        point.position = QPointF(comprehensiveAbility, singleAbility);
        point.label = label;
        point.isSelf = isSelf;
        m_dataPoints.append(point);
        update();
    }

    // 清空数据
    void clearData() {
        m_dataPoints.clear();
        update();
    }

    // 设置坐标轴范围
    void setAxisRange(double xMin, double xMax, double yMin, double yMax) {
        m_xMin = xMin;
        m_xMax = xMax;
        m_yMin = yMin;
        m_yMax = yMax;
        update();
    }

protected:
    void paintEvent(QPaintEvent *event) override {
        Q_UNUSED(event);
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 设置背景
        painter.fillRect(rect(), QColor(240, 240, 240));

        // 绘制坐标轴和网格
        drawGrid(painter);
        drawAxis(painter);

        // 绘制数据点
        drawPoints(painter);

        // 绘制图例
        drawLegend(painter);

        // 绘制悬停信息
        if (m_hoverPoint) {
            drawHoverInfo(painter);
        }
    }

    void resizeEvent(QResizeEvent *event) override {
        Q_UNUSED(event);
        update();
    }

    void mouseMoveEvent(QMouseEvent *event) override {
        m_mousePos = event->pos();
        m_hoverPoint = nullptr;

        // 检测鼠标是否悬停在数据点上
        for (const DataPoint &point : m_dataPoints) {
            QPointF widgetPos = dataToWidget(point.position);
            QPointF diff = widgetPos - m_mousePos;
            double distance = std::sqrt(diff.x() * diff.x() + diff.y() * diff.y());

            if (distance < 8) { // 悬停半径
                m_hoverPoint = const_cast<DataPoint*>(&point);
                break;
            }
        }

        update();
    }

private:
    QVector<DataPoint> m_dataPoints;
    double m_xMin, m_xMax, m_yMin, m_yMax;
    QPoint m_mousePos;
    DataPoint* m_hoverPoint;

    // 设置默认数据
    void setupDefaultData() {
        QRandomGenerator random;

        // 添加本人数据（橙红色）
        addDataPoint(85, 92, "本人", true);

        // 添加其他人数据（浅蓝色）- 16个点
        for (int i = 0; i < 16; ++i) {
            // 使用static_cast明确指定类型
            double compAbility = static_cast<double>(random.generateDouble()) * 65.0 + 30.0;
            double singleAbility = static_cast<double>(random.generateDouble()) * 65.0 + 25.0;
            addDataPoint(compAbility, singleAbility, QString("人员%1").arg(i+1), false);
        }
    }

    // 坐标转换：数据坐标 -> 控件坐标
    QPointF dataToWidget(const QPointF &dataPoint) const {
        double x = 60 + (dataPoint.x() - m_xMin) / (m_xMax - m_xMin) * (width() - 80);
        double y = height() - 40 - (dataPoint.y() - m_yMin) / (m_yMax - m_yMin) * (height() - 80);
        return QPointF(x, y);
    }

    // 绘制坐标轴
    void drawAxis(QPainter &painter) {
        painter.setPen(QPen(Qt::black, 2));

        // X轴（综合能力）
        painter.drawLine(60, height() - 40, width() - 20, height() - 40);
        painter.drawText(QRect(width() / 2 - 40, height() - 25, 80, 20), Qt::AlignCenter, "综合能力");

        // Y轴（单项能力）
        painter.drawLine(60, 20, 60, height() - 40);
        painter.save();
        painter.translate(20, height() / 2);
        painter.rotate(-90);
        painter.drawText(QRect(-100, 0, 200, 20), Qt::AlignCenter, "单项能力");
        painter.restore();

        // 刻度
        painter.setPen(QPen(Qt::black, 1));
        for (int i = 0; i <= 10; i++) {
            double value = m_xMin + (m_xMax - m_xMin) * i / 10.0;
            int x = 60 + i * (width() - 80) / 10;
            painter.drawLine(x, height() - 40, x, height() - 35);
            painter.drawText(QRect(x - 20, height() - 35, 40, 20), Qt::AlignCenter, QString::number(value));

            value = m_yMin + (m_yMax - m_yMin) * i / 10.0;
            int y = height() - 40 - i * (height() - 80) / 10;
            painter.drawLine(60, y, 55, y);
            painter.drawText(QRect(30, y - 10, 25, 20), Qt::AlignCenter, QString::number(value));
        }
    }

    // 绘制网格
    void drawGrid(QPainter &painter) {
        painter.setPen(QPen(QColor(200, 200, 200), 1));

        for (int i = 1; i < 10; i++) {
            int x = 60 + i * (width() - 80) / 10;
            painter.drawLine(x, 20, x, height() - 40);

            int y = height() - 40 - i * (height() - 80) / 10;
            painter.drawLine(60, y, width() - 20, y);
        }
    }

    // 绘制数据点
    void drawPoints(QPainter &painter) {
        for (const DataPoint &point : m_dataPoints) {
            QPointF pos = dataToWidget(point.position);

            if (point.isSelf) {
                // 本人 - 橙红色
                painter.setPen(QPen(QColor(255, 69, 0), 2));
                painter.setBrush(QColor(255, 69, 0));
                painter.drawEllipse(pos, 8, 8);
            } else {
                // 其他人 - 浅蓝色
                painter.setPen(QPen(QColor(100, 149, 237), 1));
                painter.setBrush(QColor(100, 149, 237, 180));
                painter.drawEllipse(pos, 6, 6);
            }
        }
    }

    // 绘制图例
    void drawLegend(QPainter &painter) {
        painter.setPen(Qt::black);
        painter.setFont(QFont("Arial", 9));

        // 本人图例
        painter.setPen(QPen(QColor(255, 69, 0), 2));
        painter.setBrush(QColor(255, 69, 0));
        painter.drawEllipse(QRectF(width() - 120, 20, 10, 10));
        painter.setPen(Qt::black);
        painter.drawText(QRect(width() - 105, 15, 100, 20), "本人");

        // 其他人图例
        painter.setPen(QPen(QColor(100, 149, 237), 1));
        painter.setBrush(QColor(100, 149, 237, 180));
        painter.drawEllipse(QRectF(width() - 120, 45, 8, 8));
        painter.setPen(Qt::black);
        painter.drawText(QRect(width() - 105, 40, 100, 20), "其他人");
    }

    // 绘制悬停信息
    void drawHoverInfo(QPainter &painter) {
        if (!m_hoverPoint) return;

        QPointF pos = dataToWidget(m_hoverPoint->position);
        QString info = QString("%1\n综合: %2\n单项: %3")
                           .arg(m_hoverPoint->label)
                           .arg(m_hoverPoint->position.x(), 0, 'f', 1)
                           .arg(m_hoverPoint->position.y(), 0, 'f', 1);

        painter.setPen(Qt::black);
        painter.setBrush(QColor(255, 255, 225));
        painter.setFont(QFont("Arial", 8));

        QRect textRect = painter.fontMetrics().boundingRect(QRect(0, 0, 100, 60), Qt::AlignLeft, info);
        textRect.moveTo(pos.x() + 10, pos.y() - textRect.height() / 2);

        painter.drawRect(textRect.adjusted(-5, -5, 5, 5));
        painter.drawText(textRect, info);
    }
};
*/
#endif // SCATTERPLOT_H

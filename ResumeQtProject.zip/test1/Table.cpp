#include "Table.h"
#include "ui_Table.h"

#include <QStandardItemModel>

Table::Table(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Table)
{
    ui->setupUi(this);

    ui->comboBox->addItem("202501");
    ui->comboBox->addItem("202502");
    ui->comboBox->addItem("202503");

    ui->comboBox_2->addItem("张三");
    ui->comboBox_2->addItem("李四");
    ui->comboBox_2->addItem("王五");

    // 创建模型，10列（序号+复选框列合并，后面8列）
    QStandardItemModel *m_pModel = new QStandardItemModel(0, 9);

    // 设置水平表头标签
    m_pModel->setHorizontalHeaderLabels(QStringList()
                                        << "序号" // 第一列：序号+复选框
                                        << "姓名"
                                        << "期数"
                                        << "工作内容1"
                                        << "工作内容2"
                                        << "工作内容3"
                                        << "任务绩效1"
                                        << "任务绩效2"
                                        << "操作");

    // 插入三条示例数据
    for (int row = 0; row < 3; ++row) {
        QList<QStandardItem*> rowItems;

        // 第一列：序号+复选框
        QStandardItem* itemIndex = new QStandardItem(QString::number(row + 1));
        itemIndex->setCheckable(true); // 设置为可勾选
        itemIndex->setCheckState(Qt::Unchecked); // 默认未选中
        itemIndex->setTextAlignment(Qt::AlignCenter); // 居中对齐
        rowItems.append(itemIndex);

        // 第二列：姓名
        QStandardItem* itemName = new QStandardItem(QString("人员%1").arg(row + 1));
        itemName->setTextAlignment(Qt::AlignCenter);
        rowItems.append(itemName);

        // 第三列：期数
        QStandardItem* itemPeriod = new QStandardItem(QString("第%1期").arg(row + 1));
        itemPeriod->setTextAlignment(Qt::AlignCenter);
        rowItems.append(itemPeriod);

        // 工作内容列
        for (int i = 1; i <= 3; ++i) {
            QStandardItem* itemWork = new QStandardItem(QString("工作内容%1").arg(i));
            itemWork->setTextAlignment(Qt::AlignCenter);
            rowItems.append(itemWork);
        }

        // 任务绩效列
        for (int i = 1; i <= 2; ++i) {
            QStandardItem* itemPerformance = new QStandardItem(QString("绩效%1").arg(i));
            itemPerformance->setTextAlignment(Qt::AlignCenter);
            rowItems.append(itemPerformance);
        }

        // 操作列
        // 在表格中直接使用QPushButton
        // 修改操作列的创建代码：
        QStandardItem* itemAction = new QStandardItem("");
        itemAction->setEditable(false);
        rowItems.append(itemAction);
        // QStandardItem* itemAction = new QStandardItem("编辑");
        // itemAction->setTextAlignment(Qt::AlignCenter);
        // rowItems.append(itemAction);

        // 添加行到模型
        m_pModel->appendRow(rowItems);
    }

    // 将模型设置到tableView
    ui->tableView->setModel(m_pModel);

    // 在所有行添加完成后，为每一行的最后一列设置按钮
    // for (int row = 0; row < m_pModel->rowCount(); ++row) {
    //     QPushButton *insertButton = new QPushButton("插入");
    //     insertButton->setStyleSheet("color: white; background-color: #3F99D5; border-radius: 4px; border: none; padding: 2px 8px;");
    //     ui->tableView->setIndexWidget(m_pModel->index(row, 8), insertButton);
    //
    //     connect(insertButton, &QPushButton::clicked, this, [this, row]() {
    //         qDebug() << "插入按钮被点击，行号:" << row;
    //         //QMessageBox::information(this, "提示", QString("插入第%1行数据").arg(row + 1));
    //     });
    // }
    // 在所有行添加完成后，为每一行的最后一列设置按钮
    for (int row = 0; row < m_pModel->rowCount(); ++row) {
        QPushButton *insertButton = new QPushButton("插入");

        // 设置紧凑样式
        insertButton->setStyleSheet(
            "QPushButton {"
            "    color: white;"
            "    background-color: #3F99D5;"
            "    border-radius: 4px;"
            "    border: none;"
            "    padding: 0px 4px;"  // 最小内边距
            "    margin: 1px;"       // 最小外边距
            "}"
            "QPushButton:hover {"
            "    background-color: #2A7BB8;"
            "}"
            "QPushButton:pressed {"
            "    background-color: #1A5A8C;"
            "}"
            );

        // 根据文字内容计算合适的大小
        QFontMetrics metrics(insertButton->font());
        int textWidth = metrics.horizontalAdvance("插入") + 12; // 文字宽度 + 边距
        int textHeight = metrics.height() + 4; // 文字高度 + 边距

        insertButton->setFixedSize(textWidth, textHeight);

        ui->tableView->setIndexWidget(m_pModel->index(row, 8), insertButton);

        connect(insertButton, &QPushButton::clicked, this, [this, row]() {
            qDebug() << "插入按钮被点击，行号:" << row;
            //QMessageBox::information(this, "提示", QString("插入第%1行数据").arg(row + 1));
        });
    }

    // 设置表格属性
    ui->tableView->horizontalHeader()->setStretchLastSection(true); // 最后一列拉伸
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); // 整行选择
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers); // 不可编辑
    ui->tableView->verticalHeader()->setVisible(false);// 去掉最左边的行号列（垂直表头）

    // 调整列宽
    ui->tableView->setColumnWidth(0, 60); // 序号列稍宽以容纳复选框
    for (int col = 1; col < 8; ++col) {
        ui->tableView->setColumnWidth(col, 100);
    }
}

Table::~Table()
{
    delete ui;
}

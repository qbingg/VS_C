#ifndef VERTICALPROGRESS_H
#define VERTICALPROGRESS_H

#include <QWidget>
#include <QPainter>

class VerticalProgress : public QWidget
{
    Q_OBJECT

private:
    int m_progress; // 进度值 0-100
    QColor m_fillColor; // 填充颜色
    const int m_borderWidth = 1;   // 固定边框宽度（像素）
    const int m_fillMargin = 1;    // 固定填充间隙（像素）

public:
    VerticalProgress(QWidget *parent = nullptr)
        : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
        , m_progress(80) // 默认80%进度
        , m_fillColor(QColor::fromString("#43D0C0")) // 默认填充颜色为绿色
    {
        setAttribute(Qt::WA_TranslucentBackground);
        //resize(30, 200); // 更窄的宽度以适应细边框
    }

    // 设置进度值
    void setProgress(int progress) {
        m_progress = qBound(0, progress, 100);
        update();
    }

    int progress() const { return m_progress; }

    // 设置填充颜色（边框保持绿色）
    void setFillColor(const QColor &color) {
        m_fillColor = color;
        update();
    }

    // 获取填充颜色
    QColor fillColor() const { return m_fillColor; }

protected:
    void paintEvent(QPaintEvent* event) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 计算边框和填充区域（基于固定像素值）
        int totalBorderThickness = m_borderWidth;
        int totalMargin = totalBorderThickness + m_fillMargin;

        // 边框矩形（占满整个控件，减去边框宽度的一半以避免裁剪）
        QRect borderRect(totalBorderThickness / 2,
                         totalBorderThickness / 2,
                         width() - totalBorderThickness,
                         height() - totalBorderThickness);

        // 绘制矩形边框（绿色细边）- 边框颜色固定为绿色
        QPen borderPen(QColor::fromString("#42B1DF"));
        borderPen.setWidth(m_borderWidth); // 固定边框宽度
        painter.setPen(borderPen);
        painter.setBrush(Qt::NoBrush);
        painter.drawRect(borderRect);

        // 计算填充区域（随窗口尺寸变化）
        int fillWidth = width() - 2 * totalMargin;
        int fillHeight = (height() - 2 * totalMargin) * m_progress / 100;

        // 从底部开始填充（进度从下往上增长）
        int fillX = totalMargin;
        int fillY = height() - totalMargin - fillHeight; // 从底部计算Y坐标

        // 绘制进度填充（使用可配置的颜色）
        painter.setPen(Qt::NoPen);
        painter.setBrush(m_fillColor);

        // 只有当填充区域有效时才绘制
        if (fillWidth > 0 && fillHeight > 0) {
            painter.drawRect(fillX, fillY, fillWidth, fillHeight);
        }
    }

    // 可选：添加尺寸变化时的处理
    void resizeEvent(QResizeEvent* event) override
    {
        update(); // 窗口尺寸变化时重绘
        QWidget::resizeEvent(event);
    }
};
#endif // VERTICALPROGRESS_H

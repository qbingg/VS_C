#include "CircularProgress.h"
#include "RectangularProgress.h"
#include "ScatterPlot.h"
#include "Table.h"
#include "VerticalProgress.h"
#include "widget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // // 在你的主窗口中创建散点图
    // ScatterPlot *scatterPlot = new ScatterPlot();
    // //scatterPlot->setFixedSize(600, 500);
    // // 也可以动态添加数据点（可选）
    // scatterPlot->addDataPoint(88, 95, "新人员", false);
    // // 设置坐标轴范围（可选）
    // scatterPlot->setAxisRange(0, 100, 0, 100);
    // scatterPlot->show();

    // CircularProgress ci;
    // // 设置为红色
    // ci.setRed(true);
    // ci.show();

    // RectangularProgress re;
    // re.show();
    // re.setProgress(75); // 设置75%进度

    // VerticalProgress *progressBar = new VerticalProgress;
    // progressBar->show();
    // progressBar->setProgress(75); // 设置75%进度

    Table t;
    t.show();

    Widget w;
    w.show();
    return a.exec();
}

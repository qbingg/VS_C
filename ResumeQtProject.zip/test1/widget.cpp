#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    setWindowTitle("游戏软件开发系统");

    //resize(1000,500);

    //setStyleSheet("background-color:#142445");

    // for(int i =0 ;i<6;i++)
    // {
    //     cirProgress[i]= new CircularProgress(this);

    //     cirProgress[i]->move(i*110+25,25);
    // }

    // for(int i =0 ;i<16;i++)
    // {
    //     progressBar[i] = new VerticalProgress(this);

    //     progressBar[i]->setProgress((i/static_cast<double>(16))*100);

    //     progressBar[i]->move(i*40+25,150);
    // }

    ui->widget_13->setRed(true);
    ui->widget_16->setRed(true);
    ui->widget_15->setRed(true);

    ui->widget_25->setFillColor(QColor::fromString("#EF5F15"));
    ui->widget_25->setProgress(70);

    ui->widget_26->setFillColor(QColor::fromString("#A436F5"));
    ui->widget_26->setProgress(60);

    ui->widget_28->setFillColor(QColor::fromString("#C34666"));
    ui->widget_28->setProgress(50);

    ui->widget_27->setFillColor(QColor::fromString("#5C5CF0"));
    ui->widget_27->setProgress(40);
}

Widget::~Widget()
{
    delete ui;
}

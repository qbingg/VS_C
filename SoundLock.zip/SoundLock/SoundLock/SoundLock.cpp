﻿//#include <windows.h>  
//#include <mmdeviceapi.h>  
//#include <endpointvolume.h>  
//#include <stdio.h>
//
//#pragma comment(lib, "ole32.lib")  
//
//int main() {
//    HRESULT hr = CoInitialize(NULL);
//    if (FAILED(hr)) {
//        // 错误处理  
//        return 1;
//    }
//
//    IMMDeviceEnumerator* pEnumerator = NULL;
//    IMMDevice* pDefaultDevice = NULL;
//    IAudioEndpointVolume* pEndpointVolume = NULL;
//
//    // 创建设备枚举器  
//    hr = CoCreateInstance(CLSID_MMDeviceEnumerator, NULL, CLSCTX_ALL, IID_IMMDeviceEnumerator, (void**)&pEnumerator);
//    if (FAILED(hr)) {
//        // 错误处理  
//        //goto cleanup;
//    }
//
//    // 获取默认音频渲染设备  
//    hr = pEnumerator->GetDefaultAudioEndpoint(eRender, eConsole, &pDefaultDevice);
//    if (FAILED(hr)) {
//        // 错误处理  
//        //goto cleanup;
//    }
//
//    // 激活IAudioEndpointVolume接口  
//    hr = pDefaultDevice->Activate(IID_IAudioEndpointVolume, CLSCTX_ALL, NULL, (void**)&pEndpointVolume);
//    if (FAILED(hr)) {
//        // 错误处理  
//        //goto cleanup;
//    }
//
//    // 获取音量级别  
//    float volumeLevel = 0.0f;
//    hr = pEndpointVolume->GetMasterVolumeLevelScalar(&volumeLevel);
//    if (SUCCEEDED(hr)) {
//        // 成功获取音量级别，可以使用volumeLevel变量  
//        // 例如：打印音量级别  
//        printf("Volume Level: %f\n", volumeLevel);
//    }
//    else {
//        // 错误处理  
//    }
//
//cleanup:
//    // 释放资源  
//    if (pEndpointVolume) {
//        pEndpointVolume->Release();
//    }
//    if (pDefaultDevice) {
//        pDefaultDevice->Release();
//    }
//    if (pEnumerator) {
//        pEnumerator->Release();
//    }
//    CoUninitialize();
//
//    return 0;
//}






#include <windows.h>  
#include <mmdeviceapi.h>  
#include <endpointvolume.h>  
#include <stdio.h>
#include <Audioclient.h>

int main()
{
    //system("control.exe /name Microsoft.AudioDevicesAndSoundThemes");

    CoInitialize(NULL);

    HRESULT hr;

	IMMDeviceEnumerator* pDeviceEnumerator = NULL;
    IMMDevice* pDevice = NULL;
    IAudioEndpointVolume* pEndpointVolume = NULL;
    IAudioClient* pAudioClient = NULL;

    hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), NULL, CLSCTX_ALL,__uuidof(IMMDeviceEnumerator), (void**)&pDeviceEnumerator);

    hr = pDeviceEnumerator->GetDefaultAudioEndpoint(eRender, eMultimedia, &pDevice);

    hr = pDevice->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_ALL, NULL, (void**)&pEndpointVolume);

    hr = pDevice->Activate(__uuidof(IAudioClient), CLSCTX_ALL, NULL, (void**)&pAudioClient);

    //静音
    //hr = pEndpointVolume->SetMute(TRUE, NULL);

    //取消静音
    //hr = pEndpointVolume->SetMute(FALSE, NULL);

    // 获取音量级别  
    float volumeLevel = 0.0f;
    hr = pEndpointVolume->GetMasterVolumeLevelScalar(&volumeLevel);
    hr = pEndpointVolume->SetMasterVolumeLevelScalar((volumeLevel / 2),NULL);
    //hr = pEndpointVolume->GetMasterVolumeLevel(&volumeLevel);
    if (SUCCEEDED(hr)) {
        // 成功获取音量级别，可以使用volumeLevel变量  
        // 例如：打印音量级别  
        printf("Volume Level: %f\n", volumeLevel);
    }
    //float min, max, range;
    //hr = pEndpointVolume->GetVolumeRange(&min, &max, &range);
    //printf("min: %f\n", min);
    //printf("max: %f\n", max);
    //printf("range: %f\n", range);


    CoUninitialize();
}








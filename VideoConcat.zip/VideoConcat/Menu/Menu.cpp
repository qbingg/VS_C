#include "Menu.h"
#include "ui_Menu.h"

Menu::Menu(QWidget *parent)
    : QWidget(parent)//QWidget(parent,Qt::WindowStaysOnTopHint)//窗口置顶
    , ui(new Ui::Menu)
{

    setWindowFlags(Qt::WindowStaysOnTopHint);//窗口置顶

    move(0,0);//移动到左上角

    ui->setupUi(this);

    setAcceptDrops(true);// 开启对整个窗口的拖放操作的支持

    //setWindowTitle("合并视频（不转码）");
    setWindowTitle("请将视频拖拽到窗口...");

    m_pModel= new QStandardItemModel();// 20行 5列

    m_pModel->setHorizontalHeaderLabels(QStringList()<<"视频文件地址");//设置列名

    ui->tableView->setModel(m_pModel);//tableView绑定model

    ui->tableView->setAlternatingRowColors(true);//隔行变色

    ui->tableView->horizontalHeader()->setStretchLastSection(true);//拉伸最右一列至贴边

    //connect(ui->btnConcat,SIGNAL(clicked()),this,SLOT(slot_btnConcat()));
    /*
    qt.core.qobject.connect: QObject::connect: No such slot Menu::slot_btnConcat()
    qt.core.qobject.connect: QObject::connect:  (sender name:   'btnConcat')
    qt.core.qobject.connect: QObject::connect:  (receiver name: 'Menu')
    为什么在这里用不了，明明是从其它项目直接复制过来的
    */
    connect(ui->btnConcat, &QPushButton::clicked, this, &Menu::slot_btnConcat);


}

Menu::~Menu()
{
    delete ui;
}

void Menu::dragEnterEvent(QDragEnterEvent * event)
{
    if (event->mimeData()->hasUrls())
    {
        event->acceptProposedAction(); // 接受默认的拖放行为
    }
}

void Menu::dropEvent(QDropEvent* event)
{
    QList<QUrl> urls = event->mimeData()->urls();
    for (const QUrl& url : urls)
    {
        //添加到model中  （因为只有一列信息，不用QList<QStandardItem*> rowItem;，直接加到model里）
        QStandardItem* itemFileInfo = new QStandardItem(QString(QFileInfo(url.toLocalFile()).absoluteFilePath()));
        itemFileInfo->setCheckable(true);//复选框，问了ai，这个好像没有单选框
        m_pModel->appendRow(itemFileInfo);

        //将名字和后缀复制到"输出文件名"中
        ui->outputFilename->setText(QString(QFileInfo(url.toLocalFile()).absolutePath())+"/"+QString(QFileInfo(url.toLocalFile()).baseName())+ "_");
        ui->suffix->setText("."+QString(QFileInfo(url.toLocalFile()).suffix()));
    }

    //换回标题
    setWindowTitle("合并视频（不转码）");
}

bool Menu::slot_btnConcat(bool checked)
{
    //获取model的行
    if(m_pModel->rowCount() == 0)
    {
        QMessageBox::information(this, "", "请拖入要合并的视频");
        return false;
    }
    QStringList fileInfoList;
    for (int row = 0; row < m_pModel->rowCount(); ++row)
    {
        QModelIndex Index = m_pModel->index(row, 0);
        QString fileInfo = Index.data().toString();

        fileInfoList.append(fileInfo);
    }
    //写到filelist.txt
    // 打开输出文件流
    std::ofstream outputFile("filelist.txt");
    // 检查文件是否成功打开
    if (!outputFile.is_open())
    {
        QMessageBox::warning(this, "", "无法打开filelist.txt！");
        return 1;
    }
    // 将文件名写入到输出文件中
    for (QString fileInfo : fileInfoList)
    {
        outputFile <<"file "<<"\'"<< fileInfo.toStdString() <<"\'"<< std::endl;
    }

    // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
    //ffmpeg -f concat -safe 0 -i file_list.txt -c copy output.mp4
    // QString QffmpegCmd =
    //     "ffmpeg -f concat -safe 0 -i filelist.txt -c copy " +
    //     ui->outputFilename->text() + ui->suffix->text();

    //构建命令
    // QStringList arguments;
    // arguments << "-f concat -safe 0 -i filelist.txt -c copy"//一长串字符串无法识别命令
    //           << ui->outputFilename->text() + ui->suffix->text();
    QStringList arguments;
    arguments <<"-f"<<"concat"<<"-safe"<<"0"<<"-i"<<"filelist.txt"<<"-c"<<"copy"
              << ui->outputFilename->text() + ui->suffix->text();

    // 确认命令
    // 显示带有问号的弹窗
    // 完整的命令行
    QString fullCommand =  "ffmpeg " + arguments.join(" ");
    QMessageBox::StandardButton answer = QMessageBox::question(nullptr, "剪辑", fullCommand, QMessageBox::Yes | QMessageBox::No);
    // 根据用户的选择，输出结果
    if (answer == QMessageBox::No)
    {
        return false;
    }

    // 检查输出文件是否已存在
    // ffmpeg会提问是否覆盖，而QProcess调用不会有命令行窗口，无法直接与ffmpeg交互
    // 除非输入-y直接覆盖输出文件，否则程序会卡住
    QString outputFilePath = ui->outputFilename->text() + ui->suffix->text();
    if (QFile::exists(outputFilePath)) {
        // 显示提示框，通知用户文件已存在
        QMessageBox::warning(nullptr, "文件已存在", "输出文件已存在，操作已取消。");
        return false;
    }

    //执行FFmpeg命令

    //执行命令
    //创建一个 QProcess 对象，并将其父对象设置为当前对象（this），以便在父对象销毁时自动清理 QProcess 对象。
    /*
     * 异步操作：
    在 Qt 中，QProcess 本身并不需要显式地使用 QThread 来实现异步操作。
    QProcess 的异步行为是通过事件循环（event loop）机制实现的，而不是通过线程。

    非阻塞调用：
    start() 方法是一个非阻塞调用。它立即返回，而不会等待外部进程完成。
    进程在后台运行，由操作系统管理。
    信号和槽：
    QProcess 使用信号和槽机制来通知应用程序进程状态的变化。
    例如，finished 信号在进程结束时触发，errorOccurred 信号在进程出错时触发。
    这些信号被连接到槽函数或 Lambda 表达式，以异步处理结果。
    事件循环：
    Qt 的事件循环负责监听和分发这些信号。
    即使没有显式使用 QThread，事件循环也会在后台运行，等待外部进程完成或出错。
*/
    QProcess *ffmpegProcess = new QProcess(this);
    //连接 finished 信号
    //使用 Lambda 表达式处理信号
    connect(ffmpegProcess, &QProcess::finished, [=](int exitCode, QProcess::ExitStatus exitStatus) {
        if (exitStatus == QProcess::NormalExit && exitCode == 0) {
            qDebug() << "Video concat successfully!";
            QMessageBox::information(this, "", "合并成功");
        } else {
            qDebug() << "Error occurred:" << ffmpegProcess->readAllStandardError();
        }
        ffmpegProcess->deleteLater();
    });

    connect(ffmpegProcess, QOverload<QProcess::ProcessError>::of(&QProcess::errorOccurred),
            [=](QProcess::ProcessError error) {
                qDebug() << "Process error:" << error;
                ffmpegProcess->deleteLater();
            });

    ffmpegProcess->start("ffmpeg", arguments);




    return false;
}

#ifndef MENU_H
#define MENU_H

#include <QStandardItemModel>
#include <QWidget>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QList>
#include <QUrl>
#include <QVector>
#include <QFileInfo>
#include <QMimeData>
#include <qmessagebox.h>
#include <QProcess>
#include <fstream>

QT_BEGIN_NAMESPACE
namespace Ui {
class Menu;
}
QT_END_NAMESPACE

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();

private:
    Ui::Menu *ui;

    QStandardItemModel *m_pModel;


protected:
    // 重写父类事件方法
    // 当拖拽对象进入窗口时调用
    void dragEnterEvent(QDragEnterEvent* event) override;
    // 当拖放对象在窗口内释放时调用
    void dropEvent(QDropEvent* event) override;

private slots:
    // 选择文件
    bool slot_btnConcat(bool checked);

};
#endif // MENU_H

﻿#include <iostream>
#include <fstream>
#include <vector>

int main() {
    // 文件名列表
    std::vector<std::string> videoFiles = { "video4.mp4", "video5.mp4", "video6.mp4" };

    // 打开输出文件流
    std::ofstream outputFile("output.txt");

    // 检查文件是否成功打开
    if (!outputFile.is_open()) {
        std::cerr << "无法打开输出文件！" << std::endl;
        return 1;
    }

    // 将文件名写入到输出文件中
    for (const auto& fileName : videoFiles) {
        outputFile << fileName << std::endl;
    }

    // 关闭输出文件流
    outputFile.close();

    std::cout << "文件名已成功写入到 output.txt 文件中。" << std::endl;

    return 0;
}
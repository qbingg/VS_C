#include "Menu.h"
#include "ui_Menu.h"

Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);

    setAcceptDrops(true);// 开启对整个窗口的拖放操作的支持

    setWindowTitle("合并视频（不转码）");

    m_pModel= new QStandardItemModel();// 20行 5列

    m_pModel->setHorizontalHeaderLabels(QStringList()<<"视频文件地址");//设置列名

    ui->tableView->setModel(m_pModel);//tableView绑定model

    ui->tableView->setAlternatingRowColors(true);//隔行变色

    ui->tableView->horizontalHeader()->setStretchLastSection(true);//拉伸最右一列至贴边

    //connect(ui->btnConcat,SIGNAL(clicked()),this,SLOT(slot_btnConcat()));
    /*
    qt.core.qobject.connect: QObject::connect: No such slot Menu::slot_btnConcat()
    qt.core.qobject.connect: QObject::connect:  (sender name:   'btnConcat')
    qt.core.qobject.connect: QObject::connect:  (receiver name: 'Menu')
    为什么在这里用不了，明明是从其它项目直接复制过来的
    */
    connect(ui->btnConcat, &QPushButton::clicked, this, &Menu::slot_btnConcat);


}

Menu::~Menu()
{
    delete ui;
}

void Menu::dragEnterEvent(QDragEnterEvent * event)
{
    if (event->mimeData()->hasUrls())
    {
        event->acceptProposedAction(); // 接受默认的拖放行为
    }
}

void Menu::dropEvent(QDropEvent* event)
{
    QList<QUrl> urls = event->mimeData()->urls();
    for (const QUrl& url : urls)
    {
        //添加到model中  （因为只有一列信息，不用QList<QStandardItem*> rowItem;，直接加到model里）
        QStandardItem* itemFileInfo = new QStandardItem(QString(QFileInfo(url.toLocalFile()).absoluteFilePath()));
        itemFileInfo->setCheckable(true);//复选框，问了ai，这个好像没有单选框
        m_pModel->appendRow(itemFileInfo);

        //将名字和后缀复制到"输出文件名"中
        ui->outputFilename->setText(QString(QFileInfo(url.toLocalFile()).absolutePath())+"/"+QString(QFileInfo(url.toLocalFile()).baseName())+ "_");
        ui->suffix->setText("."+QString(QFileInfo(url.toLocalFile()).suffix()));
    }
}

bool Menu::slot_btnConcat(bool checked)
{
    //获取model的行
    if(m_pModel->rowCount() == 0)
    {
        QMessageBox::information(this, "", "请拖入要合并的视频");
        return false;
    }
    QStringList fileInfoList;
    for (int row = 0; row < m_pModel->rowCount(); ++row)
    {
        QModelIndex Index = m_pModel->index(row, 0);
        QString fileInfo = Index.data().toString();

        fileInfoList.append(fileInfo);
    }
    //写到filelist.txt
    // 打开输出文件流
    std::ofstream outputFile("filelist.txt");
    // 检查文件是否成功打开
    if (!outputFile.is_open())
    {
        QMessageBox::warning(this, "", "无法打开filelist.txt！");
        return 1;
    }
    // 将文件名写入到输出文件中
    for (QString fileInfo : fileInfoList)
    {
        outputFile <<"file "<<"\'"<< fileInfo.toStdString() <<"\'"<< std::endl;
    }

    // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
    //ffmpeg -f concat -safe 0 -i file_list.txt -c copy output.mp4
    QString QffmpegCmd =
        "ffmpeg -f concat -safe 0 -i filelist.txt -c copy " +
        ui->outputFilename->text() + ui->suffix->text();

    // 显示带有问号的弹窗
    QMessageBox::StandardButton answer = QMessageBox::question(nullptr, "剪辑", QffmpegCmd, QMessageBox::Yes | QMessageBox::No);
    // 根据用户的选择，输出结果
    if (answer == QMessageBox::No)
    {
        return false;
    }

    // 使用std::system()函数执行FFmpeg命令
    std::string ffmpegCmd = QffmpegCmd.toStdString();
    int result = std::system(ffmpegCmd.c_str());

    // 不为0,即为转码失败
    if (result != 0)
    {
        QMessageBox::warning(this, "错误", "失败");
    }
    else
    {
        QMessageBox::information(this, "", "成功");
    }

    return false;
}

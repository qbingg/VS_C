#include "Menu.h"
#include "ui_Menu.h"

Menu::Menu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Menu)
{
    ui->setupUi(this);

    setAcceptDrops(true);// 开启对整个窗口的拖放操作的支持

    // 选择文件
    connect(ui->btnOpenFile, &QPushButton::clicked, this, &Menu::slot_btnOpenFile);

    // 默认帧率 59.94
    ui->FPS->setValue(59.94);
    // 帧数
    connect(ui->btnFPS30, &QPushButton::clicked, this, &Menu::slot_btnFPS30);
    connect(ui->btnFPS5994, &QPushButton::clicked, this, &Menu::slot_btnFPS5994);
    connect(ui->btnFPS60, &QPushButton::clicked, this, &Menu::slot_btnFPS60);
    // ps5预设
    connect(ui->btnPS5_preset, &QPushButton::clicked, this, &Menu::slot_btnPS5_preset);

    // 预览
    connect(ui->btnShowPng, &QPushButton::clicked, this, &Menu::slot_btnShowPng);

    // 前、后一帧
    connect(ui->StartPng_last, &QToolButton::clicked, this, &Menu::slot_StartPng_last);
    connect(ui->StartPng_next, &QToolButton::clicked, this, &Menu::slot_StartPng_next);
    connect(ui->EndPng_last, &QToolButton::clicked, this, &Menu::slot_EndPng_last);
    connect(ui->EndPng_next, &QToolButton::clicked, this, &Menu::slot_EndPng_next);

    // 剪辑并转码
    connect(ui->btnCut, &QPushButton::clicked, this, &Menu::slot_btnCut);
    connect(ui->btnCut_MAXPreset, &QPushButton::clicked, this, &Menu::slot_btnCut_MAXPreset);

    // 码率默认设置为ps5的，所以在构造函数执行一次
    slot_btnPS5_preset(true);
    // 设置标题
    this->setWindowTitle("以帧剪辑并转码mp4");
    // 设置视频长度，默认为 1x
    ui->video_Length->setValue(1.0);
}

Menu::~Menu()
{
    delete ui;
}

void Menu::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasUrls())
    {
        event->acceptProposedAction(); // 接受默认的拖放行为
    }
}

void Menu::dropEvent(QDropEvent *event)
{
    QList<QUrl> urls = event->mimeData()->urls();

    // 确保文件数量仅为一个
    int file_num = 0;
    for (const QUrl& url : urls)
    {
        //QMessageBox::warning(this, "", url.toString());// 直接toString()输出的是file:///C:\Users\Luweiming\Desktop\test\test.mp4

        // 赋值到ui窗口上, 便于查看
        ui->fileInfo->setText(url.toLocalFile());

        // 赋值到输出文件名上
        // QString name_Output = QFileInfo(url.toLocalFile()).baseName();
        ui->fileName_Output->setText("clip_"+QString(QFileInfo(url.toLocalFile()).baseName()));

        file_num++;
    }
    if (file_num > 1)
    {
        // 清空输入栏
        ui->fileInfo->clear();

        // 报错
        QMessageBox::warning(this, "剪辑", "请拖入单个视频文件");

    }
}

bool Menu::slot_btnOpenFile(bool checked)
{
    QString filePath = QFileDialog::getOpenFileName(nullptr, QObject::tr("Open File"), QDir::rootPath(), QObject::tr("All Files (*)"));

    if (!filePath.isEmpty())
    {
        // 用户选择了文件，filePath 就是文件的路径
        // 在这里处理文件
        ui->fileInfo->setText(filePath);
    }

    return false;
}

bool Menu::slot_btnFPS30(bool checked)
{
    ui->FPS->setValue(30);

    return false;
}

bool Menu::slot_btnFPS5994(bool checked)
{
    ui->FPS->setValue(59.94);

    return false;
}

bool Menu::slot_btnFPS60(bool checked)
{
    ui->FPS->setValue(60);

    return false;
}

bool Menu::slot_btnPS5_preset(bool checked)
{
    // PS5默认帧率 59.94
    ui->FPS->setValue(59.94);

    // 设置码率
    ui->bitrate_average->setValue(50000);
    ui->bitrate_buffer->setValue(50000);
    ui->bitrate_max->setValue(55000);

    return false;
}

bool Menu::slot_btnShowPng(bool checked)
{
    if (ui->fileInfo->text().isEmpty())
    {
        //QMessageBox::warning(this, "剪辑", "输入栏为空, 不执行命令");

        return false;
    }

    QLabel* startPng= ui->label_StartPng;
    QLabel* endPng= ui->label_EndPng;

    if (true)
    {
        std::filesystem::path filePath = "startPng.png";
        if (std::filesystem::exists(filePath)) {
            if (std::filesystem::remove(filePath.c_str()) != 0) {
                //std::cerr << "Error deleting file" << std::endl;
                //return -1;
            }
            //std::cout << "File deleted successfully" << std::endl;
        }
        else {
            //std::cout << "File does not exist" << std::endl;
        }

        // 获取文件名
        QFileInfo fileInfo(ui->fileInfo->text());// 完整路径/+输入文件名.webm

        // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
        QString QffmpegCmd =
            "ffmpeg -i " +
            fileInfo.absoluteFilePath() +//完整路径+输入文件名.webm
            "  -vf \"select = \'eq(n," + QString::number(ui->startFPS->value()) + ")\'\" -frames:v 1 startPng.png";

        //QMessageBox::warning(this, "剪辑", QffmpegCmd);

        // 使用std::system()函数执行FFmpeg命令
        std::string ffmpegCmd = QffmpegCmd.toStdString();
        int result = std::system(ffmpegCmd.c_str());

        // 不为0,即为转码失败
        if (result != 0)
        {
            QMessageBox::warning(this, "错误", "图片获取失败");
        }
        else
        {
            // 加载图片
            QImage image;

            image.load("startPng.png"); // 替换为你的图片路径

            //// 在这删去图片，会无法显示（改为截图前删除旧的图片）
            //std::filesystem::path filePath = "startPng.png";
            //if (std::filesystem::exists(filePath)) {
            //    if (std::filesystem::remove(filePath.c_str()) != 0) {
            //        //std::cerr << "Error deleting file" << std::endl;
            //        return -1;
            //    }
            //    //std::cout << "File deleted successfully" << std::endl;
            //}
            //else {
            //    //std::cout << "File does not exist" << std::endl;
            //}

            // 将QImage转换为QPixmap
            QPixmap pixmap = QPixmap::fromImage(image);

            QPixmap show = pixmap.scaled(QSize(192, 108), Qt::KeepAspectRatio);

            // 在QLabel上显示图片
            startPng->setPixmap(show);

            // 设置窗口的大小以适合图片
            startPng->resize(show.width(), show.height());

        }
    }

    if (true)
    {
        std::filesystem::path filePath = "endPng.png";
        if (std::filesystem::exists(filePath)) {
            if (std::filesystem::remove(filePath.c_str()) != 0) {
                //std::cerr << "Error deleting file" << std::endl;
                //return -1;
            }
            //std::cout << "File deleted successfully" << std::endl;
        }
        else {
            //std::cout << "File does not exist" << std::endl;
        }

        // 获取文件名
        QFileInfo fileInfo(ui->fileInfo->text());// 完整路径/+输入文件名.webm

        // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
        QString QffmpegCmd =
            "ffmpeg -i " +
            fileInfo.absoluteFilePath() +//完整路径+输入文件名.webm
            "  -vf \"select = \'eq(n," + QString::number(ui->endFPS->value()) + ")\'\" -frames:v 1 endPng.png";

        //QMessageBox::warning(this, "剪辑", QffmpegCmd);

        // 使用std::system()函数执行FFmpeg命令
        std::string ffmpegCmd = QffmpegCmd.toStdString();
        int result = std::system(ffmpegCmd.c_str());

        // 不为0,即为转码失败
        if (result != 0)
        {
            QMessageBox::warning(this, "错误", "图片获取失败");
        }
        else
        {
            // 加载图片
            QImage image;

            image.load("endPng.png"); // 替换为你的图片路径

            //// 在这删去图片，会无法显示（改为截图前删除旧的图片）
            //std::filesystem::path filePath = "startPng.png";
            //if (std::filesystem::exists(filePath)) {
            //    if (std::filesystem::remove(filePath.c_str()) != 0) {
            //        //std::cerr << "Error deleting file" << std::endl;
            //        return -1;
            //    }
            //    //std::cout << "File deleted successfully" << std::endl;
            //}
            //else {
            //    //std::cout << "File does not exist" << std::endl;
            //}

            // 将QImage转换为QPixmap
            QPixmap pixmap = QPixmap::fromImage(image);

            QPixmap show = pixmap.scaled(QSize(192, 108), Qt::KeepAspectRatio);

            // 在QLabel上显示图片
            endPng->setPixmap(show);

            // 设置窗口的大小以适合图片
            endPng->resize(show.width(), show.height());


        }
    }

    //int x = 50;
    //int y = 200;

    //startPng->move(x, y);

    startPng->show();

    //endPng->move(x+200,y);

    endPng->show();

    return false;
}

bool Menu::slot_StartPng_last(bool checked)
{
    ui->startFPS->setValue(ui->startFPS->value()-1);

    update_startPng();

    return false;
}

bool Menu::slot_StartPng_next(bool checked)
{
    ui->startFPS->setValue(ui->startFPS->value()+1);

    update_startPng();

    return false;
}

bool Menu::slot_EndPng_last(bool checked)
{
    ui->endFPS->setValue(ui->endFPS->value()-1);

    update_endPng();

    return false;
}

bool Menu::slot_EndPng_next(bool checked)
{
    ui->endFPS->setValue(ui->endFPS->value()+1);

    update_endPng();

    return false;
}

bool Menu::slot_btnCut(bool checked)
{
    if (ui->fileInfo->text().isEmpty())
    {
        //QMessageBox::warning(this, "剪辑", "输入栏为空, 不执行命令");

        return false;
    }

    // 获取文件名
    QFileInfo fileInfo(ui->fileInfo->text());// 完整路径/+输入文件名.webm

    //
    double FPS = ui->FPS->value();
    double startFPS = ui->startFPS->value();
    double endFPS = ui->endFPS->value() + 1;// 结束点，改为“结束帧 + 1”，使其包含结束帧

    // 获取开始时间
    QString startTime = QString::number((startFPS / FPS), 'd', 5);
    // 获取结束时间
    QString endTime = QString::number((endFPS / FPS), 'd', 5);

    // 平均码率
    QString bitrate_Average =" -b:v " + QString::number(ui->bitrate_average->value()) + "k ";
    // 缓冲码率
    QString bitrate_buffer = " -bufsize " + QString::number(ui->bitrate_buffer->value())+ "k ";
    // 最大码率
    QString bitrate_Max = " -maxrate "+ QString::number(ui->bitrate_max->value())+ "k ";

    // 视频长度
    QString video_Length;
    if(ui->video_Length->value()!=1)
    {
        // 视频长度倍数 ， 还要设置输出视频帧率，否则默认25帧/秒
        video_Length = " -filter:v \"setpts="+QString::number(ui->video_Length->value())+"*PTS\" -r "+QString::number(ui->FPS->value())+" ";

        // 新的结束时间 = 结束时间 * 视频长度倍数
        endTime = QString::number((endFPS / FPS)*(ui->video_Length->value()), 'd', 5);
    }

    // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
    QString QffmpegCmd =
        "ffmpeg -i " +
        fileInfo.absoluteFilePath() +//完整路径+输入文件名.webm
        bitrate_Average     +
        bitrate_buffer      +
        bitrate_Max         +
        " -ss " + startTime +
        " -to " + endTime   +
        video_Length        +
        " " + fileInfo.absolutePath() + "/" + ui->fileName_Output->text() + ".mp4";//路径+文件名+.mp4

    // 显示带有问号的弹窗
    QMessageBox::StandardButton answer = QMessageBox::question(nullptr, "剪辑", QffmpegCmd, QMessageBox::Yes | QMessageBox::No);
    // 根据用户的选择，输出结果
    if (answer == QMessageBox::No)
    {
        return false;
    }

    // 使用std::system()函数执行FFmpeg命令
    std::string ffmpegCmd = QffmpegCmd.toStdString();
    int result = std::system(ffmpegCmd.c_str());

    // 不为0,即为转码失败
    if (result != 0)
    {
        QMessageBox::warning(this, "错误", "剪辑并转码失败");
    }
    else
    {
        QMessageBox::information(this, "", "剪辑并转码成功");
    }

    return false;
}

bool Menu::slot_btnCut_MAXPreset(bool checked)
{
    // 最高预设：    ffmpeg -i "i.webm" -c:v libx264 -crf 0 -preset veryslow -c:a aac -b:a 192k o.mp4

    if (ui->fileInfo->text().isEmpty())
    {
        //QMessageBox::warning(this, "剪辑", "输入栏为空, 不执行命令");

        return false;
    }

    // 获取文件名
    QFileInfo fileInfo(ui->fileInfo->text());// 完整路径/+输入文件名.webm

    //
    double FPS = ui->FPS->value();
    double startFPS = ui->startFPS->value();
    double endFPS = ui->endFPS->value() + 1;// 结束点，改为“结束帧 + 1”，使其包含结束帧

    // 获取开始时间
    QString startTime = QString::number((startFPS / FPS), 'd', 5);
    // 获取结束时间
    QString endTime = QString::number((endFPS / FPS), 'd', 5);

    //QMessageBox::information(this, "", startTime);

    // 视频长度
    QString video_Length;
    if(ui->video_Length->value()!=1)
    {
        // 视频长度倍数 ， 还要设置输出视频帧率，否则默认25帧/秒
        video_Length = " -filter:v \"setpts="+QString::number(ui->video_Length->value())+"*PTS\" -r "+QString::number(ui->FPS->value())+" ";

        // 新的结束时间 = 结束时间 * 视频长度倍数
        endTime = QString::number((endFPS / FPS)*(ui->video_Length->value()), 'd', 5);
    }

    // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
    QString QffmpegCmd =
        "ffmpeg -i " +
        fileInfo.absoluteFilePath() +//完整路径+输入文件名.webm
        " -c:v libx264 -crf 0 -preset veryslow -c:a aac -b:a 192k"
        " -ss " + startTime +
        " -to " + endTime   +
        video_Length        +
        " " + fileInfo.absolutePath() + "/" + ui->fileName_Output->text() + ".mp4";//路径+文件名+.mp4

    // 显示带有问号的弹窗
    QMessageBox::StandardButton answer = QMessageBox::question(nullptr, "剪辑", QffmpegCmd, QMessageBox::Yes | QMessageBox::No);
    // 根据用户的选择，输出结果
    if (answer == QMessageBox::No)
    {
        return false;
    }

    // 使用std::system()函数执行FFmpeg命令
    std::string ffmpegCmd = QffmpegCmd.toStdString();
    int result = std::system(ffmpegCmd.c_str());

    // 不为0,即为转码失败
    if (result != 0)
    {
        QMessageBox::warning(this, "错误", "剪辑并转码失败");
    }
    else
    {
        QMessageBox::information(this, "最高预设", "剪辑并转码成功");
    }

    return false;
}

void Menu::update_startPng()
{
    if (ui->fileInfo->text().isEmpty())
    {
        //QMessageBox::warning(this, "剪辑", "输入栏为空, 不执行命令");

        return ;
    }

    QLabel* startPng= ui->label_StartPng;


    if (true)
    {
        std::filesystem::path filePath = "startPng.png";
        if (std::filesystem::exists(filePath)) {
            if (std::filesystem::remove(filePath.c_str()) != 0) {
                //std::cerr << "Error deleting file" << std::endl;
                //return -1;
            }
            //std::cout << "File deleted successfully" << std::endl;
        }
        else {
            //std::cout << "File does not exist" << std::endl;
        }

        // 获取文件名
        QFileInfo fileInfo(ui->fileInfo->text());// 完整路径/+输入文件名.webm

        // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
        QString QffmpegCmd =
            "ffmpeg -i " +
            fileInfo.absoluteFilePath() +//完整路径+输入文件名.webm
            "  -vf \"select = \'eq(n," + QString::number(ui->startFPS->value()) + ")\'\" -frames:v 1 startPng.png";

        //QMessageBox::warning(this, "剪辑", QffmpegCmd);

        // 使用std::system()函数执行FFmpeg命令
        std::string ffmpegCmd = QffmpegCmd.toStdString();
        int result = std::system(ffmpegCmd.c_str());

        // 不为0,即为转码失败
        if (result != 0)
        {
            QMessageBox::warning(this, "错误", "图片获取失败");
        }
        else
        {
            // 加载图片
            QImage image;

            image.load("startPng.png"); // 替换为你的图片路径

            //// 在这删去图片，会无法显示（改为截图前删除旧的图片）
            //std::filesystem::path filePath = "startPng.png";
            //if (std::filesystem::exists(filePath)) {
            //    if (std::filesystem::remove(filePath.c_str()) != 0) {
            //        //std::cerr << "Error deleting file" << std::endl;
            //        return -1;
            //    }
            //    //std::cout << "File deleted successfully" << std::endl;
            //}
            //else {
            //    //std::cout << "File does not exist" << std::endl;
            //}

            // 将QImage转换为QPixmap
            QPixmap pixmap = QPixmap::fromImage(image);

            QPixmap show = pixmap.scaled(QSize(192, 108), Qt::KeepAspectRatio);

            // 在QLabel上显示图片
            startPng->setPixmap(show);

            // 设置窗口的大小以适合图片
            startPng->resize(show.width(), show.height());

        }
    }

}

void Menu::update_endPng()
{
    if (ui->fileInfo->text().isEmpty())
    {
        //QMessageBox::warning(this, "剪辑", "输入栏为空, 不执行命令");

        return;
    }

    QLabel* endPng= ui->label_EndPng;


    if (true)
    {
        std::filesystem::path filePath = "endPng.png";
        if (std::filesystem::exists(filePath)) {
            if (std::filesystem::remove(filePath.c_str()) != 0) {
                //std::cerr << "Error deleting file" << std::endl;
                //return -1;
            }
            //std::cout << "File deleted successfully" << std::endl;
        }
        else {
            //std::cout << "File does not exist" << std::endl;
        }

        // 获取文件名
        QFileInfo fileInfo(ui->fileInfo->text());// 完整路径/+输入文件名.webm

        // 构建FFmpeg命令字符串(使用中文,中文会乱码,QProcess可能可以解决,以后再说)
        QString QffmpegCmd =
            "ffmpeg -i " +
            fileInfo.absoluteFilePath() +//完整路径+输入文件名.webm
            "  -vf \"select = \'eq(n," + QString::number(ui->endFPS->value()) + ")\'\" -frames:v 1 endPng.png";

        //QMessageBox::warning(this, "剪辑", QffmpegCmd);

        // 使用std::system()函数执行FFmpeg命令
        std::string ffmpegCmd = QffmpegCmd.toStdString();
        int result = std::system(ffmpegCmd.c_str());

        // 不为0,即为转码失败
        if (result != 0)
        {
            QMessageBox::warning(this, "错误", "图片获取失败");
        }
        else
        {
            // 加载图片
            QImage image;

            image.load("endPng.png"); // 替换为你的图片路径

            //// 在这删去图片，会无法显示（改为截图前删除旧的图片）
            //std::filesystem::path filePath = "startPng.png";
            //if (std::filesystem::exists(filePath)) {
            //    if (std::filesystem::remove(filePath.c_str()) != 0) {
            //        //std::cerr << "Error deleting file" << std::endl;
            //        return -1;
            //    }
            //    //std::cout << "File deleted successfully" << std::endl;
            //}
            //else {
            //    //std::cout << "File does not exist" << std::endl;
            //}

            // 将QImage转换为QPixmap
            QPixmap pixmap = QPixmap::fromImage(image);

            QPixmap show = pixmap.scaled(QSize(192, 108), Qt::KeepAspectRatio);

            // 在QLabel上显示图片
            endPng->setPixmap(show);

            // 设置窗口的大小以适合图片
            endPng->resize(show.width(), show.height());


        }
    }


}

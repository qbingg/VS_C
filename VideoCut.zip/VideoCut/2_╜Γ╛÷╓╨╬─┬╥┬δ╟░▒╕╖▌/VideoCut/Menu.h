#ifndef MENU_H
#define MENU_H

#include <QWidget>

#include <cstdlib> // 包含std::system()函数的头文件
#include <QDialog>
#include <QMimeData>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QList>
#include <QUrl>
#include <QVector>
#include <QFileInfo>
#include <qmessagebox.h>
#include <QFileDialog>
#include <filesystem>

QT_BEGIN_NAMESPACE
namespace Ui {
class Menu;
}
QT_END_NAMESPACE

class Menu : public QWidget
{
    Q_OBJECT

public:
    Menu(QWidget *parent = nullptr);
    ~Menu();

private:
    Ui::Menu *ui;

protected:
    // 重写父类事件方法
    // 当拖拽对象进入窗口时调用
    void dragEnterEvent(QDragEnterEvent* event) override;
    // 当拖放对象在窗口内释放时调用
    void dropEvent(QDropEvent* event) override;

private slots:
    // 选择文件
    bool slot_btnOpenFile(bool checked);

    // 设置帧数按钮s
    bool slot_btnFPS30(bool checked);
    bool slot_btnFPS5994(bool checked);
    bool slot_btnFPS60(bool checked);
    // ps5预设
    bool slot_btnPS5_preset(bool checked);
    // 预览
    bool slot_btnShowPng(bool checked);
    // 前、后一帧
    bool slot_StartPng_last(bool checked);
    bool slot_StartPng_next(bool checked);
    bool slot_EndPng_last(bool checked);
    bool slot_EndPng_next(bool checked);

    // 触发剪辑事件 // 剪辑并转码
    bool slot_btnCut(bool checked);
    bool slot_btnCut_MAXPreset(bool checked);
    bool slot_btnCut_CCopy(bool checked);

public:
    void update_startPng();
    void update_endPng();

};
#endif // MENU_H

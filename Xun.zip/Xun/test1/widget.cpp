#include "widget.h"
#include "ui_widget.h"

#include <QProcess>
#include <qmessagebox.h>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , ffmpegProcess(nullptr)
{
    ui->setupUi(this);

    setWindowTitle("录屏测试，截图测试");

    ui->lineEdit->setText("output");
}

Widget::~Widget()
{
    delete ui;
}

cv::Mat Widget::function_screenGray(int x1, int y1, int x2, int y2)
{
    //截图
    // 获取屏幕设备的上下文
    HDC hScreenDC = GetDC(NULL);
    // 计算截图区域的宽度和高度
    int width = x2 - x1;
    int height = y2 - y1;

    // 检查宽高是否有效
    if (width <= 0 || height <= 0) {
        return cv::Mat(); // 返回空的Mat
    }

    // 创建一个与屏幕设备上下文兼容的内存设备上下文
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    // 创建一个与屏幕兼容的位图，用于存储截图数据
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

    // 将位图选入内存设备上下文
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

    // 将指定区域的屏幕内容拷贝到位图上
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

    // 创建OpenCV Mat来存储图像数据
    cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

    // 锁定位图的像素区域以便访问
    BITMAPINFOHEADER bi;
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = width;
    bi.biHeight = -height; // Negative height for top-down DIB
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    // 获取位图的像素数据，并将其存储在OpenCV Mat中
    GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
    cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

    // 将图像转换为灰度图像
    cv::Mat grayScreenshot;
    cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

    // 清理资源
    SelectObject(hMemoryDC, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);

    //cv::namedWindow("hist", cv::WINDOW_FREERATIO);
    //cv::imshow("hist", grayScreenshot);

    return grayScreenshot;
}


void Widget::on_pushButton_clicked()
{
    //1、获取屏幕分辨率

    int x,y;
    x= ui->screen_resolution_x->value();
    y= ui->screen_resolution_y->value();

    cv::Mat hist = function_screenGray(0,0,x,y);

    if(!hist.empty())
    {
        cv::namedWindow("hist", cv::WINDOW_FREERATIO);
        cv::imshow("hist", hist);

        cv::waitKey(0);
    }
    else
    {
        QMessageBox::warning(this, "截图失败", "截图区域为空");
    }




}


void Widget::on_checkBox_stateChanged(int arg1)
{
    //Q_UNUSED(arg1);

    if(ui->checkBox->isChecked())
    {
        // 如果之前有进程在运行，先终止它
        if (ffmpegProcess && ffmpegProcess->state() != QProcess::NotRunning) {
            ffmpegProcess->terminate();
            if (!ffmpegProcess->waitForFinished(3000)) {
                ffmpegProcess->kill();
            }
        }

        /* 不录制音频

        // QStringList arguments;
        // arguments << "-y"                       // 强制覆盖输出文件
        //           << "-f" << "gdigrab"          // 视频捕获格式
        //           << "-framerate" << "30"       // 帧率
        //           << "-i" << "desktop"          // 视频输入源（桌面）
        //           << "-c:v" << "libx264"        // 视频编码器
        //           << "-crf" << "23"             // 视频质量
        //           << "-preset" << "veryfast"    // 编码速度
        //           << ui->lineEdit->text()+".mp4";              // 输出文件
*/

        /* 录制音频，在cmd可运行，在qt不行

        // QStringList arguments;
        // arguments << "-y"                       // 强制覆盖输出文件
        //           << "-f" << "gdigrab"          // 视频捕获格式
        //           << "-framerate" << "30"       // 帧率
        //           << "-i" << "desktop"          // 视频输入源（桌面）
        //           << "-f" << "dshow"            // 音频捕获格式（DirectShow）
        //           << "-i" << "audio=\"CABLE Output (VB-Audio Virtual Cable)\"" // 音频输入源
        //           << "-c:v" << "libx264"        // 视频编码器
        //           << "-crf" << "23"             // 视频质量
        //           << "-preset" << "veryfast"    // 编码速度
        //           << "-c:a" << "aac"            // 音频编码器
        //           << "-strict" << "experimental" // 允许实验性编码器（如 AAC）
        //           << ui->lineEdit->text() + ".mp4"; // 输出文件
*/

        /* 用<<代替字符串内的空格，更不行！！！只能识别到audio=\"CABLE

        // QStringList arguments;
        // arguments << "-y"                       // 强制覆盖输出文件
        //           << "-f" << "gdigrab"          // 视频捕获格式
        //           << "-framerate" << "30"       // 帧率
        //           << "-i" << "desktop"          // 视频输入源（桌面）
        //           << "-f" << "dshow"            // 音频捕获格式（DirectShow）
        //           << "-i" << "audio=\"CABLE"<<"Output"<<"(VB-Audio"<<"Virtual"<<"Cable)\"" // 音频输入源
        //           << "-c:v" << "libx264"        // 视频编码器
        //           << "-crf" << "23"             // 视频质量
        //           << "-preset" << "veryfast"    // 编码速度
        //           << "-c:a" << "aac"            // 音频编码器
        //           << "-strict" << "experimental" // 允许实验性编码器（如 AAC）
        //           << ui->lineEdit->text() + ".mp4"; // 输出文件
*/

        // 去掉 : 反斜杠" 成功了
        QStringList arguments;
        arguments << "-y"                       // 强制覆盖输出文件
                  << "-f" << "gdigrab"          // 视频捕获格式
                  << "-framerate" << "30"       // 帧率
                  << "-i" << "desktop"          // 视频输入源（桌面）
                  << "-f" << "dshow"            // 音频捕获格式（DirectShow）
                  << "-i" << "audio=CABLE Output (VB-Audio Virtual Cable)" // 音频输入源
                  << "-c:v" << "libx264"        // 视频编码器
                  << "-crf" << "23"             // 视频质量
                  << "-preset" << "veryfast"    // 编码速度
                  << "-c:a" << "aac"            // 音频编码器
                  << "-strict" << "experimental" // 允许实验性编码器（如 AAC）
                  << ui->lineEdit->text() + ".mp4"; // 输出文件

        qDebug() << "FFmpeg command:" << "ffmpeg " << arguments.join(" ");


        // 创建新的QProcess实例
        ffmpegProcess = new QProcess(this);
        //连接 finished 信号
        //使用 Lambda 表达式处理信号
        connect(ffmpegProcess, &QProcess::finished, [=](int exitCode, QProcess::ExitStatus exitStatus) {
            if (exitStatus == QProcess::NormalExit && exitCode == 0) {
                qDebug() << "Video cut successfully!";
                QMessageBox::information(this, "", "录制成功");
            } else {
                qDebug() << "Error occurred:" << ffmpegProcess->readAllStandardError();
            }
            ffmpegProcess->deleteLater();
        });

        connect(ffmpegProcess, QOverload<QProcess::ProcessError>::of(&QProcess::errorOccurred),
                [=](QProcess::ProcessError error) {
                    qDebug() << "Process error:" << error;
                    ffmpegProcess->deleteLater();
                });

        ffmpegProcess->start("ffmpeg", arguments);
    }
    else
    {
        if (ffmpegProcess) {
            // 先尝试优雅终止
            ffmpegProcess->write("q\n");  // 发送FFmpeg的退出命令
            ffmpegProcess->closeWriteChannel();

            if (!ffmpegProcess->waitForFinished(5000)) { // 等待5秒
                ffmpegProcess->terminate();
                if (!ffmpegProcess->waitForFinished(3000)) {
                    ffmpegProcess->kill();
                }
            }
        }
    }
}


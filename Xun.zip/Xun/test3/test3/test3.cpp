﻿

#include <iostream>
#include <Windows.h>

//在（x,y）处触发一次鼠标左键点击 （sleepTime为移动至按下的等待时间，默认500ms）
void SendMouseClick(int x, int y, int sleepTime = 500)
{
    INPUT input[2] = { 0 };
    MOUSEINPUT mi = { 0 };

    // 设置鼠标位置
    SetCursorPos(x, y);

    Sleep(sleepTime);

    // 按下鼠标左键
    //mi.type = INPUT_MOUSE;
    mi.dx = 0; // 相对移动，这里设置为0
    mi.dy = 0; // 相对移动，这里设置为0
    mi.mouseData = 0; // 通常设置为0，对于左键点击不需要特殊值
    mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    input[0].mi = mi;

    // 释放鼠标左键
    mi.dwFlags = MOUSEEVENTF_LEFTUP;
    input[1].mi = mi;

    // 发送输入事件
    SendInput(2, input, sizeof(INPUT));
}

int main()
{
    std::cout << "5秒后开始\n";

    Sleep(5000);

    //while (1)
    //{
    //    std::cout << "模拟按下“下箭头”\n";

    //    keybd_event(VK_DOWN, 0, 0, 0);
    //    Sleep(100);
    //    keybd_event(VK_DOWN, 0, KEYEVENTF_KEYUP, 0);

    //    Sleep(2000);
    //}

    std::cout << "模拟按下鼠标左键\n";


    SendMouseClick(711, 429);

    system("pause");

}



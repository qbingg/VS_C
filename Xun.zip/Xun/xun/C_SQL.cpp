#include "C_SQL.h"

C_SQL::C_SQL() {
    //打开数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return;
    }

    if(1){
        //查看int表是否存在
        QSqlQuery query;
        QString sql = QString::fromUtf8(R"(
create table if not exists tb_int
(
key int PRIMARY KEY,
value int
)
)");
        if (!query.exec(sql))
        {
            qDebug() << "Failed to create table";
            qDebug() << query.lastQuery();
            return;
        }
    }

    if(1){
        //查看double表是否存在
        QSqlQuery query;
        QString sql = QString::fromUtf8(R"(
create table if not exists tb_double
(
key int PRIMARY KEY,
value double
)
)");
        if (!query.exec(sql))
        {
            qDebug() << "Failed to create table";
            qDebug() << query.lastQuery();
            return;
        }
    }

    if(1){
        //查看QColor表是否存在
        QSqlQuery query;
        QString sql = QString::fromUtf8(R"(
create table if not exists tb_QColor
(
key int PRIMARY KEY,
value text
)
)");
        if (!query.exec(sql))
        {
            qDebug() << "Failed to create table";
            qDebug() << query.lastQuery();
            return;
        }
    }

    if(1){
        //查看QString表是否存在
        QSqlQuery query;
        QString sql = QString::fromUtf8(R"(
create table if not exists tb_QString
(
key int PRIMARY KEY,
value text
)
)");
        if (!query.exec(sql))
        {
            qDebug() << "Failed to create table";
            qDebug() << query.lastQuery();
            return;
        }
    }



    m_db.close();
}

bool C_SQL::write_intMapData(QMap<int, int> &intMapData)
{
    //打开数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    //写入数据
    foreach (int key, intMapData.keys()) {
        int value = intMapData.value(key);

        QSqlQuery query;
        query.prepare(R"(
        insert into tb_int
        (
        key,
        value
        )
        values
        (
        :key,
        :value
        )
        ON CONFLICT(key) DO UPDATE SET value = excluded.value;
        )");//key = excluded.key,键不需要修改

        query.bindValue(":key", key);
        query.bindValue(":value", value);
        if (!query.exec())
        {
            qDebug() << query.lastQuery();
            m_db.close();
            return false;
        }

    }



    m_db.close();

    return true;
}

bool C_SQL::read_intMapData(QMap<int, int> &intMapData)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM tb_int");
    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }

    while(query.next())
    {
        qDebug() << query.value("key").toInt()<<", "<<query.value("value").toInt();

        int key = query.value("key").toInt();
        int value = query.value("value").toInt();
        intMapData[key] = value;
    }
    m_db.close();

    return true;
}

bool C_SQL::write_doubleMapData(QMap<int, double> &doubleMapData)
{
    //打开数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    //写入数据
    foreach (int key, doubleMapData.keys()) {
        double value = doubleMapData.value(key);

        QSqlQuery query;
        query.prepare(R"(
        insert into tb_double
        (
        key,
        value
        )
        values
        (
        :key,
        :value
        )
        ON CONFLICT(key) DO UPDATE SET value = excluded.value;
        )");//key = excluded.key,键不需要修改

        query.bindValue(":key", key);
        query.bindValue(":value", value);
        if (!query.exec())
        {
            qDebug() << query.lastQuery();
            m_db.close();
            return false;
        }

    }



    m_db.close();

    return true;
}

bool C_SQL::read_doubleMapData(QMap<int, double> &doubleMapData)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM tb_double");
    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }

    while(query.next())
    {
        qDebug() << query.value("key").toInt()<<", "<<query.value("value").toDouble();

        int key = query.value("key").toInt();
        double value = query.value("value").toDouble();
        doubleMapData[key] = value;
    }
    m_db.close();

    return true;
}

bool C_SQL::write_QColorMapData(QMap<int, QColor> &QColorMapData)
{
    //打开数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    //写入数据
    foreach (int key, QColorMapData.keys()) {
        QColor value = QColorMapData.value(key);

        QSqlQuery query;
        query.prepare(R"(
        insert into tb_QColor
        (
        key,
        value
        )
        values
        (
        :key,
        :value
        )
        ON CONFLICT(key) DO UPDATE SET value = excluded.value;
        )");//key = excluded.key,键不需要修改

        query.bindValue(":key", key);
        query.bindValue(":value", value.name());//QString好像是可以直接存入的#ffffff
        if (!query.exec())
        {
            qDebug() << query.lastQuery();
            m_db.close();
            return false;
        }

    }



    m_db.close();

    return true;
}

bool C_SQL::read_QColorMapData(QMap<int, QColor> &QColorMapData)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM tb_QColor");
    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }

    while(query.next())
    {
        qDebug() << query.value("key").toInt()<<", "<<query.value("value");

        int key = query.value("key").toInt();
        QColor value = query.value("value").toString();
        QColorMapData[key] = value;
    }
    m_db.close();

    return true;
}

bool C_SQL::write_QStringMapData(QMap<int, QString> &QStringMapData)
{
    //打开数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    //写入数据
    foreach (int key, QStringMapData.keys()) {
        QString value = QStringMapData.value(key);

        QSqlQuery query;
        query.prepare(R"(
        insert into tb_QString
        (
        key,
        value
        )
        values
        (
        :key,
        :value
        )
        ON CONFLICT(key) DO UPDATE SET value = excluded.value;
        )");//key = excluded.key,键不需要修改

        query.bindValue(":key", key);
        query.bindValue(":value", value);
        if (!query.exec())
        {
            qDebug() << query.lastQuery();
            m_db.close();
            return false;
        }

    }



    m_db.close();

    return true;
}

bool C_SQL::read_QStringMapData(QMap<int, QString> &QStringMapData)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");//使用sqlite不需要安装数据库////使用sqlite而不是sql server语言
    m_db.setDatabaseName("Database.db");
    if (!m_db.open())
    {
        qDebug() << "Failed to open database";
        return false;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM tb_QString");
    if (!query.exec())
    {
        qDebug() << query.lastQuery();
        m_db.close();
        return false;
    }

    while(query.next())
    {
        qDebug() << query.value("key").toInt()<<", "<<query.value("value");

        int key = query.value("key").toInt();
        QString value = query.value("value").toString();
        QStringMapData[key] = value;
    }
    m_db.close();

    return true;
}

#ifndef C_SQL_H
#define C_SQL_H

#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>
#include <QColor>

class C_SQL
{
private:
    QSqlDatabase m_db;  //数据库连接
public:
    C_SQL();
    bool write_intMapData(QMap<int,int> &intMapData);
    bool read_intMapData(QMap<int,int> &intMapData);

    bool write_doubleMapData(QMap<int,double> &doubleMapData);
    bool read_doubleMapData(QMap<int,double> &doubleMapData);

    bool write_QColorMapData(QMap<int,QColor> &QColorMapData);
    bool read_QColorMapData(QMap<int,QColor> &QColorMapData);

    bool write_QStringMapData(QMap<int,QString> &QStringMapData);
    bool read_QStringMapData(QMap<int,QString> &QStringMapData);
};

#endif // C_SQL_H

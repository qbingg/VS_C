#ifndef C_PREVIEW_H
#define C_PREVIEW_H

#include <QWidget>
#include"Defines.h"
#include <qpainter.h>
//预览: 图像检测区域
namespace Ui {
class C_preview;
}

class C_preview : public QWidget
{
    Q_OBJECT

public:
    explicit C_preview(QWidget *parent = nullptr);
    ~C_preview();
    void paintEvent(QPaintEvent* event)override;
    void setPreviewData(QMap<int,int> newIntMapData, double newMagnify_n);
private:
    Ui::C_preview *ui;

    QMap<int,int> intMapData;
    double magnify_n;//125%->0.8



};

#endif // C_PREVIEW_H

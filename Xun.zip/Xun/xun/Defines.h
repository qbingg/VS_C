#ifndef DEFINES_H
#define DEFINES_H

//包含头文件
#include <opencv2/opencv.hpp>
#include <Windows.h>

struct Click
{
    cv::Mat templ;
    int x1;
    int y1;
    int x2;
    int y2;
};

//int
#define SCREEN_RESOLUTION_X 1
#define SCREEN_RESOLUTION_Y 2

#define PLAY_X1 3
#define PLAY_Y1 4
#define PLAY_X2 5
#define PLAY_Y2 6

#define TIMELINE_X1 7
#define TIMELINE_Y1 8
#define TIMELINE_X2 9
#define TIMELINE_Y2 10

// #define TIMELINE_TEMPL_X1 11
// #define TIMELINE_TEMPL_Y1 12
// #define TIMELINE_TEMPL_X2 13
// #define TIMELINE_TEMPL_Y2 14

#define DELAYTIME 15

#define OUTPUTFILENAME 16

//double
#define SCREEN_MAGNIFY 1

//QString
#define FOLDERINFO 1

#endif // DEFINES_H

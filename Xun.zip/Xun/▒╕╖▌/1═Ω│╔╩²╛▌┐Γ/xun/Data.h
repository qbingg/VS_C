#ifndef DATA_H
#define DATA_H

#include <qsqldatabase.h>	//属性管理器	>>	Qt project settings	>>	勾选sql
#include <qstring.h>
#include <QSqlQuery>
#include <QColor>

#include"Defines.h"

QMap<int, int> intMapData = {
    {SCREEN_RESOLUTION_X, 0},
    {SCREEN_RESOLUTION_Y, 0},
    {PLAY_X1, 0},
    {PLAY_Y1, 0},
    {PLAY_X2, 0},
    {PLAY_Y2, 0},
    {TIMELINE_X1, 0},
    {TIMELINE_Y1, 0},
    {TIMELINE_X2, 0},
    {TIMELINE_Y2, 0}
};

QMap<int,double> doubleMapData = {
    {SCREEN_MAGNIFY , 0}
};



#endif // DATA_H

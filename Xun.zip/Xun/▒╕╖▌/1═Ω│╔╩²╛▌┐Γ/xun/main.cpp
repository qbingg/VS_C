#include "widget.h"

#include <QApplication>

#include "Data.h"
#include "C_SQL.h"

//启动程序需要做的事
void function_StartALL()//启动程序需要做的事
{
    //读取数据
    C_SQL sql;
    sql.read_intMapData(intMapData);
    sql.read_doubleMapData(doubleMapData);



    // for(int key :intMapData.keys()){

    //     qDebug() << intMapData[key];
    // }


}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    function_StartALL();

    Widget w;

    w.setIntMapData(intMapData);
    w.setDoubleMapData(doubleMapData);

    w.show();
    return a.exec();
}

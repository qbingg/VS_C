#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "Defines.h"
#include "C_SQL.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;


    //数据库
private:
    QMap<int,int> m_intMapData;
    QMap<int,double> m_doubleMapData;
    QMap<int,QColor> m_QColorMapData;
public:
    void setIntMapData(const QMap<int, int> &newIntMapData);

    void setDoubleMapData(const QMap<int, double> &newDoubleMapData);

    void setQColorMapData(const QMap<int, QColor> &newQColorMapData);



private slots:
    void on_btnSave_clicked();
};
#endif // WIDGET_H

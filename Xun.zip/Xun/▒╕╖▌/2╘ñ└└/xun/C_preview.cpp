#include "C_preview.h"
#include "ui_C_preview.h"

C_preview::C_preview(QWidget *parent)
    : QWidget(parent, Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint)
    , ui(new Ui::C_preview)
{
    //ui->setupUi(this);

    setAttribute(Qt::WA_TranslucentBackground);
}

C_preview::~C_preview()
{
    delete ui;
}

void C_preview::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);

    painter.setPen(QPen(Qt::green, 1));

    //播放按钮
    painter.drawRect(
        intMapData[PLAY_X1] * magnify_n,
        intMapData[PLAY_Y1] * magnify_n,
        (intMapData[PLAY_X2]-intMapData[PLAY_X1]) * magnify_n,
        (intMapData[PLAY_Y2]-intMapData[PLAY_Y1]) * magnify_n
        );
    //时间轴
    painter.drawRect(
        intMapData[TIMELINE_X1] * magnify_n,
        intMapData[TIMELINE_Y1] * magnify_n,
        (intMapData[TIMELINE_X2]-intMapData[TIMELINE_X1]) * magnify_n,
        (intMapData[TIMELINE_Y2]-intMapData[TIMELINE_Y1]) * magnify_n
        );
    //总时长
    painter.drawRect(
        intMapData[TIMELINE_TEMPL_X1] * magnify_n,
        intMapData[TIMELINE_TEMPL_Y1] * magnify_n,
        (intMapData[TIMELINE_TEMPL_X2]-intMapData[TIMELINE_TEMPL_X1]) * magnify_n,
        (intMapData[TIMELINE_TEMPL_Y2]-intMapData[TIMELINE_TEMPL_Y1]) * magnify_n
        );

    //小地图的边框
    //画边框，确认小地图范围
    // //400
    // painter.drawRect(0, 0, (sMap400_x2 - sMap400_x1) * magnify_n, (sMap400_y2 - sMap400_y1) * magnify_n);
    // //700
    // painter.drawRect(0, 0, (sMap700_x2 - sMap700_x1) * magnify_n , (sMap700_y2 - sMap700_y1) * magnify_n);

    // 400
    // painter.drawRect(
    //     intMapData[SMAP400_X1] * magnify_n,
    //     intMapData[SMAP400_Y1] * magnify_n,
    //     (intMapData[SMAP400_X2]-intMapData[SMAP400_X1]) * magnify_n,
    //     (intMapData[SMAP400_Y2]-intMapData[SMAP400_Y1]) * magnify_n
    //     );

    // // 700
    // painter.drawRect(
    //     intMapData[SMAP700_X1] * magnify_n,
    //     intMapData[SMAP700_Y1] * magnify_n,
    //     (intMapData[SMAP700_X2]-intMapData[SMAP700_X1]) * magnify_n,
    //     (intMapData[SMAP700_Y2]-intMapData[SMAP700_Y1]) * magnify_n
    //     );

}

void C_preview::setPreviewData(QMap<int, int> newIntMapData, double newMagnify_n)
{
    intMapData = newIntMapData;

    magnify_n = (static_cast<double>(1) / newMagnify_n);//125%->0.8


}

#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;

    //将数据赋值到ui控件上
    ui->screen_resolution_x->setValue(m_intMapData[SCREEN_RESOLUTION_X]);
    ui->screen_resolution_y->setValue(m_intMapData[SCREEN_RESOLUTION_Y]);

    ui->play_x1->setValue(m_intMapData[PLAY_X1]);
    ui->play_y1->setValue(m_intMapData[PLAY_Y1]);
    ui->play_x2->setValue(m_intMapData[PLAY_X2]);
    ui->play_y2->setValue(m_intMapData[PLAY_Y2]);

    ui->timeline_x1->setValue(m_intMapData[TIMELINE_X1]);
    ui->timeline_y1->setValue(m_intMapData[TIMELINE_Y1]);
    ui->timeline_x2->setValue(m_intMapData[TIMELINE_X2]);
    ui->timeline_y2->setValue(m_intMapData[TIMELINE_Y2]);

    ui->timeline_templ_x1->setValue(m_intMapData[TIMELINE_TEMPL_X1]);
    ui->timeline_templ_y1->setValue(m_intMapData[TIMELINE_TEMPL_Y1]);
    ui->timeline_templ_x2->setValue(m_intMapData[TIMELINE_TEMPL_X2]);
    ui->timeline_templ_y2->setValue(m_intMapData[TIMELINE_TEMPL_Y2]);


}

void Widget::setDoubleMapData(const QMap<int, double> &newDoubleMapData)
{
    m_doubleMapData = newDoubleMapData;

    ui->screen_magnify->setValue(m_doubleMapData[SCREEN_MAGNIFY]);

}

void Widget::on_btnSave_clicked()
{
    //将ui控件的数据复制到Map里

    //将ui控件的数据写入Map
    //int
    m_intMapData[SCREEN_RESOLUTION_X] = ui->screen_resolution_x->value();
    m_intMapData[SCREEN_RESOLUTION_Y] = ui->screen_resolution_y->value();

    m_intMapData[PLAY_X1] = ui->play_x1->value();
    m_intMapData[PLAY_Y1] = ui->play_y1->value();
    m_intMapData[PLAY_X2] = ui->play_x2->value();
    m_intMapData[PLAY_Y2] = ui->play_y2->value();

    m_intMapData[TIMELINE_X1] = ui->timeline_x1->value();
    m_intMapData[TIMELINE_Y1] = ui->timeline_y1->value();
    m_intMapData[TIMELINE_X2] = ui->timeline_x2->value();
    m_intMapData[TIMELINE_Y2] = ui->timeline_y2->value();

    m_intMapData[TIMELINE_TEMPL_X1] = ui->timeline_templ_x1->value();
    m_intMapData[TIMELINE_TEMPL_Y1] = ui->timeline_templ_y1->value();
    m_intMapData[TIMELINE_TEMPL_X2] = ui->timeline_templ_x2->value();
    m_intMapData[TIMELINE_TEMPL_Y2] = ui->timeline_templ_y2->value();

    //double
    m_doubleMapData[SCREEN_MAGNIFY] = ui->screen_magnify->value();

    //将map写入数据库
    C_SQL sql;
    sql.write_intMapData(m_intMapData);
    sql.write_doubleMapData(m_doubleMapData);
}


void Widget::on_checkBoxPreview_stateChanged(int arg1)
{
    QMessageBox::information(this, "", "Preview");

    if(ui->checkBoxPreview->isChecked())
    {
        m_C_preview = new C_preview;
        m_C_preview->setPreviewData(m_intMapData,m_doubleMapData[SCREEN_MAGNIFY]);
        m_C_preview->resize
            (
                m_intMapData[SCREEN_RESOLUTION_X] / (m_doubleMapData[SCREEN_MAGNIFY]),
                m_intMapData[SCREEN_RESOLUTION_Y] / (m_doubleMapData[SCREEN_MAGNIFY])
                );
        m_C_preview->show();
    }
    else
    {
        m_C_preview->close();
        delete m_C_preview;
        m_C_preview=nullptr;
    }
}


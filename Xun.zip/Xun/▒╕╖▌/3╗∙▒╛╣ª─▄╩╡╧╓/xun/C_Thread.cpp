#include "C_Thread.h"

void C_Thread::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;
}

void C_Thread::run()
{
    while (1)
    {
        //检测并点击播放按钮
        struct Click play
        {
            cv::imread("play.png", 0)
                , m_intMapData[PLAY_X1]
                , m_intMapData[PLAY_Y1]
                , m_intMapData[PLAY_X2]
                , m_intMapData[PLAY_Y2]
        };
        function_clickWhile(play);


        //开始录制
        emit startRecording();

        //检测播放完毕
        //获取timeline的模板图像timeline_templ
        cv::Mat timeline_templ = function_screenGray(m_intMapData[TIMELINE_TEMPL_X1],m_intMapData[TIMELINE_TEMPL_Y1],m_intMapData[TIMELINE_TEMPL_X2],m_intMapData[TIMELINE_TEMPL_Y2]);

        // cv::namedWindow("hist", cv::WINDOW_FREERATIO);
        // cv::imshow("hist", timeline_templ);
        // cv::waitKey(0);

        struct Click timeline
        {
            timeline_templ
                , m_intMapData[TIMELINE_X1]
                , m_intMapData[TIMELINE_Y1]
                , m_intMapData[TIMELINE_X2]
                , m_intMapData[TIMELINE_Y2]
        };
        while (true)
        {
            cv::Mat srcGray = function_screenGray(timeline.x1, timeline.y1, timeline.x2, timeline.y2);

            cv::Point p = function_matchTemplate(srcGray, timeline.templ, 0.9, timeline.x1, timeline.y1);

            //std::cout<<p.x<<"\n";

            if (p.x != -1)
            {
                //SendMouseClick(p.x, p.y, sleepTime);

                break;
            }


            Sleep(10);
        }

        //按下：下一集
        keybd_event(VK_DOWN, 0, 0, 0);
        Sleep(100);
        keybd_event(VK_DOWN, 0, KEYEVENTF_KEYUP, 0);
        Sleep(1000);

        //停止录制
        emit stopRecording();


        // while(true)
        // {
        //     Sleep(10000);
        // }

        Sleep(5000);
    }
}



C_Thread::C_Thread() {}

#ifndef C_THREAD_H
#define C_THREAD_H

#include"Defines.h"
#include <QMap>
#include <QProcess>
#include<QThread>

class C_Thread:public QThread
{
    Q_OBJECT
private:
    QMap<int,int> m_intMapData;

    std::atomic<bool> m_quit = false;//原子变量

    //在（x,y）处触发一次鼠标左键点击 （sleepTime为移动至按下的等待时间，默认500ms）
    void SendMouseClick(int x, int y, int sleepTime = 500)
    {
        INPUT input[2] = { 0 };
        MOUSEINPUT mi = { 0 };

        // 设置鼠标位置
        SetCursorPos(x, y);

        Sleep(sleepTime);

        // 按下鼠标左键
        //mi.type = INPUT_MOUSE;
        mi.dx = 0; // 相对移动，这里设置为0
        mi.dy = 0; // 相对移动，这里设置为0
        mi.mouseData = 0; // 通常设置为0，对于左键点击不需要特殊值
        mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        input[0].mi = mi;

        // 释放鼠标左键
        mi.dwFlags = MOUSEEVENTF_LEFTUP;
        input[1].mi = mi;

        // 发送输入事件
        SendInput(2, input, sizeof(INPUT));
    }

    //图像检测区域，在区域中心按下左键，鼠标移动后等待时间，循环间隔时间
    bool function_clickWhile(struct Click button,int sleepTime = 500, int whileTime = 2000)
    {
        while (true)
        {
            cv::Mat srcGray = function_screenGray(button.x1, button.y1, button.x2, button.y2);

            cv::Point p = function_matchTemplate(srcGray, button.templ, 0.8, button.x1, button.y1);

            if (p.x != -1)
            {
                SendMouseClick(p.x, p.y, sleepTime);

                return true;
            }


            Sleep(whileTime);
        }



        Sleep(100);
    }

    //截取全屏灰度图像函数
    cv::Mat function_screenGray(int x1, int y1, int x2, int y2)
    {
        //截图
        // 获取屏幕设备的上下文
        HDC hScreenDC = GetDC(NULL);
        // 计算截图区域的宽度和高度
        int width = x2 - x1;
        int height = y2 - y1;

        // 创建一个与屏幕设备上下文兼容的内存设备上下文
        HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

        // 创建一个与屏幕兼容的位图，用于存储截图数据
        HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);

        // 将位图选入内存设备上下文
        HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemoryDC, hBitmap);

        // 将指定区域的屏幕内容拷贝到位图上
        BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, x1, y1, SRCCOPY);

        // 创建OpenCV Mat来存储图像数据
        cv::Mat screenshot(height, width, CV_8UC4); // Assuming 32-bit color depth

        // 锁定位图的像素区域以便访问
        BITMAPINFOHEADER bi;
        bi.biSize = sizeof(BITMAPINFOHEADER);
        bi.biWidth = width;
        bi.biHeight = -height; // Negative height for top-down DIB
        bi.biPlanes = 1;
        bi.biBitCount = 32;
        bi.biCompression = BI_RGB;
        bi.biSizeImage = 0;
        bi.biXPelsPerMeter = 0;
        bi.biYPelsPerMeter = 0;
        bi.biClrUsed = 0;
        bi.biClrImportant = 0;

        // 获取位图的像素数据，并将其存储在OpenCV Mat中
        GetDIBits(hMemoryDC, hBitmap, 0, height, screenshot.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

        // OpenCV默认使用BGR颜色空间，所以我们需要转换颜色通道
        cv::cvtColor(screenshot, screenshot, cv::COLOR_BGRA2BGR);

        // 将图像转换为灰度图像
        cv::Mat grayScreenshot;
        cv::cvtColor(screenshot, grayScreenshot, cv::COLOR_BGR2GRAY);

        // 清理资源
        SelectObject(hMemoryDC, hOldBitmap);
        DeleteObject(hBitmap);
        DeleteDC(hMemoryDC);
        ReleaseDC(NULL, hScreenDC);

        //cv::namedWindow("hist", cv::WINDOW_FREERATIO);
        //cv::imshow("hist", grayScreenshot);

        return grayScreenshot;
    }

    //图像检测函数，返回中心坐标 (截图，模板图，n值 ,截图左上角)  point= -1 时请弃用
    cv::Point function_matchTemplate(cv::Mat& src, cv::Mat& templ, double n, int x1, int y1)//截图，模板图，n值
    {

        //源图为空，阻止图像检测，否则程序崩溃！！！找了2个小时的bug
        cv::Point pFault(-1, -1);
        if ((src.cols == 0) || (templ.cols == 0) || (src.cols < templ.cols))
        {
            // 这是程序会崩溃的情况：

            //截图为空，返回-1值
            //模板图为空，返回-1值
            //截图小于模板图，返回-1值
            return pFault;
        }

        cv::Mat result(src.rows - templ.rows + 1, src.cols - templ.cols + 1, CV_32FC1); //构建结果矩阵
        matchTemplate(src, templ, result, cv::TM_CCOEFF_NORMED); //模板匹配

        double dMaxVal; //分数最大值
        cv::Point ptMaxLoc; //最大值坐标
        minMaxLoc(result, 0, &dMaxVal, 0, &ptMaxLoc); //寻找结果矩阵中的最大值

        //匹配结果的四个顶点
        //cv::Point pt1(ptMaxLoc.x, ptMaxLoc.y);
        //cv::Point pt2(ptMaxLoc.x + templ.cols, ptMaxLoc.y);
        //cv::Point pt3(ptMaxLoc.x, ptMaxLoc.y + templ.rows);
        //cv::Point pt4(ptMaxLoc.x + templ.cols, ptMaxLoc.y + templ.rows);

        //画线,因为是画在原图上，所以第一次画的线可能会挡住子弹，从而影响第二次检测，实战要注释掉。
        //line(src, pt1, pt2, cv::Scalar(0, 255, 0), 11, 1);
        //line(src, pt2, pt4, cv::Scalar(0, 255, 0), 11, 1);
        //line(src, pt4, pt3, cv::Scalar(0, 255, 0), 11, 1);
        //line(src, pt3, pt1, cv::Scalar(0, 255, 0), 11, 1);

        //cv::namedWindow("src", cv::WindowFlags::WINDOW_FREERATIO);
        //imshow("src", src);
        //imwrite("D:/M/Opencv/LearningProject/target_new0.png", image);


        //cv::imshow("image", src);
        //cv::waitKey(0);


        //std::cout << dMaxVal << std::endl;

        cv::Point p(x1 + ptMaxLoc.x + (templ.cols) / 2, y1 + ptMaxLoc.y + (templ.rows) / 2);

        //// 在图像上画点
        //cv::circle(src, p, 5, cv::Scalar(0, 255, 0), -1, cv::LINE_AA); // -1表示填充圆形，cv::LINE_AA表示抗锯齿
        //namedWindow("src", cv::WindowFlags::WINDOW_FREERATIO);
        //imshow("src", src);


        //std::cout<<"拟合度："<<dMaxVal<<"\n";

        if (dMaxVal > n)
        {
            return p;
        }
        else
        {
            return pFault;
        }

    }


public:
    C_Thread();
    void setIntMapData(const QMap<int, int> &newIntMapData);

    void quitTheWhile(){
        m_quit = true;
    }

signals:
    void startRecording();
    void stopRecording();
    void sendString(QString);

protected:
    void run()override;//写override提高代码可读性，说明这个函数是重载的

};

#endif // C_THREAD_H

#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "Defines.h"
#include "C_SQL.h"
#include "C_preview.h"
#include <C_Thread.h>
#include <qmessagebox.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;


    //数据库
private:
    QMap<int,int> m_intMapData;
    QMap<int,double> m_doubleMapData;
    QMap<int,QColor> m_QColorMapData;
public:
    void setIntMapData(const QMap<int, int> &newIntMapData);

    void setDoubleMapData(const QMap<int, double> &newDoubleMapData);

    void setQColorMapData(const QMap<int, QColor> &newQColorMapData);

    //图像检测区域预览
private:
    C_preview* m_C_preview;


    //多线程
private:
    C_Thread *m_C_Thread;
     QProcess *ffmpegProcess; // 将QProcess作为成员变量
private slots:
    void startRecording();
    void stopRecording();
    void recieveString(QString);

private slots:
    void on_btnSave_clicked();
    void on_checkBoxPreview_stateChanged(int arg1);
    void on_checkBoxStart_stateChanged(int arg1);
};
#endif // WIDGET_H

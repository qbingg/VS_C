#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , m_C_Thread(nullptr)
    , ffmpegProcess(nullptr)
{
    ui->setupUi(this);



}

Widget::~Widget()
{
    delete ui;
}

void Widget::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;

    //将数据赋值到ui控件上
    ui->screen_resolution_x->setValue(m_intMapData[SCREEN_RESOLUTION_X]);
    ui->screen_resolution_y->setValue(m_intMapData[SCREEN_RESOLUTION_Y]);

    ui->play_x1->setValue(m_intMapData[PLAY_X1]);
    ui->play_y1->setValue(m_intMapData[PLAY_Y1]);
    ui->play_x2->setValue(m_intMapData[PLAY_X2]);
    ui->play_y2->setValue(m_intMapData[PLAY_Y2]);

    ui->timeline_x1->setValue(m_intMapData[TIMELINE_X1]);
    ui->timeline_y1->setValue(m_intMapData[TIMELINE_Y1]);
    ui->timeline_x2->setValue(m_intMapData[TIMELINE_X2]);
    ui->timeline_y2->setValue(m_intMapData[TIMELINE_Y2]);

    ui->timeline_templ_x1->setValue(m_intMapData[TIMELINE_TEMPL_X1]);
    ui->timeline_templ_y1->setValue(m_intMapData[TIMELINE_TEMPL_Y1]);
    ui->timeline_templ_x2->setValue(m_intMapData[TIMELINE_TEMPL_X2]);
    ui->timeline_templ_y2->setValue(m_intMapData[TIMELINE_TEMPL_Y2]);


}

void Widget::setDoubleMapData(const QMap<int, double> &newDoubleMapData)
{
    m_doubleMapData = newDoubleMapData;

    ui->screen_magnify->setValue(m_doubleMapData[SCREEN_MAGNIFY]);

}

void Widget::startRecording()
{
    if(1)
    {
        // 如果之前有进程在运行，先终止它
        if (ffmpegProcess && ffmpegProcess->state() != QProcess::NotRunning) {
            ffmpegProcess->terminate();
            if (!ffmpegProcess->waitForFinished(3000)) {
                ffmpegProcess->kill();
            }
        }

        /* 不录制音频

        // QStringList arguments;
        // arguments << "-y"                       // 强制覆盖输出文件
        //           << "-f" << "gdigrab"          // 视频捕获格式
        //           << "-framerate" << "30"       // 帧率
        //           << "-i" << "desktop"          // 视频输入源（桌面）
        //           << "-c:v" << "libx264"        // 视频编码器
        //           << "-crf" << "23"             // 视频质量
        //           << "-preset" << "veryfast"    // 编码速度
        //           << ui->lineEdit->text()+".mp4";              // 输出文件
*/

        /* 录制音频，在cmd可运行，在qt不行

        // QStringList arguments;
        // arguments << "-y"                       // 强制覆盖输出文件
        //           << "-f" << "gdigrab"          // 视频捕获格式
        //           << "-framerate" << "30"       // 帧率
        //           << "-i" << "desktop"          // 视频输入源（桌面）
        //           << "-f" << "dshow"            // 音频捕获格式（DirectShow）
        //           << "-i" << "audio=\"CABLE Output (VB-Audio Virtual Cable)\"" // 音频输入源
        //           << "-c:v" << "libx264"        // 视频编码器
        //           << "-crf" << "23"             // 视频质量
        //           << "-preset" << "veryfast"    // 编码速度
        //           << "-c:a" << "aac"            // 音频编码器
        //           << "-strict" << "experimental" // 允许实验性编码器（如 AAC）
        //           << ui->lineEdit->text() + ".mp4"; // 输出文件
*/

        /* 用<<代替字符串内的空格，更不行！！！只能识别到audio=\"CABLE

        // QStringList arguments;
        // arguments << "-y"                       // 强制覆盖输出文件
        //           << "-f" << "gdigrab"          // 视频捕获格式
        //           << "-framerate" << "30"       // 帧率
        //           << "-i" << "desktop"          // 视频输入源（桌面）
        //           << "-f" << "dshow"            // 音频捕获格式（DirectShow）
        //           << "-i" << "audio=\"CABLE"<<"Output"<<"(VB-Audio"<<"Virtual"<<"Cable)\"" // 音频输入源
        //           << "-c:v" << "libx264"        // 视频编码器
        //           << "-crf" << "23"             // 视频质量
        //           << "-preset" << "veryfast"    // 编码速度
        //           << "-c:a" << "aac"            // 音频编码器
        //           << "-strict" << "experimental" // 允许实验性编码器（如 AAC）
        //           << ui->lineEdit->text() + ".mp4"; // 输出文件
*/

        // 去掉 : 反斜杠" 成功了
        QStringList arguments;
        arguments << "-y"                       // 强制覆盖输出文件
                  << "-f" << "gdigrab"          // 视频捕获格式
                  << "-framerate" << "30"       // 帧率
                  << "-i" << "desktop"          // 视频输入源（桌面）
                  << "-f" << "dshow"            // 音频捕获格式（DirectShow）
                  << "-i" << "audio=CABLE Output (VB-Audio Virtual Cable)" // 音频输入源
                  << "-c:v" << "libx264"        // 视频编码器
                  << "-crf" << "23"             // 视频质量
                  << "-preset" << "veryfast"    // 编码速度
                  << "-c:a" << "aac"            // 音频编码器
                  << "-strict" << "experimental" // 允许实验性编码器（如 AAC）
                  << QString::number(ui->outputFileName->value()) +".mp4"; // 输出文件

        ui->outputFileName->setValue(ui->outputFileName->value() + 1);

        qDebug() << "FFmpeg command:" << "ffmpeg " << arguments.join(" ");


        // 创建新的QProcess实例
        ffmpegProcess = new QProcess(this);
        //连接 finished 信号
        //使用 Lambda 表达式处理信号
        connect(ffmpegProcess, &QProcess::finished, [=](int exitCode, QProcess::ExitStatus exitStatus) {
            if (exitStatus == QProcess::NormalExit && exitCode == 0) {
                qDebug() << "Video cut successfully!";
                //QMessageBox::information(this, "", "录制成功");
            } else {
                qDebug() << "Error occurred:" << ffmpegProcess->readAllStandardError();
            }
            ffmpegProcess->deleteLater();
        });

        connect(ffmpegProcess, QOverload<QProcess::ProcessError>::of(&QProcess::errorOccurred),
                [=](QProcess::ProcessError error) {
                    qDebug() << "Process error:" << error;
                    ffmpegProcess->deleteLater();
                });

        ffmpegProcess->start("ffmpeg", arguments);
    }

}

void Widget::stopRecording()
{
    if (ffmpegProcess) {
        // 先尝试优雅终止
        ffmpegProcess->write("q\n");  // 发送FFmpeg的退出命令
        ffmpegProcess->closeWriteChannel();

        if (!ffmpegProcess->waitForFinished(5000)) { // 等待5秒
            ffmpegProcess->terminate();
            if (!ffmpegProcess->waitForFinished(3000)) {
                ffmpegProcess->kill();
            }
        }
    }
}

void Widget::on_btnSave_clicked()
{
    //将ui控件的数据复制到Map里

    //将ui控件的数据写入Map
    //int
    m_intMapData[SCREEN_RESOLUTION_X] = ui->screen_resolution_x->value();
    m_intMapData[SCREEN_RESOLUTION_Y] = ui->screen_resolution_y->value();

    m_intMapData[PLAY_X1] = ui->play_x1->value();
    m_intMapData[PLAY_Y1] = ui->play_y1->value();
    m_intMapData[PLAY_X2] = ui->play_x2->value();
    m_intMapData[PLAY_Y2] = ui->play_y2->value();

    m_intMapData[TIMELINE_X1] = ui->timeline_x1->value();
    m_intMapData[TIMELINE_Y1] = ui->timeline_y1->value();
    m_intMapData[TIMELINE_X2] = ui->timeline_x2->value();
    m_intMapData[TIMELINE_Y2] = ui->timeline_y2->value();

    m_intMapData[TIMELINE_TEMPL_X1] = ui->timeline_templ_x1->value();
    m_intMapData[TIMELINE_TEMPL_Y1] = ui->timeline_templ_y1->value();
    m_intMapData[TIMELINE_TEMPL_X2] = ui->timeline_templ_x2->value();
    m_intMapData[TIMELINE_TEMPL_Y2] = ui->timeline_templ_y2->value();

    //double
    m_doubleMapData[SCREEN_MAGNIFY] = ui->screen_magnify->value();

    //将map写入数据库
    C_SQL sql;
    sql.write_intMapData(m_intMapData);
    sql.write_doubleMapData(m_doubleMapData);
}


void Widget::on_checkBoxPreview_stateChanged(int arg1)
{
    QMessageBox::information(this, "", "Preview");

    if(ui->checkBoxPreview->isChecked())
    {
        m_C_preview = new C_preview;
        m_C_preview->setPreviewData(m_intMapData,m_doubleMapData[SCREEN_MAGNIFY]);
        m_C_preview->resize
            (
                m_intMapData[SCREEN_RESOLUTION_X] / (m_doubleMapData[SCREEN_MAGNIFY]),
                m_intMapData[SCREEN_RESOLUTION_Y] / (m_doubleMapData[SCREEN_MAGNIFY])
                );
        m_C_preview->show();
    }
    else
    {
        m_C_preview->close();
        delete m_C_preview;
        m_C_preview=nullptr;
    }
}


void Widget::on_checkBoxStart_stateChanged(int arg1)
{
    if(ui->checkBoxStart->isChecked())
    {
        m_C_Thread = new C_Thread;

        //绑定槽函数：接受信号
        connect(m_C_Thread,&C_Thread::startRecording,this,&Widget::startRecording);
        connect(m_C_Thread,&C_Thread::stopRecording,this,&Widget::stopRecording);

        m_C_Thread->setIntMapData(m_intMapData);
        m_C_Thread->start();
    }
    else
    {
        m_C_Thread->quitTheWhile();//停下while循环
        m_C_Thread->quit(); // 停止线程
        m_C_Thread->wait(); // 等待线程退出

        //如果停止录制放在开始录制之前的话，手动结束，就要手动调用“停止录制”
        //否则最后一个视频会无法播放
        stopRecording();

        delete m_C_Thread;
        m_C_Thread = nullptr;
    }


}


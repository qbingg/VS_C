#include "C_Thread.h"

void C_Thread::setIntMapData(const QMap<int, int> &newIntMapData)
{
    m_intMapData = newIntMapData;
}

void C_Thread::run()
{
    while (!m_quit)
    {
        //停止录制（第一次因为ffmpegProcess=nullptr）if为空，不执行
        emit stopRecording();
        emit sendString("停止");

        //检测并点击播放按钮
        struct Click play
        {
            cv::imread("play.png", 0)
                , m_intMapData[PLAY_X1]
                , m_intMapData[PLAY_Y1]
                , m_intMapData[PLAY_X2]
                , m_intMapData[PLAY_Y2]
        };

        // keybd_event(13, 0, 0, 0);
        // Sleep(100);
        // keybd_event(13, 0, KEYEVENTF_KEYUP, 0);
        // Sleep(1000);

        while (true)
        {
            cv::Mat srcGray = function_screenGray(play.x1, play.y1, play.x2, play.y2);

            cv::Point p = function_matchTemplate(srcGray, play.templ, 0.8, play.x1, play.y1);

            //std::cout<<p.x<<"\n";

            if (p.x != -1)
            {
                //SendMouseClick(p.x, p.y, sleepTime);
                keybd_event(13, 0, 0, 0);
                Sleep(100);
                keybd_event(13, 0, KEYEVENTF_KEYUP, 0);
                Sleep(1000);

                break;
            }


            Sleep(10);
        }

        emit sendString("按下了：下一集");

        emit sendString("检测并点击了播放按钮");

        //开始录制
        emit startRecording();
        emit sendString("开始");

        //检测播放完毕
        //获取timeline的模板图像timeline_templ
        cv::Mat timeline_templ = function_screenGray(m_intMapData[TIMELINE_TEMPL_X1],m_intMapData[TIMELINE_TEMPL_Y1],m_intMapData[TIMELINE_TEMPL_X2],m_intMapData[TIMELINE_TEMPL_Y2]);

        // cv::namedWindow("hist", cv::WINDOW_FREERATIO);
        // cv::imshow("hist", timeline_templ);
        // cv::waitKey(0);

        struct Click timeline
        {
            cv::imread("button.png", 0)
                , m_intMapData[TIMELINE_X1]
                , m_intMapData[TIMELINE_Y1]
                , m_intMapData[TIMELINE_X2]
                , m_intMapData[TIMELINE_Y2]
        };
        while (true)
        {
            cv::Mat srcGray = function_screenGray(timeline.x1, timeline.y1, timeline.x2, timeline.y2);

            cv::Point p = function_matchTemplate(srcGray, timeline.templ, 0.6, timeline.x1, timeline.y1);

            //std::cout<<p.x<<"\n";

            if (p.x != -1)
            {
                //SendMouseClick(p.x, p.y, sleepTime);

                break;
            }


            Sleep(10);
        }

        //按下：下一集
        keybd_event(VK_DOWN, 0, 0, 0);
        Sleep(100);
        keybd_event(VK_DOWN, 0, KEYEVENTF_KEYUP, 0);
        Sleep(1000);
        emit sendString("按下了：下一集");



        // while(true)
        // {
        //     Sleep(10000);
        // }

        Sleep(3000);
    }
}



C_Thread::C_Thread() {}
